//Copyright (C) 2003-2023, Foxit Software Inc..
//All Rights Reserved.
//
//http://www.foxitsoftware.com
//
//The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
//You cannot distribute any part of Foxit PDF SDK to any third party or general public,
//unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
//This file contains an example to demonstrate how to use Foxit PDF SDK to tag a PDF document.

import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.Library;
import com.foxit.sdk.common.Progressive;
import com.foxit.sdk.pdf.PDFDoc;
import com.foxit.sdk.pdf.PDFPage;
import com.foxit.sdk.pdf.SignatureCallback;
import com.foxit.sdk.addon.accessibility.*;
import com.foxit.sdk.common.fxcrt.RectF;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import static com.foxit.sdk.common.Constants.e_ErrSuccess;
import static com.foxit.sdk.pdf.PDFPage.e_ParsePageNormal;

public class taggedpdf {

 // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
       String os = System.getProperty("os.name").toLowerCase();
       String lib = "fsdk_java_";
       if (os.startsWith("win")) {
           lib += "win";
       } else if (os.startsWith("mac")) {
           lib += "mac";
       } else {
           lib += "linux";
       }
       if (System.getProperty("sun.arch.data.model").equals("64")) {
           if(System.getProperty("os.arch").equals("aarch64")){
               lib += "arm";
           }
           else{
               lib += "64";
           }
       } else {
           lib += "32";
       }
       System.loadLibrary(lib);
    }

 private static void createResultFolder(String output_path) {
     File myPath = new File(output_path);
     if (!myPath.exists()) {
         myPath.mkdir();
     }
 }

 public static void main(String[] args) throws PDFException {
     String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
	 String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
     String input_path = "../input_files/";
     String output_path = "../output_files/taggedpdf/";
     String input_file = input_path + "AboutFoxit.pdf";
     createResultFolder(output_path);

     // Initialize library
     int error_code = Library.initialize(sn, key);
     if (error_code != e_ErrSuccess) {
         System.out.println("Library Initialize Error: " + error_code);
         return;
     }
     
     {
         String output_file_path = output_path + "TaggedPdf_StartAutoTagged.pdf";

         PDFDoc pdfDoc= new PDFDoc(input_file);
         pdfDoc.load(null);
         TaggedPDF taggedpdf = new TaggedPDF(pdfDoc);
         Progressive progressive = taggedpdf.startTagDocument(null);
         int progressState = Progressive.e_ToBeContinued;
         while (Progressive.e_ToBeContinued == progressState)
           progressState = progressive.resume();

         pdfDoc.saveAs(output_file_path, 0);
     }
     {
         String output_file_path = output_path + "TaggedPdf_StartAutoTagged_SetCallback.pdf";

         PDFDoc pdfDoc= new PDFDoc(input_file);
         pdfDoc.load(null);
         TaggedPDF taggedpdf = new TaggedPDF(pdfDoc);
         TaggedPDFCallbackImpl callback = new TaggedPDFCallbackImpl();
         taggedpdf.setCallback(callback);
         Progressive progressive = taggedpdf.startTagDocument(null);
         int progressState = Progressive.e_ToBeContinued;
         while (Progressive.e_ToBeContinued == progressState)
           progressState = progressive.resume();

         pdfDoc.saveAs(output_file_path, 0);
     }
		 
     Library.release();
 }
}

class AutoTag_ReportElemRectCon {
	  public RectF rcRect;
	  public int eConfidence;
}
class ReportElemMap extends HashMap<Integer,ArrayList<AutoTag_ReportElemRectCon>> {}
class ReportResultPagesMap extends HashMap<Integer,ReportElemMap> {}
//Implementation of TaggedPDFCallback
class TaggedPDFCallbackImpl extends TaggedPDFCallback{
	private ReportResultPagesMap result_map_ = new ReportResultPagesMap();

	@Override
	public void release() {
		System.out.println("TaggedPDFCallbackImpl::Release()");
		ResetResult();
	}
	
	String GetReportCategoryString(int type) {
		String sFormat = "";
		switch (type) {
		case TaggedPDFCallback.e_ReportCategoryRegion:
		    sFormat = "Region";
		    break;
		case TaggedPDFCallback.e_ReportCategoryArtifact:
		    sFormat = "Artifact";
		    break;
		case TaggedPDFCallback.e_ReportCategoryParagraph:
		    sFormat = "Paragraph";
		    break;
		case TaggedPDFCallback.e_ReportCategoryListItem:
		    sFormat = "List Item";
		    break;
		case TaggedPDFCallback.e_ReportCategoryFigure:
		    sFormat = "Figure";
		    break;
		case TaggedPDFCallback.e_ReportCategoryTable:
		    sFormat = "Table";
		    break;
		case TaggedPDFCallback.e_ReportCategoryTableRow:
		    sFormat = "Table Row";
		    break;
		case TaggedPDFCallback.e_ReportCategoryTableHeader:
		    sFormat = "Table Header";
		    break;
		case TaggedPDFCallback.e_ReportCategoryTocItem:
		    sFormat = "Toc Item";
		    break;
		default:
		    break;
		}
		return sFormat;
	}

	String GetReportConfidenceString(int type) {
		String sFormat = "";
		switch (type) {
		case TaggedPDFCallback.e_ReportConfidenceHigh:
		    sFormat = "High";
		    break;
		case TaggedPDFCallback.e_ReportConfidenceMediumHigh:
		    sFormat = "Medium High";
		    break;
		case TaggedPDFCallback.e_ReportConfidenceMedium:
		    sFormat = "Medium";
		    break;
		case TaggedPDFCallback.e_ReportConfidenceMediumLow:
		    sFormat = "Medium Low";
		    break;
		case TaggedPDFCallback.e_ReportConfidenceLow:
		    sFormat = "Low";
		    break;
		default:
		    break;
		}
		return sFormat;
	}

	@Override
	public void report(int category, int confidence, int page_index, RectF rect) {
		System.out.println("Page Index: " + page_index + ", ReportCategory: " + GetReportCategoryString(category)
		      + ", ReportConfidence: " + GetReportConfidenceString(confidence) + ", Rect: [" + rect.getLeft()
		      + ", " +rect.getTop() + ", " + rect.getRight() + ", " + rect.getBottom() + "]");

		AutoTag_ReportElemRectCon pRectCon = new AutoTag_ReportElemRectCon();
		pRectCon.rcRect = rect;
		pRectCon.eConfidence = confidence;

		ReportElemMap pElemMap = null;
		ArrayList<AutoTag_ReportElemRectCon> pArray = null;

		if (!result_map_.containsKey(page_index)) {
		    pArray = new ArrayList<AutoTag_ReportElemRectCon>();
		    pArray.add(pRectCon);
		    pElemMap = new ReportElemMap();
		    pElemMap.put(category, pArray);
		    result_map_.put(page_index, pElemMap);
		}
		else {
		    pElemMap = result_map_.get(page_index);
		    if (pElemMap.containsKey(category)) {
		        pArray = pElemMap.get(category);
		        pArray.add(pRectCon);
		    }
		    else {
		        pArray = new ArrayList<AutoTag_ReportElemRectCon>();
		        pArray.add(pRectCon);
		        pElemMap.put(category, pArray);
		    }
		}
	}

	ReportResultPagesMap GetResult() {
		return result_map_;
	}

	void ResetResult() {
		result_map_.clear();
	}
}