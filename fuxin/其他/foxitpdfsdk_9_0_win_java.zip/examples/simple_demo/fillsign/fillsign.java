
// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to add fillsign to PDF document.
import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.Library;
import com.foxit.sdk.common.Constants;
import com.foxit.sdk.pdf.PDFDoc;
import com.foxit.sdk.pdf.PDFPage;
import com.foxit.sdk.pdf.FillSign;
import com.foxit.sdk.pdf.FillSign.*;
import com.foxit.sdk.common.fxcrt.PointF;
import com.foxit.sdk.common.fxcrt.Matrix2D;
import com.foxit.sdk.pdf.FillSignObject;
import com.foxit.sdk.pdf.TextFillSignObjectDataArray;
import com.foxit.sdk.pdf.TextFillSignObjectData;
import com.foxit.sdk.pdf.SignatureFillSignObject;
import com.foxit.sdk.pdf.graphics.TextState;
import com.foxit.sdk.common.Font;
import com.foxit.sdk.common.Bitmap;

import java.io.File;
import static java.lang.Math.max;
import static java.lang.StrictMath.ceil;
import static com.foxit.sdk.common.Constants.e_ErrSuccess;
import static com.foxit.sdk.common.Constants.e_ErrInvalidLicense;
import static com.foxit.sdk.pdf.PDFDoc.e_SaveFlagRemoveRedundantObjects;
import static com.foxit.sdk.pdf.PDFDoc.e_SaveFlagNoOriginal;
import static com.foxit.sdk.pdf.PDFPage.e_ParsePageNormal;
import static com.foxit.sdk.common.Constants.e_Rotation0;
import static com.foxit.sdk.common.Font.e_StdIDHelvetica;
import static com.foxit.sdk.pdf.FillSign.e_FillSignObjectTypeCrossMark;
import static com.foxit.sdk.pdf.FillSign.e_FillSignObjectTypeCheckMark;
import static com.foxit.sdk.pdf.FillSign.e_FillSignObjectTypeRoundRectangle;
import static com.foxit.sdk.pdf.FillSign.e_FillSignObjectTypeLine;
import static com.foxit.sdk.pdf.FillSign.e_FillSignObjectTypeDot;
import static com.foxit.sdk.pdf.FillSign.e_FillSignObjectTypeSignature;
import static com.foxit.sdk.pdf.FillSign.e_FillSignObjectTypeInitialsSignature;
import static com.foxit.sdk.common.Bitmap.e_DIBArgb;

public class fillsign {

  private static String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
  private static String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";

  private static String output_path = "../output_files/fillsign/";
  private static String input_path = "../input_files/";

  // You can also use System.load("filename") instead. The filename argument must
  // be an absolute path name.
  static {
      String os = System.getProperty("os.name").toLowerCase();
      String lib = "fsdk_java_";
      if (os.startsWith("win")) {
          lib += "win";
      } else if (os.startsWith("mac")) {
          lib += "mac";
      } else {
          lib += "linux";
      }
      if (System.getProperty("sun.arch.data.model").equals("64")) {
          if(System.getProperty("os.arch").equals("aarch64")){
              lib += "arm";
          }
          else{
              lib += "64";
          }
      } else {
          lib += "32";
      }
      System.loadLibrary(lib);
  }

  private static void createResultFolder(String output_path) {
    File myPath = new File(output_path);
    if (!myPath.exists()) {
      myPath.mkdir();
    }
  }

  public static void main(String[] args) throws PDFException {
    // Initialize library
    int error_code = Library.initialize(sn, key);
    if (error_code != e_ErrSuccess) {
      System.out.println("Library Initialize Error: " + error_code);
      return;
    }
    createResultFolder(output_path);
    String input_file = input_path + "blank.pdf";
    System.out.println("fillsign Start ");
    try {
      PDFDoc doc = new PDFDoc(input_file);
      error_code = doc.load(null);
      if (error_code != e_ErrSuccess) {
        System.out.println("The Doc [" + input_file + " Error: " + error_code);
        return;
      }

      PDFPage page = doc.getPage(0);

      page.startParse(e_ParsePageNormal, null, false);
      FillSign sign = new FillSign(page);
      FillSignObject fillsignobject = sign.addObject(e_FillSignObjectTypeCrossMark, new PointF(0, 0), 100, 100,e_Rotation0);
      fillsignobject = sign.addObject(e_FillSignObjectTypeCheckMark, new PointF(100, 100), 50, 100, e_Rotation0);
      fillsignobject = sign.addObject(e_FillSignObjectTypeRoundRectangle, new PointF(200, 200), 100, 50, e_Rotation0);
      fillsignobject = sign.addObject(e_FillSignObjectTypeLine, new PointF(300, 300), 100, 50, e_Rotation0);
      fillsignobject = sign.addObject(e_FillSignObjectTypeDot, new PointF(400, 400), 100, 100, e_Rotation0);

      TextFillSignObjectDataArray textdataarray = new TextFillSignObjectDataArray();
      TextFillSignObjectData textdata = new TextFillSignObjectData();
      TextState textState = new TextState();
      Font font = new Font(e_StdIDHelvetica);

      textState.setFont(font);
      textState.setFont_size(20);
      textState.setOrigin_position(new PointF(500, 0));
      textState.setCharspace(1.0f);
      textdata.setText("666777888");
      textdata.setText_state(textState);
      textdataarray.add(textdata);
      FillSignObject text = sign.addTextObject(textdataarray, new PointF(400, 100), 200, 200, e_Rotation0, false);
      text.generateContent();
      fillsignobject = sign.addObject(e_FillSignObjectTypeSignature, new PointF(300, 100), 100, 100, e_Rotation0);
      Bitmap bitmap = new Bitmap(100, 100, e_DIBArgb, null, 0);
      long background_color = 0xFFFF0000;
      bitmap.fillRect(background_color, null);
      SignatureFillSignObject signature = new SignatureFillSignObject(fillsignobject);
      signature.setBitmap(bitmap);

      fillsignobject.generateContent();
      page.generateContent();

      String pdf_new = output_path + "new_fillsign.pdf";
      doc.saveAs(pdf_new, e_SaveFlagNoOriginal);
      System.out.println("fillsign Finish : All fillsign generated successfully");

    } catch (PDFException e) {
      e.printStackTrace();
      return;
    }
    Library.release();
  }
}
