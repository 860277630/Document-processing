// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to verify if a PDF file is PDFA-1a version
// or convert a PDF file to PDFA-1a version.

import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.Library;
import com.foxit.sdk.addon.compliance.*;
import com.foxit.sdk.common.WStringArray;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import static com.foxit.sdk.common.Constants.e_ErrSuccess;
import static com.foxit.sdk.common.Constants.e_ErrInvalidLicense;

public class compliance {


    static String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg=="; 
    static String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
    static String output_path = "../output_files/compliance/";
    static String input_path = "../input_files/";

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
        String os = System.getProperty("os.name").toLowerCase();
        String lib = "fsdk_java_";
        if (os.startsWith("win")) {
            lib += "win";
        } else if (os.startsWith("mac")) {
            lib += "mac";
        } else {
            lib += "linux";
        }
        if (System.getProperty("sun.arch.data.model").equals("64")) {
            if(System.getProperty("os.arch").equals("aarch64")){
                lib += "arm";
            }
            else{
                lib += "64";
            }
        } else {
            lib += "32";
        }
        System.loadLibrary(lib);
    }

    private static void createResultFolder(String output_path) {
        File myPath = new File(output_path);
        if (!myPath.exists()) {
            myPath.mkdir();
        }
    }

    static void outputPDFAHitData(ResultInformation result_info, String output_txt_path) throws PDFException, IOException {
        FileWriter text_doc = new FileWriter(output_txt_path, false);

        int hit_data_count = result_info.getHitDataCount();
        text_doc.write(String.format("== Hit Data, count:%d ==\r\n", hit_data_count));
        for (int i = 0; i<hit_data_count; i++) {
            HitData hit_data = result_info.getHitData(i);
            text_doc.write(String.format("Triggered count:%d\r\n", hit_data.getTriggered_count()));

            text_doc.write("Name:");
            text_doc.write(hit_data.getName());
            text_doc.write("\r\n");

            text_doc.write("Comment:");
            text_doc.write(hit_data.getComment());
            text_doc.write("\r\n");
    
            text_doc.write("Trigger value:");
            WStringArray trigger_values = hit_data.getTrigger_values();
            long trigger_value_count = trigger_values.getSize();
            if (trigger_value_count < 1) {
                text_doc.write("\r\n");
            } else {
                for (long z = 0; z<trigger_value_count; z++) {
                    text_doc.write("\t");
                    text_doc.write(trigger_values.getAt(z));
                    text_doc.write("\r\n");
                }
            }

            text_doc.write(String.format("Check severity:%d\r\nPage index:%d\r\n", hit_data.getSeverity(), hit_data.getPage_index()));
    
            text_doc.write("\r\n");
        }
        text_doc.close();
    }

    static void outputPDFAFixupData(ResultInformation result_info, String output_txt_path) throws PDFException, IOException {
        FileWriter text_doc = new FileWriter(output_txt_path, false);

        int fixup_count = result_info.getFixupDataCount();
        text_doc.write(String.format("== Fixup Data, count:%d ==\r\n", fixup_count));
        for (int i = 0; i<fixup_count; i++) {
            FixupData fixup_data = result_info.getFixupData(i);
            text_doc.write(String.format("Used count:%d\r\n", fixup_data.getUsed_count()));

            text_doc.write("Name:");
            text_doc.write(fixup_data.getName());
            text_doc.write("\r\n");

            text_doc.write("Comment:");
            text_doc.write(fixup_data.getComment());
            text_doc.write("\r\n");

            text_doc.write("Reason:");
            WStringArray reasons = fixup_data.getReasons();
            long reason_count = reasons.getSize();
            if (reason_count < 1) {
                text_doc.write("\r\n");
            } else {
                for (long z = 0; z<reason_count; z++) {
                    text_doc.write("\t");
                    text_doc.write(reasons.getAt(z));
                    text_doc.write("\r\n");
                }
            }

            text_doc.write(String.format("State value:%d\r\n", fixup_data.getState()));

            text_doc.write("\r\n");
        }
        text_doc.close();
    }
    
    public static void main(String[] args) throws PDFException, IOException {
        createResultFolder(output_path);
        // Initialize library
        int error_code = Library.initialize(sn, key);
        if (error_code != e_ErrSuccess) {
            System.out.println(String.format("Library Initialize Error: %d\n", error_code));
            return;
        }

        String input_file = input_path + "AboutFoxit.pdf";

        try {
            // "compliance_resource_folder_path" is the path of compliance resource folder. Please refer to Developer Guide for more details.
            String compliance_resource_folder_path = "";
            // If you use an authorization key for Foxit PDF SDK, please set a valid unlock code string to compliance_engine_unlockcode for ComplianceEngine.
            // If you use an trial key for Foxit PDF SDK, just keep compliance_engine_unlockcode as an empty string.
            String compliance_engine_unlockcode = "";
            
            if (compliance_resource_folder_path.length()<1) {
                System.out.println("compliance_resource_folder_path is still empty. Please set it with a valid path to compliance resource folder path.");
                return ;
            }
            // Initialize compliance engine.
            error_code = ComplianceEngine.initialize(compliance_resource_folder_path, compliance_engine_unlockcode);
            if (error_code != e_ErrSuccess) {
              switch (error_code) {
              case e_ErrInvalidLicense:
                System.out.println("[Failed] Compliance module is not contained in current Foxit PDF SDK keys.\n");
                break;
              default:
                System.out.println(String.format("[Failed] Fail to initialize compliance engine. Error: %d\n", error_code));
                break;
              }
              return ;
            }
            System.out.println("ComplianceEngine is initialized.");
            
            // Set custom temp folder path for ComplianceEngine. 
            //ComplianceEngine.setTempFolderPath("");
            // Set languages. If not set language to ComplianceEngine, "English" will be used as default.
            //ComplianceEngine.setLanguage("Chinese-Simplified");

            PDFACompliance pdfa_compliance = new PDFACompliance();
            {
                // Verify original PDF file.
                System.out.println("======== PDFACompliance: Verify before convert ========");
                MyComplianceProgressCallback verify_progress_callback = new MyComplianceProgressCallback(output_path + "0_pdfacompliance_verify_before_convert_progressdata.txt");
                ResultInformation verify_result_info = pdfa_compliance.verify(PDFACompliance.e_VersionPDFA1a, input_file, 0, -1, verify_progress_callback);
                outputPDFAHitData(verify_result_info, output_path + "0_pdfacompliance_verify_before_convert_hitdata.txt");
            }
            
            String save_pdf_path = output_path + "1_pdfacompliance_convert_to_pdf1a.pdf";
            {
              // Convert original PDF file to PDFA-1a version.
                System.out.println("======== PDFACompliance: Convert ========");
                MyComplianceProgressCallback convert_progress_callback = new MyComplianceProgressCallback(output_path + "1_1_pdfacompliance_convert_progressdata.txt");
                ResultInformation convert_result_info = pdfa_compliance.convertPDFFile(input_file, save_pdf_path,
                                                                                       PDFACompliance.e_VersionPDFA1a,
                                                                                       convert_progress_callback);
                outputPDFAFixupData(convert_result_info, output_path+ "1_1_pdfacompliance_convert_pdfa1a_fixupdata.txt");
                outputPDFAHitData(convert_result_info, output_path + "1_1_pdfacompliance_convert_pdfa1a_hitdata.txt");
            }
            
            {
                // Verify converted result PDF file, which is not expected to be PDFA-1a compliant as the original did not have accessibility structures.
                System.out.println("======== PDFACompliance: Verify after convert ========");
                MyComplianceProgressCallback verify_progress_callback_2 = new MyComplianceProgressCallback(output_path + "1_2_pdfacompliance_verify_after_convert_progressdata.txt");
                ResultInformation verify_result_info_2 = pdfa_compliance.verify(PDFACompliance.e_VersionPDFA1a, save_pdf_path, 0, -1, verify_progress_callback_2);
                outputPDFAHitData(verify_result_info_2, output_path + "1_2_pdfacompliance_verify_after_convert_hitdata.txt");
            }

            input_file = input_path + "AboutFoxit_Structured.pdf";
            {
                // Verify original PDF file.
                System.out.println("======== PDFACompliance: Verify before convert ========");
                MyComplianceProgressCallback verify_progress_callback = new MyComplianceProgressCallback(output_path + "2_pdfacompliance_verify_before_convert_progressdata.txt");
                ResultInformation verify_result_info = pdfa_compliance.verify(PDFACompliance.e_VersionPDFA1a, input_file, 0, -1, verify_progress_callback);
                outputPDFAHitData(verify_result_info, output_path + "2_pdfacompliance_verify_before_convert_hitdata.txt");
            }

            save_pdf_path = output_path + "3_pdfacompliance_convert_to_pdf1a.pdf";
            {
              // Convert original PDF file to PDFA-1a version.
                System.out.println("======== PDFACompliance: Convert ========");
                MyComplianceProgressCallback convert_progress_callback = new MyComplianceProgressCallback(output_path + "3_1_pdfacompliance_convert_progressdata.txt");
                ResultInformation convert_result_info = pdfa_compliance.convertPDFFile(input_file, save_pdf_path,
                                                                                       PDFACompliance.e_VersionPDFA1a,
                                                                                       convert_progress_callback);
                outputPDFAFixupData(convert_result_info, output_path+ "3_1_pdfacompliance_convert_pdfa1a_fixupdata.txt");
                outputPDFAHitData(convert_result_info, output_path + "3_1_pdfacompliance_convert_pdfa1a_hitdata.txt");
            }

            {
                // Verify converted result PDF file, which is expected to be PDFA-1a version.
                System.out.println("======== PDFACompliance: Verify after convert ========");
                MyComplianceProgressCallback verify_progress_callback_2 = new MyComplianceProgressCallback(output_path + "3_2_pdfacompliance_verify_after_convert_progressdata.txt");
                ResultInformation verify_result_info_2 = pdfa_compliance.verify(PDFACompliance.e_VersionPDFA1a, save_pdf_path, 0, -1, verify_progress_callback_2);
                outputPDFAHitData(verify_result_info_2, output_path + "3_2_pdfacompliance_verify_after_convert_hitdata.txt");
            }

            PDFCompliance pdf_compliance = new PDFCompliance();
            input_file = input_path + "AF_ImageXObject_FormXObject.pdf";
            {
                // Convert original PDF file to PDF-1.4.
                System.out.println("======== PDFCompliance: Convert ========");
                MyComplianceProgressCallback convert_progress_callback= new MyComplianceProgressCallback(output_path + "4_pdfcompliance_convert_1_4_progressdata.txt");
                save_pdf_path = output_path + "4_pdfcompliance_convert_to_1_4.pdf";
                ResultInformation convert_result_info = pdf_compliance.convertPDFFile(input_file, save_pdf_path, 14, convert_progress_callback);
                outputPDFAFixupData(convert_result_info, output_path + "4_pdfcompliance_convert_1_4_fixupdata.txt");
                outputPDFAHitData(convert_result_info, output_path + "4_pdfcompliance_convert_1_4_hitdata.txt");
            }
            {
                // Convert original PDF file to PDF-1.7.
                System.out.println("======== PDFCompliance: Convert ========");
                MyComplianceProgressCallback convert_progress_callback = new MyComplianceProgressCallback(output_path + "5_pdfcompliance_convert_1_7_progressdata.txt");
                save_pdf_path = output_path + "5_pdfcompliance_convert_to_1_7.pdf";
                ResultInformation convert_result_info = pdf_compliance.convertPDFFile(input_file, save_pdf_path, 17, convert_progress_callback);
                outputPDFAFixupData(convert_result_info, output_path + "5_pdfcompliance_convert_1_7_fixupdata.txt");
                outputPDFAHitData(convert_result_info, output_path + "5_pdfcompliance_convert_1_7_hitdata.txt");
            }

            // Release compliance engine.
            ComplianceEngine.release();
            
            System.out.println("== End: Compliance demo. ==");


        } catch (Exception e) {
            e.printStackTrace();

        }
        Library.release();
        return;
    }

}
