// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file is a demo demonstrate how to convert a PDF file to one or multiple image files.

import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.Bitmap;
import com.foxit.sdk.common.Image;
import com.foxit.sdk.common.Library;
import com.foxit.sdk.common.Renderer;
import com.foxit.sdk.common.fxcrt.Matrix2D;
import com.foxit.sdk.pdf.PDFDoc;
import com.foxit.sdk.pdf.PDFPage;

import java.io.*;
import java.io.File;
import java.io.FileWriter;

import static com.foxit.sdk.common.Bitmap.e_DIBArgb;
import static com.foxit.sdk.common.Constants.e_ErrSuccess;
import static com.foxit.sdk.pdf.PDFPage.e_ParsePageNormal;

public class pdf2image {
    private static String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
    private static String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
    private static String output_path = "../output_files/pdf2image/";
    private static String input_path = "../input_files/";
    private static String input_file = input_path + "AboutFoxit.pdf";
    private static String[] support_image_extends = {".bmp", ".jpg", ".jpeg", ".png", ".jpx", ".jp2"};
    private static String[] support_multi_image = {".tif", ".tiff"};

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
       String os = System.getProperty("os.name").toLowerCase();
       String lib = "fsdk_java_";
       if (os.startsWith("win")) {
           lib += "win";
       } else if (os.startsWith("mac")) {
          lib += "mac";
       } else {
           lib += "linux";
       }
       if (System.getProperty("sun.arch.data.model").equals("64")) {
           if(System.getProperty("os.arch").equals("aarch64")){
               lib += "arm";
           }
           else{
               lib += "64";
           }
       } else {
           lib += "32";
       }
       System.loadLibrary(lib);
    }

    public static void main(String[] args) throws PDFException {
        createResultFolder(output_path);
        // Initialize library
        int error_code = Library.initialize(sn, key);
        if (error_code != e_ErrSuccess) {
            System.out.println("Library Initialize Error: " + error_code);
            return;
        }
        {
			PDFDoc doc = new PDFDoc(input_file);
			error_code = doc.load(null);
			if (error_code != e_ErrSuccess) {
				System.out.println("The Doc " + input_file + " Error: " + error_code);
				return;
			}
			PDF2Image(doc, false);
		}
		{
			File file = new File(input_file);  
			Long filelength = file.length();  
			byte[] filecontent = new byte[filelength.intValue()];  
			try {  
				FileInputStream in = new FileInputStream(file);  
				in.read(filecontent);  
				in.close();  
			} catch (FileNotFoundException e) {  
				e.printStackTrace();  
			} catch (IOException e) {  
				e.printStackTrace();  
			} 
			PDFDoc doc = new PDFDoc(filecontent);
			error_code = doc.load(null);
			if (error_code != e_ErrSuccess) {
				System.out.println("The Doc " + input_file + " Error: " + error_code);
				return;
			}
			PDF2Image(doc, true);
		}
        Library.release();
    }

	private static void PDF2Image(PDFDoc doc, boolean from_memory) throws PDFException {
        Image image = new Image();
        // Get page count
        int nPageCount = doc.getPageCount();
        for (int i = 0; i < nPageCount; i++) {
            PDFPage page = doc.getPage(i);
            // Parse page.
            page.startParse(e_ParsePageNormal, null, false);

            int width = (int) page.getWidth();
            int height = (int) page.getHeight();
            Matrix2D matrix = page.getDisplayMatrix(0, 0, width, height, page.getRotation());

            // Prepare a bitmap for rendering.
            Bitmap bitmap = new Bitmap(width, height, e_DIBArgb, null, 0);
            bitmap.fillRect(0xFFFFFFFF, null);

            // Render page
            Renderer render = new Renderer(bitmap, false);
            render.startRender(page, matrix, null);
            image.addFrame(bitmap);
            for (int j = 0; j < support_image_extends.length; j++) {
                String extend = support_image_extends[j];
                Save2Image(bitmap, i, extend, from_memory);
            }
        }
        for (int j = 0; j < support_multi_image.length; j++) {
            String extend = support_multi_image[j];
            Save2Image(image, extend, from_memory);
        }
	}
	
    private static void createResultFolder(String output_path) {
        File myPath = new File(output_path);
        if (!myPath.exists()) {
            myPath.mkdir();
        }
    }

    private static void Save2Image(Bitmap bitmap, int page_index, String sExt, boolean from_memory) throws PDFException {
        // Add the bitmap to image and save the image.
        Image image = new Image();
        image.addFrame(bitmap);
        String s = "AboutFoxit_" + page_index + (from_memory ? "_from_memory":"");
        s = output_path + s + sExt;
        image.saveAs(s);

        System.out.println("Save page " + page_index + " into a picture of " + sExt + " format.");
    }

    private static void Save2Image(Image image, String sExt, boolean from_memory) throws PDFException {
        String s = "AboutFoxit" + (from_memory ? "_from_memory":"");
        s = output_path + s + sExt;
        image.saveAs(s);

        System.out.println("Save pdf file into a picture of " + sExt + " format.");
    }
}
