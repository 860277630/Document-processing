// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to add electronic table to PDF document.

import java.util.Calendar;
import java.io.File;
import java.io.IOException;

import com.foxit.sdk.common.DateTime;
import com.foxit.sdk.common.Constants;
import com.foxit.sdk.common.fxcrt.RectF;
import com.foxit.sdk.common.fxcrt.FloatArray;
import com.foxit.sdk.common.Font;
import com.foxit.sdk.common.Library;
import com.foxit.sdk.common.Image;

import com.foxit.sdk.pdf.annots.RichTextStyle;
import com.foxit.sdk.addon.tablegenerator.TableBorderInfo;
import com.foxit.sdk.addon.tablegenerator.TableData;
import com.foxit.sdk.addon.tablegenerator.TableCellData;
import com.foxit.sdk.addon.tablegenerator.TableCellDataArray;
import com.foxit.sdk.addon.tablegenerator.TableCellDataColArray;
import com.foxit.sdk.addon.tablegenerator.TableCellIndexArray;
import com.foxit.sdk.addon.tablegenerator.TableGenerator;
import com.foxit.sdk.pdf.PDFDoc;
import com.foxit.sdk.pdf.PDFPage;
import com.foxit.sdk.PDFException;

import static com.foxit.sdk.common.Constants.e_ErrSuccess;
import static com.foxit.sdk.common.Constants.e_AlignmentLeft;
import static com.foxit.sdk.common.Constants.e_AlignmentCenter;
import static com.foxit.sdk.common.Constants.e_AlignmentRight;
import static com.foxit.sdk.common.Font.e_StdIDHelvetica;
import static com.foxit.sdk.common.Font.e_CharsetANSI;
import static com.foxit.sdk.addon.tablegenerator.TableBorderInfo.e_TableBorderStyleSolid;
import static com.foxit.sdk.pdf.annots.RichTextStyle.e_CornerMarkNone;
import static com.foxit.sdk.pdf.annots.RichTextStyle.e_CornerMarkSubscript;
import static com.foxit.sdk.pdf.annots.RichTextStyle.e_CornerMarkSuperscript;

public class electronictable {
    private static String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
    private static String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
    private static String output_path = "../output_files/electronictable/";

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
        String os = System.getProperty("os.name").toLowerCase();
        String lib = "fsdk_java_";
        if (os.startsWith("win")) {
            lib += "win";
        } else if (os.startsWith("mac")) {
            lib += "mac";
        } else {
            lib += "linux";
        }
        if (System.getProperty("sun.arch.data.model").equals("64")) {
            if(System.getProperty("os.arch").equals("aarch64")){
                lib += "arm";
            }
            else{
                lib += "64";
            }
        } else {
            lib += "32";
        }
        System.loadLibrary(lib);
    }

    private static DateTime GetLocalDateTime() {
        Calendar c = Calendar.getInstance();

        DateTime datetime = new DateTime();
        datetime.setYear(c.get(Calendar.YEAR));
        datetime.setMonth(c.get(Calendar.MONTH) + 1);
        datetime.setDay(c.get(Calendar.DATE));
        datetime.setHour(c.get(Calendar.HOUR));
        datetime.setMinute(c.get(Calendar.MINUTE));
        datetime.setSecond(c.get(Calendar.SECOND));

        java.util.TimeZone timeZone = c.getTimeZone();
        int offset = timeZone.getRawOffset();
        int gmt = offset / (3600 * 1000);

        datetime.setUtc_hour_offset((short) gmt);
        datetime.setUtc_minute_offset(offset % (3600 * 1000) / 60);
        return datetime;
    }

    private static String DateTimeToString(DateTime datetime) {

        return String.format("%d/%d/%d-%d:%d:%d %s%d:%d", datetime.getYear(), datetime.getMonth(), datetime.getDay(),
                datetime.getHour(),
                datetime.getMinute(), datetime.getSecond(), datetime.getUtc_hour_offset() > 0 ? "+" : "-",
                datetime.getUtc_hour_offset(),
                datetime.getUtc_minute_offset());
    }

    private static RichTextStyle GetTableTextStyle(int index) throws PDFException {
        RichTextStyle style = new RichTextStyle();
        style.setFont(new Font(e_StdIDHelvetica));
        style.setText_size(10);
        style.setText_alignment(e_AlignmentLeft);
        style.setText_color(0x000000);
        style.setIs_bold(false);
        style.setIs_italic(false);
        style.setIs_underline(false);
        style.setIs_strikethrough(false);
        style.setMark_style(e_CornerMarkNone);

        switch (index) {
            case 1:
                style.setText_alignment(e_AlignmentCenter);
                break;
            case 2: {
                style.setText_alignment(e_AlignmentRight);
                style.setText_color(0x00FF00);
                break;
            }
            case 3:
                style.setText_size(15);
                break;
            case 4: {
                String os = System.getProperty("os.name");
                if (os.toLowerCase().startsWith("win"))
                    style.setFont(new Font("Times New Roman", 0, e_CharsetANSI, 0));
                else
                    style.setFont(new Font("FreeSerif", 0, e_CharsetANSI, 0));
                style.setText_color(0xFF0000);
                style.setText_alignment(e_AlignmentRight);
                break;
            }
            case 5: {
                String os = System.getProperty("os.name");
                if (os.toLowerCase().startsWith("win"))
                    style.setFont(new Font("Times New Roman", 0, e_CharsetANSI, 0));
                else
                    style.setFont(new Font("FreeSerif", 0, e_CharsetANSI, 0));
                style.setIs_bold(true);
                style.setText_alignment(e_AlignmentRight);
                break;
            }
            case 6: {
                style.setIs_bold(true);
                style.setIs_italic(true);
            }
            case 7: {
                style.setIs_bold(true);
                style.setIs_italic(true);
                style.setText_alignment(e_AlignmentCenter);
                break;
            }
            case 8: {
                style.setIs_underline(true);
                style.setText_alignment(e_AlignmentRight);
                break;
            }
            case 9:
                style.setIs_strikethrough(true);
                break;
            case 10:
                style.setMark_style(e_CornerMarkSubscript);
                break;
            case 11:
                style.setMark_style(e_CornerMarkSuperscript);
                break;
            default:
                break;
        }
        return style;
    }

    public static String GetTableCellText(int index) throws PDFException {
        String cell_text = "";
        switch (index) {
            case 0:
                cell_text = "Reference style";
                break;
            case 1:
                cell_text = "Alignment center";
                break;
            case 2:
                cell_text = "Green text color and alignment right";
                break;
            case 3:
                cell_text = "Text font size 15";
                break;
            case 4: {
                String os = System.getProperty("os.name");
                if (os.toLowerCase().startsWith("win"))
                    cell_text = "Red text color, Times New Roman font and alignment right";
                else
                    cell_text = "Red text color, FreeSerif font and alignment right";
                break;
            }
            case 5: {
                String os = System.getProperty("os.name");
                if (os.toLowerCase().startsWith("win"))
                    cell_text = "Bold, Times New Roman font and alignment right";
                else
                    cell_text = "Bold, FreeSerif font and alignment right";
                break;
            }
            case 6:
                cell_text = "Bold and italic";
                break;
            case 7:
                cell_text = "Bold, italic and alignment center";
                break;
            case 8:
                cell_text = "Underline and alignment right";
                break;
            case 9:
                cell_text = "Strikethrough";
                break;
            case 10:
                cell_text = "CornerMarkSubscript";
                break;
            case 11:
                cell_text = "CornerMarkSuperscript";
                break;
            default:
                cell_text = " ";
                break;
        }
        return cell_text;
    }

    public static void AddElectronicTable(PDFPage page) throws PDFException {
        // Add a spreadsheet with 4 rows and 3 columns
        {
            int index = 0;
            TableCellDataArray cell_array = new TableCellDataArray();

            for (int row = 0; row < 4; row++) {
                TableCellDataColArray col_array = new TableCellDataColArray();
                for (int col = 0; col < 3; col++) {
                    String cell_text = GetTableCellText(index);
                    RichTextStyle style = GetTableTextStyle(index++);
                    TableCellData cell_data = new TableCellData(style, cell_text, new Image(), new RectF());
                    col_array.add(cell_data);
                }
                    cell_array.add(col_array);
            }
            float page_width = page.getWidth();
            float page_height = page.getHeight();
            RectF rect = new RectF(100, 550, page_width - 100, page_height - 100);
			TableBorderInfo outsideborderinfoleft = new TableBorderInfo();
		    outsideborderinfoleft.setLine_width(1);
			TableBorderInfo outsideborderinforight = new TableBorderInfo();
		    outsideborderinforight.setLine_width(1);
			TableBorderInfo outsideborderinfotop = new TableBorderInfo();
		    outsideborderinfotop.setLine_width(1);
			TableBorderInfo outsideborderinfobottom = new TableBorderInfo();
		    outsideborderinfobottom.setLine_width(1);
			
			TableBorderInfo insideborderinfo_row = new TableBorderInfo();
			insideborderinfo_row.setLine_width(1);
		    TableBorderInfo insideborderinfo_col = new TableBorderInfo();
			insideborderinfo_col.setLine_width(1);
            TableData data = new TableData(rect, 4, 3, outsideborderinfoleft, outsideborderinforight, outsideborderinfotop,outsideborderinfobottom,insideborderinfo_row, insideborderinfo_col, new TableCellIndexArray(),new FloatArray(), new FloatArray());
          
            TableGenerator.addTableToPage(page, data, cell_array);
        }
      
        //Add a spreadsheet with 5 rows and 6 columns
        {
            String cell_text = " ";
            String[] show_text = { "First column", "Second column", "Third column", "Fourth column", "Fifth columns" };
            TableCellDataArray cell_array = new TableCellDataArray();
        
            for (int row = 0; row < 5; row++) {
                TableCellDataColArray col_array = new TableCellDataColArray();
            
                for (int col = 0; col < 6; col++) {
                    if (col == 5)
                        cell_text = DateTimeToString(GetLocalDateTime());
                    else
                        cell_text = show_text[col];
                    RichTextStyle style = GetTableTextStyle(row);
                    TableCellData cell_data = new TableCellData(style, cell_text, new Image(), new RectF());
                
                  col_array.add(cell_data);
                }
              cell_array.add(col_array);
            }
            float page_width = page.getWidth();
            float page_height = page.getHeight();
            RectF rect = new RectF(10, 200, page_width - 10, page_height - 350);
			TableBorderInfo outsideborderinfoleft = new TableBorderInfo();
		    outsideborderinfoleft.setLine_width(2);
			TableBorderInfo outsideborderinforight = new TableBorderInfo();
		    outsideborderinforight.setLine_width(2);
			TableBorderInfo outsideborderinfotop = new TableBorderInfo();
		    outsideborderinfotop.setLine_width(2);
			TableBorderInfo outsideborderinfobottom = new TableBorderInfo();
		    outsideborderinfobottom.setLine_width(2);
			TableBorderInfo insideborderinfo_row = new TableBorderInfo();
			insideborderinfo_row.setLine_width(2);
		    TableBorderInfo insideborderinfo_col = new TableBorderInfo();
			insideborderinfo_col.setLine_width(2);
            TableData data = new TableData(rect, 5, 6, outsideborderinfoleft, outsideborderinforight, outsideborderinfotop,outsideborderinfobottom, insideborderinfo_row, insideborderinfo_col, new TableCellIndexArray(), new FloatArray(), new FloatArray());
            TableGenerator.addTableToPage(page, data, cell_array);
        }
      
    }

    private static void createResultFolder(String output_path) {
        File myPath = new File(output_path);
        if (!myPath.exists()) {
            myPath.mkdir();
        }
    }

    public static void main(String[] args) throws PDFException, IOException {
        createResultFolder(output_path);
        // Initialize Library.
        int error_code = Library.initialize(sn, key);
        if (error_code != e_ErrSuccess) {
            System.out.println(String.format("Library Initialize Error: %d\n", error_code));
            return;
        }

        try {
            PDFDoc doc = new PDFDoc();
            PDFPage page = doc.insertPage(0, PDFPage.e_SizeLetter);
            AddElectronicTable(page);
            String output_file = output_path + "electronictable_result.pdf";
            doc.saveAs(output_file, PDFDoc.e_SaveFlagNoOriginal);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
        System.out.println("electronictable demo");
        Library.release();
        return;
    }
}
