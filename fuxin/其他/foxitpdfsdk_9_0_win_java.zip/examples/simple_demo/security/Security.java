// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to do encryption and decryption for a PDF file
// by using password security method, custom security method, Foxit DRM security method, certificate security method
// or Microsoft RMS security method.

import static com.foxit.sdk.common.Constants.e_ErrSuccess;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Random;

import com.foxit.sdk.common.Library;
import com.foxit.sdk.pdf.CertificateEncryptData;
import com.foxit.sdk.pdf.CertificateSecurityCallback;
import com.foxit.sdk.pdf.CertificateSecurityHandler;
import com.foxit.sdk.pdf.CustomEncryptData;
import com.foxit.sdk.pdf.CustomSecurityHandler;
import com.foxit.sdk.pdf.DRMEncryptData;
import com.foxit.sdk.pdf.DRMSecurityHandler;
import com.foxit.sdk.pdf.PDFDoc;
import com.foxit.sdk.pdf.RMSEncryptData;
import com.foxit.sdk.pdf.RMSSecurityCallback;
import com.foxit.sdk.pdf.RMSSecurityHandler;
import com.foxit.sdk.pdf.SecurityHandler;
import com.foxit.sdk.pdf.StdEncryptData;
import com.foxit.sdk.pdf.StdSecurityHandler;

public class Security {
    static final String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
    static final String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
    static final String output_path = "../output_files/";
    static final String input_path = "../input_files/";

    static final String output_directory = output_path + "security/";

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
       String os = System.getProperty("os.name").toLowerCase();
       String lib = "fsdk_java_";
       if (os.startsWith("win")) {
           lib += "win";
       } else if (os.startsWith("mac")) {
           lib += "mac";
       } else {
           lib += "linux";
       }
       if (System.getProperty("sun.arch.data.model").equals("64")) {
           if(System.getProperty("os.arch").equals("aarch64")){
               lib += "arm";
           }
           else{
               lib += "64";
           }
       } else {
           lib += "32";
       }
       System.loadLibrary(lib);
    }

    static void certificateSecurity(String input_file) {
        Random rand = new Random(23);
        byte[] seed = new byte[24];
        rand.nextBytes(seed);
        for (int i = 20; i < 24; i++) {
            seed[i] = (byte) 0xFF;
        }

        try {
            PDFDoc doc = new PDFDoc(input_file);
            int error_code = doc.load(null);
            if (error_code != e_ErrSuccess) {
                System.out.println("The Doc " + input_file + " Error: " + error_code);
                return;
            }

            // Do encryption.
            String cert_file_path = input_path + "foxit.cer";
            ArrayList<byte[]> envelopes = new ArrayList<byte[]>();
            byte[] bytes=null;
            try {
                bytes = CryptUtil.encryptByKey(seed, CryptUtil.getPublicKey(cert_file_path));
                envelopes.add(bytes);
            } catch (Exception e) {
                System.out.println("[Failed] Cannot get certificate information from " + cert_file_path);
                return;
            }
            byte[] data=new byte[20+bytes.length];
            System.arraycopy(seed, 0, data, 0, 20);
            System.arraycopy(bytes, 0, data, 20, bytes.length);
            MessageDigest messageDigest = MessageDigest.getInstance("SHA1");  
            messageDigest.update(data);  
            byte[] initial_key = new byte[16];
            System.arraycopy(messageDigest.digest(),0,initial_key,0,16);  
            CertificateSecurityHandler handler = new CertificateSecurityHandler();
            CertificateEncryptData encrypt_data = new CertificateEncryptData(true, SecurityHandler.e_CipherAES,
                    envelopes);
            handler.initialize(encrypt_data, initial_key);

            doc.setSecurityHandler(handler);
            String output_file = output_directory + "certificate_encrypt.pdf";
            doc.saveAs(output_file, PDFDoc.e_SaveFlagNoOriginal);

            // Do decryption.
            CertificateSecurityCallback callback = new CertificateSecurityEvent(input_path + "foxit_all.pfx", "123456");
            Library.registerSecurityCallback("Adobe.PubSec", callback);

            PDFDoc encrypted_doc = new PDFDoc(output_file);
            error_code = encrypted_doc.load(null);
            if (error_code != e_ErrSuccess) {
                System.out.println("The Doc " + output_file + " Error: " + error_code);
                return;
            }

            output_file = output_directory + "certificate_decrypt.pdf";
            encrypted_doc.removeSecurity();
            encrypted_doc.saveAs(output_file, PDFDoc.e_SaveFlagNoOriginal);
			handler.delete();
			doc.delete();
			encrypted_doc.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void foxitDRMDecrypt(String input_file) {
        try {
            PDFDoc doc = new PDFDoc(input_file);
            int error_code = doc.load(null);
            if (error_code != e_ErrSuccess) {
                System.out.println("The Doc " + input_file + " Error: " + error_code);
                return;
            }

            // Do encryption.
            DRMSecurityHandler handler = new DRMSecurityHandler();
            String file_id = "Simple-DRM-file-ID";
            String initialize_key = "Simple-DRM-initialize-key";
            DRMEncryptData encrypt_data = new DRMEncryptData(true, "Simple-DRM-filter", SecurityHandler.e_CipherAES, 16,
                    true, 0xfffffffc);
            handler.initialize(encrypt_data, file_id, initialize_key);
            doc.setSecurityHandler(handler);

            String output_file = output_directory + "foxit_drm_encrypt.pdf";
            doc.saveAs(output_file, PDFDoc.e_SaveFlagNoOriginal);

            // Do decryption.
            DRMSecurityEvent callback = new DRMSecurityEvent(file_id, toChars(initialize_key));
            Library.registerSecurityCallback("FoxitDRM", callback);
            PDFDoc encrypted_doc = new PDFDoc(output_file);
            error_code = encrypted_doc.load(null);
            if (error_code != e_ErrSuccess) {
                System.out.println("The Doc " + output_file + " Error: " + error_code);
                return;
            }

            output_file = output_directory + "foxit_drm_decrypt.pdf";

            encrypted_doc.removeSecurity();
            encrypted_doc.saveAs(output_file, PDFDoc.e_SaveFlagNoOriginal);
			handler.delete();
			doc.delete();
			encrypted_doc.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void customSecurity(String input_file) {
        try {
            PDFDoc doc = new PDFDoc(input_file);
            int error_code = doc.load(null);
            if (error_code != e_ErrSuccess) {
                System.out.println("The Doc " + input_file + " Error: " + error_code);
                return;
            }

            // Do encryption.
            CustomSecurityEvent callback = new CustomSecurityEvent();
            CustomSecurityHandler handler = new CustomSecurityHandler();
            final String encrypt_info = "Foxit simple demo custom security";
            CustomEncryptData encrypt_data = new CustomEncryptData(true, "Custom", "foxit-simple-demo");
            handler.initialize(encrypt_data, callback, encrypt_info);
            doc.setSecurityHandler(handler);
            String output_file = output_directory + "custom_encrypt.pdf";
            doc.saveAs(output_file, PDFDoc.e_SaveFlagNoOriginal);

            // Do decryption.
            Library.registerSecurityCallback("Custom", callback);
            PDFDoc encrypted_doc = new PDFDoc(output_file);

            error_code = encrypted_doc.load(null);
            if (error_code != e_ErrSuccess) {
                System.out.println("The Doc " + output_file + " Error: " + error_code);
                return;
            }

            output_file = output_directory + "custom_decrypt.pdf";
            encrypted_doc.removeSecurity();
            encrypted_doc.saveAs(output_file, PDFDoc.e_SaveFlagNoOriginal);
			handler.delete();
			doc.delete();
			encrypted_doc.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void rmsSecurity(String input_file) {
        try {
            PDFDoc doc = new PDFDoc(input_file);
            int error_code = doc.load(null);
            if (error_code != e_ErrSuccess) {
                System.out.println("The Doc " + input_file + " Error: " + error_code);
                return;
            }

            // Do encryption.
            RMSSecurityCallback callback = new RMSSecurityEvent(toChars("Simple-RMS-encrpty-key"));
            RMSSecurityHandler handler = new RMSSecurityHandler();
            ArrayList<byte[]> server_eul_list = new  ArrayList<byte[]>();
            server_eul_list.add(toChars("WM-1"));
            server_eul_list.add(toChars("This document has been encrypted by RMS encryption."));
            server_eul_list.add(toChars("WM-2"));
            server_eul_list.add(toChars("Just for simple demo rms security."));
            RMSEncryptData encrypt_data = new RMSEncryptData(true, "PubishLicense_0123", server_eul_list, 1);
            handler.initialize(encrypt_data, callback);
            doc.setSecurityHandler(handler);
            String output_file = output_directory + "rms_encrypt.pdf";
            doc.saveAs(output_file, PDFDoc.e_SaveFlagNoOriginal);

            // Do decryption.
            Library.registerSecurityCallback("MicrosoftIRMServices", callback);
            PDFDoc encrypted_doc = new PDFDoc(output_file);
            error_code = encrypted_doc.load(null);
            if (error_code != e_ErrSuccess) {
                System.out.println("The Doc " + output_file + " Error: " + error_code);
                return;
            }

            output_file = output_directory + "rms_decrypt.pdf";
            encrypted_doc.removeSecurity();
            encrypted_doc.saveAs(output_file, PDFDoc.e_SaveFlagNoOriginal);
			handler.delete();
			doc.delete();
			encrypted_doc.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void stdSecurity(String input_file) {
        try {
            PDFDoc doc = new PDFDoc(input_file);
            int error_code = doc.load(null);
            if (error_code != e_ErrSuccess) {
                System.out.println("The Doc " + input_file + " Error: " + error_code);
                return;
            }

            // Do encryption.
            StdSecurityHandler handler = new StdSecurityHandler();
            StdEncryptData encrypt_data = new StdEncryptData(true, 0xfffffffc, SecurityHandler.e_CipherAES, 16);
            handler.initialize(encrypt_data, toChars("user"), toChars("owner"));
            doc.setSecurityHandler(handler);

            String output_file = output_directory + "std_encrypt_userpwd[user]_ownerpwd[owner].pdf";
            doc.saveAs(output_file, PDFDoc.e_SaveFlagNoOriginal);

            // Do decryption.
            PDFDoc encrypted_doc = new PDFDoc(output_file);
            error_code = encrypted_doc.load(toChars("owner"));
            if (error_code != e_ErrSuccess) {
                System.out.println("The Doc " + output_file + " Error: " + error_code);
                return;
            }

            encrypted_doc.removeSecurity();
            output_file = output_directory + "std_decrypt.pdf";
            encrypted_doc.saveAs(output_file, PDFDoc.e_SaveFlagNoOriginal);
			handler.delete();
			doc.delete();
			encrypted_doc.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void securityImpl(String pdf_file) {
         certificateSecurity(pdf_file);
         foxitDRMDecrypt(pdf_file);
         customSecurity(pdf_file);
         rmsSecurity(pdf_file);
         stdSecurity(pdf_file);
    }

    public static void main(String[] args) {

        createResultFolder(output_directory);
        // Initialize library
        int error_code = Library.initialize(sn, key);
        if (error_code != e_ErrSuccess) {
            System.out.println("Library Initialize Error: " + error_code);
            return;
        }

        String input_file = input_path + "AboutFoxit.pdf";
        securityImpl(input_file);
        Library.release();

        System.out.println("Security demo test.");
    }

    private static byte[] toChars(String value) throws UnsupportedEncodingException {
        return value.getBytes("ASCII");
    }

    private static void createResultFolder(String output_path) {
        File directory = new File(output_path);
        if (!directory.exists()) {
            directory.mkdir();
        }
    }
}
