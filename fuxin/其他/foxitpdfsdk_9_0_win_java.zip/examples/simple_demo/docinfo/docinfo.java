// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to get/set attributes of viewer preference
// and values of metadata in a PDF file.

import java.io.File;

import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.*;
import com.foxit.sdk.pdf.*;


import java.util.Calendar;
import java.io.FileWriter;
import java.io.IOException;

import static com.foxit.sdk.common.Constants.e_ErrSuccess;
import static com.foxit.sdk.pdf.PDFPage.*;
import static com.foxit.sdk.pdf.PDFDoc.*;
import static com.foxit.sdk.pdf.DocViewerPrefs.*;

public class docinfo {
    private static String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
    private static String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
    private static String output_path = "../output_files/docinfo/";
    private static String input_path = "../input_files/";
    private static String[] kMetadataItems = {"Title", "Author", "Subject", "Keywords",
            "Creator", "Producer", "CreationDate", "ModDate"};
    private static String[] kDisplayModeStrings = {"UseNone", "UseOutlines", "UseThumbs", "FullScreen", "UseOC", "UseAttachment"};
    private static int[] kUIItems = {e_HideToolbar, e_HideMenubar, e_HideWindowUI, e_FitWindow,
            e_CenterWindow, e_DisplayDocTitle};
    private static int[] kDisplayModes = {e_DisplayUseNone, e_DisplayUseOutlines, e_DisplayUseThumbs,
            e_DisplayFullScreen, e_DisplayUseOC, e_DisplayUseAttachment};

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
        String os = System.getProperty("os.name").toLowerCase();
        String lib = "fsdk_java_";
        if (os.startsWith("win")) {
            lib += "win";
        } else if (os.startsWith("mac")) {
            lib += "mac";
        } else {
            lib += "linux";
        }
        if (System.getProperty("sun.arch.data.model").equals("64")) {
            if(System.getProperty("os.arch").equals("aarch64")){
                lib += "arm";
            }
            else{
                lib += "64";
            }
        } else {
            lib += "32";
        }
        System.loadLibrary(lib);
    }

    private static void createResultFolder(String output_path) {
        File myPath = new File(output_path);
        if (!myPath.exists()) {
            myPath.mkdir();
        }
    }

    private static DateTime GetLocalDateTime() {
        Calendar c = Calendar.getInstance();

        DateTime datetime = new DateTime();
        datetime.setYear(c.get(Calendar.YEAR));
        datetime.setMonth(c.get(Calendar.MONTH) + 1);
        datetime.setDay(c.get(Calendar.DATE));
        datetime.setHour(c.get(Calendar.HOUR));
        datetime.setMinute(c.get(Calendar.MINUTE));
        datetime.setSecond(c.get(Calendar.SECOND));
        
        java.util.TimeZone timeZone = c.getTimeZone();
        int offset = timeZone.getRawOffset();
        int gmt = offset/(3600*1000);
        
        datetime.setUtc_hour_offset((short)gmt);
        datetime.setUtc_minute_offset(offset%(3600*1000) / 60);
        return datetime;
    }

    private static String GetPageBoxName(int type) {
        switch (type) {
            case e_MediaBox:
                return "MediaBox";
            case e_CropBox:
                return "CropBox";
            case e_TrimBox:
                return "TrimBox";
            case e_ArtBox:
                return "ArtBox";
            case e_BleedBox:
                return "BleedBox";
        }
        return "";
    }

    private static String GetViewerPrefName(int ui_item) {
        switch (ui_item) {
            case e_HideToolbar:
                return "HideToolbar";
            case e_HideMenubar:
                return "HideMenubar";
            case e_HideWindowUI:
                return "HideWindowUI";
            case e_FitWindow:
                return "FitWindow";
            case e_CenterWindow:
                return "CenterWindow";
            case e_DisplayDocTitle:
                return "DisplayDocTitle";
        }
        return "";
    }

    private static void ShowDocViewerPrefsInfo(PDFDoc doc, String file_name) throws PDFException, IOException {
        String file_info = output_path + "DocViewerPrefsInfo_" + file_name;
        FileWriter writer = new FileWriter(file_info, false);
        writer.write("Document viewer preferences information:\r\n");

        DocViewerPrefs prefs = new DocViewerPrefs(doc, null);

        // Get UI visibility status.
        for (int i = 0; i < kUIItems.length; i++) {
            String status = (prefs.getUIDisplayStatus(kUIItems[i])) ? "Yes" : "No";
            writer.write("Visibility of " + kUIItems[i] + ":\t" + status + "\r\n");
        }
        // Get display mode for non full-screen mode.
        int mode = prefs.getNonFullScreenPageMode();
        String display_mode = null;
        for (int i = 0; i < kDisplayModes.length; i++) {
            if (mode == kDisplayModes[i]) {
                display_mode = kDisplayModeStrings[i];
                break;
            }
        }
        writer.write("None full screen page mode:\t" + display_mode + "\r\n");
        // Get reading direction.
        String direction = prefs.getReadingDirection() ? "left to right" : "right to left";
        writer.write("Reading direction:\t" + direction + "\r\n");
        // Get the type of area item.
        int type = prefs.getPrintClip();
        writer.write("The GetPrintClip returned:\t" + GetPageBoxName(type) + "\r\n");
        type = prefs.getPrintArea();
        writer.write("The GetPrintArea returned:\t" + GetPageBoxName(type) + "\r\n");
        type = prefs.getViewArea();
        writer.write("The GetViewArea returned:\t" + GetPageBoxName(type) + "\r\n");
        type = prefs.getViewClip();
        writer.write("The GetViewClip returned:\t" + GetPageBoxName(type) + "\r\n");

        // Get page scaling option.
        writer.write("Page scaling option:\t" + prefs.getPrintScale() + "\r\n");
        // Get the number of copies to be printed.
        writer.write("The number of copies to be printed:\t" + prefs.getPrintCopies() + "\r\n");
        // Get page ranges which allowed to print
        writer.write("Page ranges for printing:\r\n");
        Range print_ranges = prefs.getPrintRange();
        if (!print_ranges.isEmpty()) {
            for (int i = 0; i < print_ranges.getSegmentCount(); i = i + 1) {
                writer.write("\tfirst:\t" + print_ranges.getSegmentStart(i) + "\tlast:\t" + print_ranges.getSegmentEnd(i) + "\r\n");
            }
        }
        writer.close();
    }

    private static void SetDocViewerPrefsInfo(PDFDoc doc) throws PDFException, IOException {

        doc.setDisplayMode(e_DisplayFullScreen);
        DocViewerPrefs prefs = new DocViewerPrefs(doc, null);
        // Set UI visibility status.
        for (int i = 0; i < kUIItems.length; i++) {
            prefs.setUIDisplayStatus(kUIItems[i], true);
        }
        // Set display mode for non full-screen mode.
        prefs.setNonFullScreenPageMode(e_DisplayUseOutlines);
        // Set reading direction.
        prefs.setReadingDirection(false);
        // Set the type of area item.

        prefs.setViewArea(e_CropBox);
        prefs.setViewClip(e_CropBox);
        prefs.setPrintArea(e_CropBox);
        prefs.setPrintClip(e_CropBox);
        // Set page scaling option.
        prefs.setPrintScale(e_PrintScaleNone);
        // Set the number of copies to be printed.
        prefs.setPrintCopies(4);
        Range print_range = new Range(0, doc.getPageCount() / 2, Range.e_All);
        prefs.setPrintRange(print_range);
    }

    private static void ShowMetaDataInfo(PDFDoc doc, String file_name) throws PDFException, IOException {
        String output_file = output_path + "MetaDataInfo_" + file_name;
        FileWriter writer = new FileWriter(output_file, false);
        writer.write("Metadata information:\r\n");
        Metadata metadata = new Metadata(doc);
        for (int i = 0; i < kMetadataItems.length; i++) {
            writer.write(kMetadataItems[i] + ": ");
            WStringArray value = metadata.getValues(kMetadataItems[i]);
            for (int j = 0; j < value.getSize(); j++) {
                writer.write(value.getAt(j));
            }
            writer.write("\r\n");
        }
        writer.close();
    }

    private static void SetMetaDataInfo(PDFDoc doc) throws PDFException {
        String[] kMetadataValues = {"Title set by simple demo", "Simple demo",
                "Subject set by simple demo", "Keywords set by simple demo",
                "Foxit PDF SDK", "Foxit"};
        Metadata metadata = new Metadata(doc);
        for (int i = 0; i < kMetadataValues.length; i++) {
            WStringArray MetadataValues = new WStringArray();
            MetadataValues.add(kMetadataValues[i]);
            metadata.setValues(kMetadataItems[i], MetadataValues);
        }
        metadata.setCreationDateTime(GetLocalDateTime());
        metadata.setModifiedDateTime(GetLocalDateTime());
    }

    public static void main(String[] args) throws PDFException, IOException {
        createResultFolder(output_path);
        // Initialize Library.
        int error_code = Library.initialize(sn, key);
        if (error_code != e_ErrSuccess) {
            System.out.println(String.format("Library Initialize Error: %d\n", error_code));
            return;
        }

        String input_file = input_path + "AboutFoxit.pdf";

        try {
            PDFDoc doc = new PDFDoc(input_file);
            error_code = doc.load(null);

            if (error_code != e_ErrSuccess) {
                System.out.println(String.format("[Failed] Cannot load PDF document [%s].\r\nError Message: %d\n", input_file, error_code));
                return;
            }

            // Show original information.
            ShowDocViewerPrefsInfo(doc, "original.txt");
            ShowMetaDataInfo(doc, "original.txt");

            // Set information.
            SetDocViewerPrefsInfo(doc);
            SetMetaDataInfo(doc);

            // Show new information.
            ShowDocViewerPrefsInfo(doc, "new.txt");
            ShowMetaDataInfo(doc, "new.txt");

            String output_file = output_path + "AboutFoxit_docinfo.pdf";
            doc.saveAs(output_file, e_SaveFlagNoOriginal);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        Library.release();
        return;
    }
}
