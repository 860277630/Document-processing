// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to generate barcode.

import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.Library;
import com.foxit.sdk.common.Bitmap;
import com.foxit.sdk.common.Image;
import com.foxit.sdk.common.Barcode;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import static com.foxit.sdk.common.Constants.e_ErrSuccess;

public class barcode {
	static String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
	static String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
	static String output_path = "../output_files/barcode/";

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
        String os = System.getProperty("os.name").toLowerCase();
        String lib = "fsdk_java_";
        if (os.startsWith("win")) {
            lib += "win";
        } else if (os.startsWith("mac")) {
            lib += "mac";
        } else {
            lib += "linux";
      	}
        if (System.getProperty("sun.arch.data.model").equals("64")) {
			if(System.getProperty("os.arch").equals("aarch64")){
				lib += "arm";
			}
			else{
				lib += "64";
			}
        } else {
            lib += "32";
        }
        System.loadLibrary(lib);
    }

	private static void createResultFolder(String output_path) {
		File myPath = new File(output_path);
		if (!myPath.exists()) {
			myPath.mkdir();
		}
	}

	private static void Save2Image(Bitmap bitmap, String filepath) throws PDFException {
		// Add the bitmap to image and save the image.
		Image image = new Image();
		image.addFrame(bitmap);
		String save_name = output_path + filepath;
		image.saveAs(save_name);
	}
	
	// Generate barcode in different type and save each of them as an image file.
	public static void Barcode_GenerateEachType(String codeStr, int codeFormat, int unitWidth, int unitHeight, int qrLevel, String bmpName) {
		try {
			Barcode barcode = new Barcode();
			Bitmap bitmap = barcode.generateBitmap(codeStr, codeFormat, unitWidth, unitHeight, qrLevel);
			Save2Image(bitmap, bmpName);
		} catch (Exception e) {
		  e.printStackTrace();
		}
	}

	// Generate all types of barcode and save each of them as an image file.
	public static void Barcode_GenerateAll() {
		// Strings used as barcode content.
		String[] codeStr = {"TEST-SHEET", "102030405060708090", "80674313", "890444000335", "9780804816632", "070429", "Unknown - change me!", "TestForBarcodeQrCode"};
		// Barcode format types
		int[] codeFormat = {Barcode.e_FormatCode39, Barcode.e_FormatCode128,
			Barcode.e_FormatEAN8, Barcode.e_FormatUPCA, 
			Barcode.e_FormatEAN13, Barcode.e_FormatITF, 
			Barcode.e_FormatPDF417, Barcode.e_FormatQRCode};

		// Image names for the saved image files.(except QR code)
		String[] bmpName = {"/code39_TEST-SHEET.bmp", "/CODE_128_102030405060708090.bmp",
			"/EAN_8_80674313.bmp", "/UPC_A_890444000335.bmp", "/EAN_13_9780804816632.bmp",
			"/ITF_070429.bmp", "/PDF_417_Unknown.bmp"};

		//Format error correction level of QR code.
		int[] qrLevel = {Barcode.e_QRCorrectionLevelLow, Barcode.e_QRCorrectionLevelMedium, 
			Barcode.e_QRCorrectionLevelQuater, Barcode.e_QRCorrectionLevelHigh};
		//Image names for the saved image files for QR code.
		String[] bmpQrName = {"/QR_CODE_TestForBarcodeQrCode_L.bmp", "/QR_CODE_TestForBarcodeQrCode_M.bmp",
			"/QR_CODE_TestForBarcodeQrCode_Q.bmp", "/QR_CODE_TestForBarcodeQrCode_H.bmp"};

		//Unit width for barcode in pixels, preferred value is 1-5 pixels.
		int unitWidth = 2;
		//Unit height for barcode in pixels, preferred value is >= 20 pixels.
		int unitHeight = 120;

		// Generate barcode for different types.
		for (int i = 0; i < 8; i++) {
			if (codeFormat[i] != Barcode.e_FormatQRCode)  // Not QR code
				Barcode_GenerateEachType(codeStr[i], codeFormat[i], unitWidth, unitHeight, 0, bmpName[i]);
			else {
				// QR code
				//Generate for each format error correction level.
				for (int j = 0; j < 4; j++)
					Barcode_GenerateEachType(codeStr[i], codeFormat[i], unitWidth, unitHeight, qrLevel[j], bmpQrName[j]);
			}
		}
	}
		
	public static void main(String[] args) throws PDFException, IOException {
		createResultFolder(output_path);
		// Initialize library.
		int error_code = Library.initialize(sn, key);
		if (error_code != e_ErrSuccess) {
			System.out.println(String.format("Library Initialize Error: %d\n", error_code));
			return;
		}

		try {
			// Generate all types of barcode
			Barcode_GenerateAll();
			System.out.println("Barcode demo.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		Library.release();
		return;
	}

}
