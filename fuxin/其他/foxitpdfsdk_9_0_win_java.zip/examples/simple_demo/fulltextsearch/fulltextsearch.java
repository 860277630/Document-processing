// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to do full text search in PDF documents under a folder.

import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.Bitmap;
import com.foxit.sdk.common.Image;
import com.foxit.sdk.common.Library;
import com.foxit.sdk.common.Renderer;
import com.foxit.sdk.common.fxcrt.*;
import com.foxit.sdk.pdf.PDFDoc;
import com.foxit.sdk.pdf.PDFPage;
import com.foxit.sdk.fts.*;
import com.foxit.sdk.common.*;
	
import java.io.*;
import java.io.File;
import java.io.FileWriter;
import java.util.Date; 
	
import static com.foxit.sdk.common.Bitmap.e_DIBArgb;
import static com.foxit.sdk.common.Constants.e_ErrSuccess;
import static com.foxit.sdk.pdf.PDFPage.e_ParsePageNormal;

public class fulltextsearch {
    private static String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
    private static String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
    private static String output_path = "../output_files/fulltextsearch/";
    private static String input_path = "../input_files/fulltextsearch";

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
      String os = System.getProperty("os.name").toLowerCase();
      String lib = "fsdk_java_";
      if (os.startsWith("win")) {
          lib += "win";
      } else if (os.startsWith("mac")) {
          lib += "mac";
      } else {
          lib += "linux";
      }
      if (System.getProperty("sun.arch.data.model").equals("64")) {
          if(System.getProperty("os.arch").equals("aarch64")){
              lib += "arm";
          }
          else{
              lib += "64";
          }
      } else {
          lib += "32";
      }
      System.loadLibrary(lib);
    }

    private static void createResultFolder(String output_path) {
		File myPath = new File(output_path);
		if (!myPath.exists()) {
			myPath.mkdir();
		}
	}
    public static void main(String[] args) throws PDFException {
        //  createResultFolder(output_path);
        // Initialize library
        int error_code = Library.initialize(sn, key);
        if (error_code != e_ErrSuccess) {
            System.out.println("Library Initialize Error: " + error_code);
            return;
        }
        String directory = input_path;
        FullTextSearch search = new FullTextSearch();
        try {
              createResultFolder(output_path);
            String dbPath = output_path + "search.db";
            search.setDataBasePath(dbPath);
            // Get document source information.
            DocumentsSource source = new DocumentsSource(directory);
         
            // Create a Pause callback object implemented by users to pause the updating process.
            PauseUtil pause = new PauseUtil(30);
         
            // Start to update the index of PDF files which receive from the source.
            Progressive progressive = search.startUpdateIndex(source, pause, false);
            int state = Progressive.e_ToBeContinued;
            while (state == Progressive.e_ToBeContinued) {
                state = progressive.resume();
            }
         
            // Create a callback object which will be invoked when a matched one is found.
            MySearchCallback searchCallback = new MySearchCallback(output_path + "result.txt");
         
            // Search the specified keyword from the indexed data source.
            search.searchOf("Foxit", FullTextSearch.e_RankHitCountASC, searchCallback);
			System.out.println("FullTextSearch demo.");
        } catch (PDFException e) {
            e.printStackTrace();
        }
        
        Library.release();
    }

}

class MySearchCallback extends SearchCallback {
    private static final String TAG = MySearchCallback.class.getCanonicalName();
	private FileWriter text_doc_ = null;

	public MySearchCallback(String output_txt_file_path) {
		try {
			text_doc_ = new FileWriter(output_txt_file_path, false);
		} catch(IOException e) {
			System.out.println(String.format("[FAILED] Failed to create a txt file. TXT path:%s\r\n", output_txt_file_path));
			e.printStackTrace();
		}
	}
 
    @Override
    public void release() {
		try {
			if (null != text_doc_)
				text_doc_.close();
		} catch(IOException e) {
		}
    }
 
    @Override
    public int retrieveSearchResult(String filePath, int pageIndex, String matchResult, int matchStartTextIndex, int matchEndTextIndex) {
		try {
			String result_str = String.format("RetrieveSearchResult:\nFound file is: %s\nPage index is: %d\nStart text index: %d\nEnd text index: %d\nMatch is: %s\n", filePath, pageIndex, matchStartTextIndex, matchEndTextIndex, matchResult);
			text_doc_.write(result_str);
			text_doc_.write("\r\n");
		} catch(IOException e) {
			
		}
        return 0;
    }
}

class PauseUtil extends PauseCallback{
    private long m_milliseconds = 0;
    private long m_startTime = 0;
 
    public PauseUtil(long milliSeconds) {
        Date date = new Date();
        m_milliseconds = milliSeconds;
        m_startTime = date.getTime();
    }
 
    @Override
    public boolean needToPauseNow() {
        // TODO Auto-generated method stub
        if (this.m_milliseconds < 1)
            return false;
        Date date = new Date();
        long diff = date.getTime() - m_startTime;
        if (diff > this.m_milliseconds) {
            m_startTime = date.getTime();
            return true;
        } else
            return false;
    }
}