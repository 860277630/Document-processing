// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to enumerate and modify bookmarks
// in PDF document.

import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.Library;
import com.foxit.sdk.pdf.Bookmark;
import com.foxit.sdk.pdf.PDFDoc;
import com.foxit.sdk.pdf.actions.Destination;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import static com.foxit.sdk.common.Constants.e_ErrSuccess;
import static com.foxit.sdk.pdf.Bookmark.e_PosLastChild;
import static com.foxit.sdk.pdf.Bookmark.e_StyleItalic;
import static com.foxit.sdk.pdf.PDFDoc.e_SaveFlagNoOriginal;

public class bookmark {


    static String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
    static String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
    static String output_path = "../output_files/bookmark/";
    static String input_path = "../input_files/";

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
        String os = System.getProperty("os.name").toLowerCase();
        String lib = "fsdk_java_";
        if (os.startsWith("win")) {
            lib += "win";
        } else if (os.startsWith("mac")) {
            lib += "mac";
        } else {
            lib += "linux";
        }
        if (System.getProperty("sun.arch.data.model").equals("64")) {
            if(System.getProperty("os.arch").equals("aarch64")){
                lib += "arm";
            }
            else{
                lib += "64";
            }
        } else {
            lib += "32";
        }
        System.loadLibrary(lib);
    }

    private static void createResultFolder(String output_path) {
        File myPath = new File(output_path);
        if (!myPath.exists()) {
            myPath.mkdir();
        }
    }

    static void showBookmarkInfo(Bookmark bookmark, FileWriter doc, int depth) throws PDFException, IOException {
        if (depth > 32)
            return;
        if (bookmark.isEmpty())
            return;
        for (int i = 0; i < depth; i++) {
            doc.write("\t");
        }
        // Show bookmark's title.
        doc.write(String.format("%s\t", bookmark.getTitle()));

        // Show bookmark's color.
        doc.write(String.format("color: %x\r\n", bookmark.getColor()));
        showBookmarkInfo(bookmark.getFirstChild(), doc, depth + 1);
        showBookmarkInfo(bookmark.getNextSibling(), doc, depth);
    }

    static void showBookmarksInfo(PDFDoc doc, String info_path) throws IOException, PDFException {
        FileWriter text_doc = new FileWriter(info_path, false);
        Bookmark root = doc.getRootBookmark();
        if (!root.isEmpty()) {
            showBookmarkInfo(root, text_doc, 0);
        } else {
            text_doc.write("No bookmark information!\r\n");
        }
        text_doc.close();
    }


    public static void main(String[] args) throws PDFException, IOException {
        createResultFolder(output_path);
        // Initialize library
        int error_code = Library.initialize(sn, key);
        if (error_code != e_ErrSuccess) {
            System.out.println(String.format("Library Initialize Error: %d\n", error_code));
            return;
        }

        String input_file = input_path + "AboutFoxit.pdf";
        String output_file1 = output_path + "bookmark_add.pdf";
        String output_file2 = output_path + "bookmark_change.pdf";
        String bookmark_info_file = output_path + "bookmark_info.txt";

        try {
            PDFDoc doc = new PDFDoc(input_file);
            error_code = doc.load(null);
            if (error_code != e_ErrSuccess) {
                System.out.println(String.format("The Doc [%s] Error: %d\n", input_file, error_code));
                return;
            }

            // Show original bookmark information.
            showBookmarksInfo(doc, bookmark_info_file);

            // Get bookmark root node or Create new bookmark root node.
            Bookmark root = doc.getRootBookmark();
            if (root.isEmpty()) {
                root = doc.createRootBookmark();
            }
            for (int i = 0; i < doc.getPageCount(); i += 2) {
                Destination dest = Destination.createFitPage(doc, i);

                String ws_title = String.format("A bookmark to a page (index: %d)", i);
                Bookmark child = root.insert(ws_title,
                        e_PosLastChild);
                child.setDestination(dest);
                child.setColor(i * 0xF68C21);
            }
            doc.saveAs(output_file1, e_SaveFlagNoOriginal);

            // Get first bookmark and change properties.
            Bookmark first_bookmark = root.getFirstChild();
            first_bookmark.setStyle(e_StyleItalic);
            first_bookmark.setColor(0xFF0000);
            first_bookmark.setTitle("Change bookmark title, style, and color");

            // Remove next sibling bookmark
            if (!first_bookmark.getNextSibling().isEmpty()) {
                doc.removeBookmark(first_bookmark.getNextSibling());
            }

            bookmark_info_file = output_path + "bookmark_info1.txt";
            showBookmarksInfo(doc, bookmark_info_file);

            doc.saveAs(output_file2, e_SaveFlagNoOriginal);
            System.out.println("Bookmark demo.");


        } catch (Exception e) {
            e.printStackTrace();

        }
        Library.release();
        return;
    }

}
