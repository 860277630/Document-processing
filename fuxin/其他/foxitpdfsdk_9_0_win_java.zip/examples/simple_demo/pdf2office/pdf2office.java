// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to convert PDF files to Office(Word, Excel or PowerPoint) format files.

import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.Library;
import com.foxit.sdk.common.Progressive;
import com.foxit.sdk.common.fxcrt.FileReaderCallback;
import com.foxit.sdk.common.fxcrt.StreamCallback;
import com.foxit.sdk.addon.conversion.pdf2office.PDF2Office;
import com.foxit.sdk.addon.conversion.pdf2office.ConvertCallback;
import com.foxit.sdk.addon.conversion.pdf2office.PDF2OfficeSettingData;
import java.io.*;

import static com.foxit.sdk.common.Constants.e_ErrSuccess;
import static com.foxit.sdk.common.Constants.e_ErrInvalidLicense;
import static com.foxit.sdk.common.Constants.e_ErrNoPDF2OfficeModuleRight;

class CustomConvertCallback extends ConvertCallback {
  CustomConvertCallback() {}

  @Override
  public boolean needToPause() {
    return true;
  }

  @Override
  public void progressNotify(int converted_count, int total_count) {
  }
}

class FileReader extends FileReaderCallback {
    private RandomAccessFile file_ = null;

    FileReader() {
    }

    boolean LoadFile(String file_path) throws FileNotFoundException {
        file_ = new RandomAccessFile(file_path, "r");
        return true;
    }

    @Override
    public long getSize() {
		try {
			return this.file_.length();
		} catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }

    @Override
    public boolean readBlock(byte[] buffer, long offset, long size) {
        try {
            file_.seek(offset);
            int read = file_.read(buffer, 0, (int) size);
            return read == size ? true : false;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void release() {
        try {
            this.file_.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class FileStream extends StreamCallback {
    private RandomAccessFile file_ = null;
    private long cur_pos_ = 0;
	private int ref_ = 0;
	
    boolean LoadFile(String file_path) throws FileNotFoundException {
        File path_file = new File(file_path);
        if(path_file.exists() == true) path_file.delete();
        file_ = new RandomAccessFile(file_path, "rw");
        return true;
    }

    @Override
    public long getSize() {
        try {
            return this.file_.length();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public boolean writeBlock(byte[] buffer, long offset, long size) {
        try {
            file_.seek(offset);
            file_.write(buffer, 0, (int) size);
			cur_pos_ = offset + size;
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean readBlock(byte[] buffer, long offset, long size) {
        try {
            file_.seek(offset);
            int read = file_.read(buffer, 0, (int) size);
			cur_pos_ = offset + size;
            return read == size ? true : false;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public long readBlock(byte[] buffer, long size) {
      return readBlock(buffer, 0 , size) ? size : 0;
    }


    @Override
    public boolean flush() {
        return true;
    }

    @Override	
    public StreamCallback retain() {
        ref_++;
		return this;
    }
 
    @Override 
	public boolean isEOF() {
        try {
            return cur_pos_ > this.file_.length() ? true:false;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override 
    public long getPosition() {
      return cur_pos_;
    }
  
    @Override 
    public void release() {
        try {
            this.file_.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

public class pdf2office {
    private static String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
    private static String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
    private static String output_path = "../output_files/pdf2office/";
    private static String input_path = "../input_files/";

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
      String os = System.getProperty("os.name").toLowerCase();
      String lib = "fsdk_java_";
      if (os.startsWith("win")) {
          lib += "win";
      } 
      if (System.getProperty("sun.arch.data.model").equals("64")) {
          lib += "64";
      } else {
          lib += "32";
      }
      System.loadLibrary(lib);
    }

    private static void createResultFolder(String output_path) {
        File myPath = new File(output_path);
        if (!myPath.exists()) {
            myPath.mkdir();
        }
    }

    public static void main(String[] args) throws PDFException {
        // Initialize library
        int error_code = Library.initialize(sn, key);
        if (error_code != e_ErrSuccess) {
            if (e_ErrInvalidLicense == error_code)
                System.out.println("[Failed] Current used Foxit PDF Conversion SDK key information is invalid.");
            else
                System.out.println("Library Initialize Error: " + error_code);
            return;
        }

        try {
            createResultFolder(output_path);
            {
				PDF2Office.initialize(""); //Please ensure the path is valid.
                // Convert PDF file to Word format file.
				PDF2OfficeSettingData setting_data = new PDF2OfficeSettingData();
				setting_data.setMetrics_data_folder_path(""); //Please ensure the path is valid.
				CustomConvertCallback callback = new CustomConvertCallback();
                Progressive progressive = PDF2Office.startConvertToWord(input_path + "word.pdf", null, output_path + "pdf2word_result.docx", setting_data, callback);
                if (progressive.getRateOfProgress() != 100)
                {
					int state = Progressive.e_ToBeContinued;
                    while (Progressive.e_ToBeContinued == state)
                    {
                        state = progressive.resume();
                    }
                }
                System.out.println("Convert PDF file to Word format file.");

				FileReader file_read_word = new FileReader();
				file_read_word.LoadFile(input_path + "word.pdf");
				FileStream file_stream_word = new FileStream();
				file_stream_word.LoadFile(output_path + "pdf2word_stream_result.docx");
                progressive = PDF2Office.startConvertToWord(file_read_word, null, file_stream_word, setting_data, callback);
                if (progressive.getRateOfProgress() != 100)
                {
					int state = Progressive.e_ToBeContinued;
                    while (Progressive.e_ToBeContinued == state)
                    {
                        state = progressive.resume();
                    }
                }
                System.out.println("Convert PDF file to Word format file with stream.");
				
                // Convert PDF file to Excel format file.
                progressive = PDF2Office.startConvertToExcel(input_path + "excel.pdf", null, output_path + "pdf2excel_result.xlsx", setting_data, callback);
                if (progressive.getRateOfProgress() != 100)
                {
					int state = Progressive.e_ToBeContinued;
                    while (Progressive.e_ToBeContinued == state)
                    {
                        state = progressive.resume();
                    }
                }
                System.out.println("Convert PDF file to Excel format file.");
				
				FileReader file_read_excel = new FileReader();
				file_read_excel.LoadFile(input_path + "excel.pdf");
				FileStream file_stream_excel = new FileStream();
				file_stream_excel.LoadFile(output_path + "pdf2excel_stream_result.xlsx");
                progressive = PDF2Office.startConvertToExcel(file_read_excel, null, file_stream_excel, setting_data, callback);
                if (progressive.getRateOfProgress() != 100)
                {
					int state = Progressive.e_ToBeContinued;
                    while (Progressive.e_ToBeContinued == state)
                    {
                        state = progressive.resume();
                    }
                }
                System.out.println("Convert PDF file to Excel format file with stream.");
				
				// Convert PDF file to PowerPoint format file.
                progressive = PDF2Office.startConvertToPowerPoint(input_path + "powerpoint.pdf", null, output_path + "pdf2powerpoint_result.pptx", setting_data, callback);
                if (progressive.getRateOfProgress() != 100)
                {
					int state = Progressive.e_ToBeContinued;
                    while (Progressive.e_ToBeContinued == state)
                    {
                        state = progressive.resume();
                    }
                }
                System.out.println("Convert PDF file to PowerPoint format file.");
				
				FileReader file_read_ppt = new FileReader();
				file_read_ppt.LoadFile(input_path + "powerpoint.pdf");
				FileStream file_stream_ppt = new FileStream();
				file_stream_ppt.LoadFile(output_path + "pdf2powerpoint_stream_result.pptx");
                progressive = PDF2Office.startConvertToPowerPoint(file_read_ppt, null, file_stream_ppt, setting_data, callback);
                if (progressive.getRateOfProgress() != 100)
                {
					int state = Progressive.e_ToBeContinued;
                    while (Progressive.e_ToBeContinued == state)
                    {
                        state = progressive.resume();
                    }
                }
                System.out.println("Convert PDF file to PowerPoint format file with stream.");
				PDF2Office.release();
            }
        } catch (PDFException e) {
            int last_error = e.getLastError();
            switch (last_error) {
                case e_ErrNoPDF2OfficeModuleRight:
                    System.out.println("[Failed] Conversion module is not contained in current Foxit PDF Conversion SDK keys.");
                    break;
                default:
                    System.out.println(e.getMessage());
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Library.release();
    }
}
