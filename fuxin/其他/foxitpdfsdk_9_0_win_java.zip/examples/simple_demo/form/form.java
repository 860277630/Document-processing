// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to add form field and
// get form field information.

import com.foxit.sdk.pdf.interform.Form;
import com.foxit.sdk.pdf.PDFDoc;
import com.foxit.sdk.pdf.PDFPage;
import com.foxit.sdk.pdf.annots.Annot;
import com.foxit.sdk.pdf.annots.DefaultAppearance;
import com.foxit.sdk.pdf.annots.Widget;
import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.Font;
import com.foxit.sdk.common.Library;
import com.foxit.sdk.common.WStringArray;
import com.foxit.sdk.common.fxcrt.RectF;
import com.foxit.sdk.pdf.interform.ChoiceOptionArray;
import com.foxit.sdk.pdf.interform.Control;
import com.foxit.sdk.pdf.interform.Field;
import com.foxit.sdk.pdf.interform.ChoiceOption;
import com.foxit.sdk.pdf.actions.*;
import com.foxit.sdk.common.Constants;
import java.io.File;

public class form {

	static void AddInteractiveForms(PDFPage page, Form form) {
		{
			// Add push button field.
			Control btn_submit = null;
			try {
				btn_submit = form.addControl(page, "Push Button Submit", Field.e_TypePushButton,
						new RectF(50, 750, 150, 780));
			} catch (PDFException e) {
				e.printStackTrace();
			}
			// Set default Appearance
			DefaultAppearance default_ap = new DefaultAppearance();
			default_ap.setFlags(DefaultAppearance.e_FlagFont | DefaultAppearance.e_FlagFontSize
					| DefaultAppearance.e_FlagTextColor);
			try {
				default_ap.setFont(new Font(Font.e_StdIDHelveticaB));
			} catch (PDFException e) {
				e.printStackTrace();
			}
			default_ap.setText_size(12f);
			default_ap.setText_color(0x000000);
			try {
				form.setDefaultAppearance(default_ap);
			} catch (PDFException e) {
				e.printStackTrace();
			}

			// Set push button appearance.
			Widget widget = null;
			try {
				widget = btn_submit.getWidget();
				widget.setHighlightingMode(Annot.e_HighlightingPush);
				widget.setMKBorderColor(0xFF0000);
				widget.setMKBackgroundColor(0xF0F0F0);
				widget.setMKNormalCaption("Submit");
				widget.resetAppearanceStream();
			} catch (PDFException e) {
				e.printStackTrace();
			}

			// Set submit form action.
			try {
				SubmitFormAction submit_action = new SubmitFormAction(Action.create(form.getDocument(), Action.e_TypeSubmitForm));
				int count = form.getFieldCount(null);
				WStringArray name_array = new WStringArray();
				for (int i = 0; i < count; i++) {
					name_array.add(form.getField(i, null).getName());
				}

				submit_action.setFieldNames(name_array);
				submit_action.setURL("http://www.foxitsoftware.com");
				widget.setAction(submit_action);
			} catch (PDFException e) {
				e.printStackTrace();
			}

			System.out.println("Add button field.");
		}

		{
			// Add radio button group
			try {
				Control control = form.addControl(page, "Radio Button0", Field.e_TypeRadioButton,
						new RectF(50.0f, 700, 90, 740));
				Control control1 = form.addControl(page, "Radio Button0", Field.e_TypeRadioButton,
						new RectF(100.0f, 700, 140, 740));
				control.setExportValue("YES");
				control.setChecked(true);
				// Update radio button's appearance.
				control.getWidget().resetAppearanceStream();

				control1.setExportValue("NO");
				control1.setChecked(false);
				// Update radio button's appearance.
				control1.getWidget().resetAppearanceStream();
			} catch (PDFException e) {
				e.printStackTrace();
			}

			System.out.println("Add radio button.");
		}

		{
			// Add check box
			try {
				Control control = form.addControl(page, "Check Box0", Field.e_TypeCheckBox,
						new RectF(50.0f, 650, 90, 690));
				control.setChecked(true);
				Widget widget = control.getWidget();
				widget.setMKBorderColor(0x000000);
				widget.setMKBackgroundColor(0xFFFFFF);
				widget.resetAppearanceStream();
			} catch (PDFException e) {
				e.printStackTrace();
			}

			System.out.println("Add check box.");
		}

		{
			// Add text field
			try {
				Control control = form.addControl(page, "Text Field0", Field.e_TypeTextField, new RectF(50, 600, 90, 640));
				control.getField().setValue("3");
				// Update text field's appearance.
				control.getWidget().resetAppearanceStream();
				
				Control control1 = form.addControl(page, "Text Field1", Field.e_TypeTextField, new RectF(100, 600, 140, 640));
				control1.getField().setValue("23");
				// Update text field's appearance.
				control1.getWidget().resetAppearanceStream();
				
				Control control2 = form.addControl(page, "Text Field2", Field.e_TypeTextField, new RectF(150, 600, 190, 640));
				Field field2 = control2.getField();
				JavaScriptAction javascipt_action = new JavaScriptAction(
						Action.create(form.getDocument(), Action.e_TypeJavaScript));
				javascipt_action
						.setScript("AFSimple_Calculate(\"SUM\", new Array (\"Text Field0\", \"Text Field1\"));");
				AdditionalAction aa = new AdditionalAction(field2);
				aa.setAction(AdditionalAction.e_TriggerFieldRecalculateValue, javascipt_action);
				field2.setValue("333333");
				// Update text field's appearance.
				control2.getWidget().resetAppearanceStream();
			} catch (PDFException e) {
				e.printStackTrace();
			}

			System.out.println("Add text field.");
		}

		{
			// Add text field with flag comb
			try {
				Control control = form.addControl(page, "Text Field3", Field.e_TypeTextField, new RectF(50, 570, 100, 590));
				Field field = control.getField();
				int flag = Field.e_FlagTextComb;
				field.setFlags(flag);
				field.setValue("94538");
				field.setMaxLength(5);
				// Update text field's appearance.
				control.getWidget().resetAppearanceStream();
			} catch (PDFException e) {
				e.printStackTrace();
			}
		}

		{
			// Add text field, with flag multiline.
			try {
				Control control = form.addControl(page, "Text Field4", Field.e_TypeTextField, new RectF(110, 550, 190, 590));
				Field field = control.getField();
				int flag = Field.e_FlagTextMultiline;
				field.setFlags(flag);
				field.setValue("Text fields are boxes or spaces in which the user can enter text from the keyboard.");
				// Update text field's appearance.
				control.getWidget().resetAppearanceStream();
			} catch (PDFException e) {
				e.printStackTrace();
			}
		}

		{
			// Add text field, with flag password.
			try {
				Control control = form.addControl(page, "Text Field5", Field.e_TypeTextField, new RectF(200, 570, 240, 590));
				Field field = control.getField();
				int flag = Field.e_FlagTextPassword;
				field.setFlags(flag);
				field.setValue("Password");
				// Update text field's appearance.
				control.getWidget().resetAppearanceStream();
			} catch (PDFException e) {
				e.printStackTrace();
			}
		}

		{
			// Add list box
			try {
				Control control = form.addControl(page, "List Box0", Field.e_TypeListBox, new RectF(50, 450, 350, 500));
				Field field = control.getField();
				ChoiceOptionArray options = new ChoiceOptionArray();
				options.add(new ChoiceOption("Foxit SDK", "Foxit SDK", true, true));
				options.add(new ChoiceOption("Foxit Reader", "Foxit Reader", true, true));
				options.add(new ChoiceOption("Foxit Phantom", "Foxit Phantom", true, true));
				field.setOptions(options);

				Widget widget = control.getWidget();
				widget.setMKBorderColor(0x000000);
				widget.setMKBackgroundColor(0xFFFFFF);
				widget.resetAppearanceStream();
			} catch (PDFException e) {
				e.printStackTrace();
			}
		}

		{
			// Add combo box
			Control control = null;
			Field field = null;
			Widget widget = null;

			try {
				control = form.addControl(page, "Combo Box0", Field.e_TypeComboBox, new RectF(50, 350, 350, 400));
				field = control.getField();
				ChoiceOptionArray options = new ChoiceOptionArray();
				options.add(new ChoiceOption("Foxit SDK", "Foxit SDK", true, true));
				options.add(new ChoiceOption("Foxit Reader", "Foxit Reader", true, true));
				options.add(new ChoiceOption("Foxit Phantom", "Foxit Phantom", true, true));
				field.setOptions(options);

				widget = control.getWidget();
				widget.setMKBorderColor(0x000000);
				widget.setMKBackgroundColor(0xFFFFFF);
				widget.resetAppearanceStream();

			} catch (PDFException e) {
				e.printStackTrace();
			}
		}
	}

	private static void createResultFolder(String output_path) {
		File myPath = new File(output_path);
		if (!myPath.exists()) {
			myPath.mkdir();
		}
	}

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
  static {
      String os = System.getProperty("os.name").toLowerCase();
      String lib = "fsdk_java_";
      if (os.startsWith("win")) {
          lib += "win";
      } else if (os.startsWith("mac")) {
          lib += "mac";
      } else {
          lib += "linux";
      }
      if (System.getProperty("sun.arch.data.model").equals("64")) {
          if(System.getProperty("os.arch").equals("aarch64")){
              lib += "arm";
          }
          else{
              lib += "64";
          }
      } else {
          lib += "32";
      }
      System.loadLibrary(lib);
  }

	public static void main(String[] args) {
		String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
		String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
		String output_path = "../output_files/form/";
		createResultFolder(output_path);
		// Initialize library
		int error_code = Library.initialize(sn, key);
		if (error_code != Constants.e_ErrSuccess) {
			System.out.printf("Library Initialize Error: %d\n", error_code);
			return;
		}

		try {
			PDFDoc doc = new PDFDoc();
			Form form = new Form(doc);
			// Create a blank new page and add some form fields.
			PDFPage page = doc.insertPage(0, PDFPage.e_SizeLetter);
			AddInteractiveForms(page, form);

			String newPdf = output_path + "form.pdf";
			doc.saveAs(newPdf, PDFDoc.e_SaveFlagNoOriginal);
		} catch (PDFException e) {
			System.out.println(e.getMessage());
			return;
		}
		Library.release();
	}

}
