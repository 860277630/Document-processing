// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit PDF SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to render all PDF layers of a PDF,
// and add layers in a PDF document.

import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.*;
import com.foxit.sdk.common.fxcrt.Matrix2D;
import com.foxit.sdk.pdf.*;
import com.foxit.sdk.pdf.graphics.GraphicsObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import static com.foxit.sdk.common.Bitmap.e_DIBArgb;
import static com.foxit.sdk.common.Constants.e_ErrSuccess;
import static com.foxit.sdk.pdf.LayerContext.e_UsageView;
import static com.foxit.sdk.pdf.LayerTree.*;
import static com.foxit.sdk.pdf.PDFDoc.e_SaveFlagNormal;
import static com.foxit.sdk.pdf.PDFPage.e_ParsePageNormal;

public class pdflayer {
    private static String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
    private static String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
    private static String output_path = "../output_files/pdflayer/";
    private static String input_path = "../input_files/";

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
       String os = System.getProperty("os.name").toLowerCase();
       String lib = "fsdk_java_";
       if (os.startsWith("win")) {
           lib += "win";
       } else if (os.startsWith("mac")) {
          lib += "mac";
       } else {
           lib += "linux";
       }
       if (System.getProperty("sun.arch.data.model").equals("64")) {
           if(System.getProperty("os.arch").equals("aarch64")){
               lib += "arm";
           }
           else{
               lib += "64";
           }
       } else {
           lib += "32";
       }
       System.loadLibrary(lib);
    }

    private static void createResultFolder(String output_path) {
        File myPath = new File(output_path);
        if (!myPath.exists()) {
            myPath.mkdir();
        }
    }

    static void renderPageToImage(PDFPage page, LayerContext layer_content, String bitmap_file) throws PDFException {
        if (!page.isParsed()) {
            // Parse page.
            page.startParse(e_ParsePageNormal, null, false);
        }

        int width = (int) page.getWidth();
        int height = (int) page.getHeight();
        Matrix2D matrix = page.getDisplayMatrix(0, 0, width, height, page.getRotation());

        // Prepare a bitmap for rendering.
        Bitmap bitmap = new Bitmap(width, height, e_DIBArgb, null, 0);
        bitmap.fillRect(0xFFFFFFFF, null);

        // Render page.
        Renderer render = new Renderer(bitmap, false);

        if (!layer_content.isEmpty()) {
            render.setLayerContext(layer_content);
        }
        render.startRender(page, matrix, null);
        Image image = new Image();
        image.addFrame(bitmap);

        image.saveAs(bitmap_file);
    }

    static String usgaeCodeToString(int state) {
        switch (state) {
            case e_StateON:
                return "ON";
            case e_StateOFF:
                return "OFF";
            case e_StateUnchanged:
                return "Unchanged";
            case e_StateUndefined:
                return "Undefined";
        }
        return "Unknown";
    }

    static void write_prefix(int depth, String prefix, String formatbuff, FileWriter text_doc) throws IOException {
        for (int i = 0; i < depth; i++) {
            text_doc.write(String.format("%s", "\t"));
        }
        text_doc.write(formatbuff);
    }

    static void getAllLayerNodesInformation(LayerNode layer_node, int depth, FileWriter text_doc) throws PDFException, IOException {

        if (depth >= 0) {
            write_prefix(depth, "\t", String.format("%s", layer_node.getName()), text_doc);

            if (layer_node.hasLayer()) {
                int state = layer_node.getViewUsage();
                text_doc.write(String.format(" %s\r\n", state == e_StateON ? "[*]" : "[ ]"));
                write_prefix(depth, "\t", String.format("View usage state:\t%s\r\n", usgaeCodeToString(state)), text_doc);
                write_prefix(depth, "\t", String.format("Export usage state:\t%s\r\n", usgaeCodeToString(layer_node.getExportUsage())), text_doc);

                LayerPrintData print_data = layer_node.getPrintUsage();
                write_prefix(depth, "\t", String.format("Print usage state:\t%s, subtype: %s\r\n", usgaeCodeToString(print_data.getPrint_state()), print_data.getSubtype()), text_doc);
                LayerZoomData zoom_data = layer_node.getZoomUsage();
                write_prefix(depth, "\t", String.format("Zomm usage:\tmin_factor = %.4f max_factor = %.4f\r\n\r\n", zoom_data.getMin_factor(), zoom_data.getMax_factor()), text_doc);
            } else {
                text_doc.write("\r\n");
            }
        }

        depth++;
        int count = layer_node.getChildrenCount();
        for (int i = 0; i < count; i++) {
            LayerNode child = layer_node.getChild(i);
            getAllLayerNodesInformation(child, depth, text_doc);
        }
    }

    static void setAllLayerNodesInformation(LayerNode layer_node) throws PDFException {
        if (layer_node.hasLayer()) {
            layer_node.setDefaultVisible(true);
            layer_node.setExportUsage(e_StateUndefined);
            layer_node.setViewUsage(e_StateOFF);
            LayerPrintData print_data = new LayerPrintData("subtype_print", e_StateON);
            layer_node.setPrintUsage(print_data);
            LayerZoomData zoom_data = new LayerZoomData(1, 10);
            layer_node.setZoomUsage(zoom_data);
            String new_name = String.format("[View_OFF_Print_ON_Export_Undefined]") + layer_node.getName();
            layer_node.setName(new_name);
        }
        int count = layer_node.getChildrenCount();
        for (int i = 0; i < count; i++) {
            LayerNode child = layer_node.getChild(i);
            setAllLayerNodesInformation(child);
        }
    }

    static void setAllLayerNodesVisible(LayerContext context, LayerNode layer_node, boolean visible) throws PDFException {
        if (layer_node.hasLayer()) {
            context.setVisible(layer_node, false);
        }
        int count = layer_node.getChildrenCount();
        for (int i = 0; i < count; i++) {
            LayerNode child = layer_node.getChild(i);
            setAllLayerNodesVisible(context, child, visible);
        }
    }

    static void renderAllLayerNodes(PDFDoc doc, LayerContext context, LayerNode layer_node, String pdf_name) throws PDFException {
        if (layer_node.hasLayer()) {
            context.setVisible(layer_node, true);
            int nCount = doc.getPageCount();
            for (int i = 0; i < nCount; i++) {
                PDFPage page = doc.getPage(i);
                String s = String.format("%d", i);
                String layer_name = layer_node.getName();
                layer_name = layer_name.replace(":", "");
                layer_name = layer_name.replace(">", "");
                layer_name = layer_name.replace("<", "");
                layer_name = layer_name.replace("=", "");
                String file_name = output_path + "page_" + s + "_layer_node_" + layer_name + ".bmp";
                renderPageToImage(page, context, file_name);
            }
        }

        int count = layer_node.getChildrenCount();
        for (int i = 0; i < count; i++) {
            LayerNode child = layer_node.getChild(i);
            renderAllLayerNodes(doc, context, child, pdf_name);
        }
        if (layer_node.hasLayer()) {
            // The visibility of parent layer will affect the children layers,
            // so reset the visibility of parent layer after children have been rendered.
            context.setVisible(layer_node, false);
        }
    }

    public static void main(String[] args) throws PDFException, IOException {
        createResultFolder(output_path);
        // Initialize library
        int error_code = Library.initialize(sn, key);
        if (error_code != e_ErrSuccess) {
            System.out.println(String.format("Library Initialize Error: %d\n", error_code));
            return;
        }

        String input_file = input_path + "OCTest_src.pdf";
   
        try {
            {
              PDFDoc doc = new PDFDoc(input_file);
              error_code = doc.load(null);
  
              if (error_code != e_ErrSuccess) {
                  System.out.println(String.format("The Doc [%s] Error: %d\n", input_file, error_code));
                  return;
              }
              LayerTree layertree = new LayerTree(doc);
              LayerNode root = layertree.getRootNode();
              if (root.isEmpty()) {
                  System.out.println("No layer information!");
                  return;
              }
  
              // Get original information of all layer nodes.
              String file_info = output_path + "original_layer_informations.txt";
              FileWriter original_doc = new FileWriter(file_info, false);
              getAllLayerNodesInformation(root, -1, original_doc);
              // Set new information.
              setAllLayerNodesInformation(root);
  
              // Get new information.
              file_info = output_path + "new_layer_informations.txt";
              FileWriter new_info = new FileWriter(file_info, false);
              getAllLayerNodesInformation(root, -1, new_info);
  
              String output_file = output_path + "new_layers.pdf";
              doc.saveAs(output_file, e_SaveFlagNormal);
              // Render layer node.
              LayerContext context = new LayerContext(doc, e_UsageView);
              setAllLayerNodesVisible(context, root, false);
  
              renderAllLayerNodes(doc, context, root, output_file);
              original_doc.close();
              new_info.close();
            }
              
            {
              // Edit layer tree
              PDFDoc doc = new PDFDoc(input_file);
              error_code = doc.load(null);
              LayerTree layertree = new LayerTree(doc);
              LayerNode root = layertree.getRootNode();
              int children_count = root.getChildrenCount();
              root.removeChild(children_count -1);
              LayerNode child = root.getChild(children_count - 2);
              LayerNode child0 = root.getChild(0);
              child.moveTo(child0, 0);
              child.addChild(0, "AddedLayerNode", true);
              child.addChild(0, "AddedNode", false);
              String file_info = output_path + "edit_layer_informations.txt";
              FileWriter edit_info = new FileWriter(file_info, false);
              getAllLayerNodesInformation(root, -1, edit_info);
              edit_info.close();

              String output_file = output_path + "edit_layer_tree.pdf";
              doc.saveAs(output_file, e_SaveFlagNormal);
            }

            {
              // Create layer tree
              PDFDoc doc = new PDFDoc(input_path + "AboutFoxit.pdf");
              error_code = doc.load(null);
              boolean has_layer = doc.hasLayer();
              LayerTree layertree = new LayerTree(doc);
              has_layer = doc.hasLayer();
              LayerNode root = layertree.getRootNode();
              int children_count = root.getChildrenCount();
              root.addChild(0, "AddedLayerNode", true);
              root.addChild(0, "AddedNode", false);
              String file_info = output_path + "create_layer_informations.txt";
              FileWriter create_info = new FileWriter(file_info, false);
              getAllLayerNodesInformation(root, -1, create_info);
              create_info.close();

              String output_file = output_path + "create_layer_tree.pdf";
              doc.saveAs(output_file, e_SaveFlagNormal);
            }

            {
              //Copy graphics objects from A PDF to B PDF
              PDFDoc doc = new PDFDoc(input_file);
              error_code = doc.load(null);
              PDFPage page = doc.getPage(0);
              page.startParse(e_ParsePageNormal, null, false);
              
              //Create layer tree.
              PDFDoc newdoc = new PDFDoc(input_path + "pdfobjects.pdf");
              error_code = newdoc.load(null);
              PDFPage newpage = newdoc.getPage(0);
              newpage.startParse(e_ParsePageNormal, null, false);
              boolean haslayer = newdoc.hasLayer();
              LayerTree layertree = new LayerTree(newdoc);
              haslayer = newdoc.hasLayer();
              LayerNode root = layertree.getRootNode();
              LayerNode node = root.addChild(0, "AddedLayerNode", true);
              
              for(int i = 0;i < 5;i++) {
                GraphicsObject graphics_object = page.getGraphicsObject(i);
                newpage.insertGraphicsObject(0, graphics_object);
                node.addGraphicsObject(newpage, graphics_object);
              }
              newpage.generateContent();
              String output_file = output_path + "copy_graphics_objects.pdf";
              newdoc.saveAs(output_file, e_SaveFlagNormal);
            }

            System.out.println("PDFLayer test.");

        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        Library.release();
        return;
    }
}
