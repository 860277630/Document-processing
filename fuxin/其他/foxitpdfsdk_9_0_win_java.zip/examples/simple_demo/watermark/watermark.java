// Copyright (C) 2003-2023, Foxit Software Inc..
// All Rights Reserved.
//
// http://www.foxitsoftware.com
//
// The following code is copyrighted and contains proprietary information and trade secrets of Foxit Software Inc..
// You cannot distribute any part of Foxit SDK to any third party or general public,
// unless there is a separate license agreement with Foxit Software Inc. which explicitly grants you such rights.
//
// This file contains an example to demonstrate how to use Foxit PDF SDK to add watermarks (in different types)
// into PDF files.

import com.foxit.sdk.PDFException;
import com.foxit.sdk.common.Bitmap;
import com.foxit.sdk.common.Font;
import com.foxit.sdk.common.Image;
import com.foxit.sdk.common.Library;
import com.foxit.sdk.pdf.*;
import com.foxit.sdk.pdf.Watermark;
import com.foxit.sdk.pdf.WatermarkSettings;
import com.foxit.sdk.pdf.WatermarkTextProperties;

import java.io.File;

import com.foxit.sdk.common.Constants;

import static com.foxit.sdk.common.Constants.e_AlignmentCenter;
import static com.foxit.sdk.common.Constants.e_ErrSuccess;
import static com.foxit.sdk.common.Font.e_StdIDTimesB;
import static com.foxit.sdk.pdf.PDFDoc.e_SaveFlagNoOriginal;
import static com.foxit.sdk.pdf.PDFPage.e_ParsePageNormal;
import static com.foxit.sdk.pdf.WatermarkSettings.*;
import static com.foxit.sdk.pdf.WatermarkTextProperties.e_FontStyleNormal;


public class watermark {


    private static String key = "8f3gFUOMvWsN+XetmKjesLrN1bbW579neweVmliZrY8uZ6/i/7SL9cclERab9veWUFnx1yutgUWtsULQY9uK+nOnriRGPTGea4EIV/RtgqaOVX2aKjEO+qKm7Z4POHyWE2EQLMdFk+NhyIhDyYgn1fzxlWO37hYJVoDsD1cJyW9MDiUXnCUVluu7MoD9eL9tg4c0sTRBaRIxJ2HVwkgj8sejZHC9+QO21smtyw8EdqBXXW65J3jv3eC+NrYy5s8uEWEljhHnXpB1kAEF7AW1BE98isH2QdYhHab8FcAP/a6KO8qpGoAN/ilZNulUOafJkdn5uxH9lwUwmy8j1Wdg6pVlMwXn86xMkSeU/GW5/FI+it61sXjfPNXBFAzmb5YdFBsrGHQIMhDFIlSz45qA1xpU7phRgA/C4P7S9Og49NPt11qIDV2XNI2Dw6nflic7ecc/hj86VPazgeTweZi0eYTxIQqC6j68nT2K9vFEOvgc+XpW9ZpI1WnwY5OStgLFNFc5TJT0XvPEqU61swY0359wUEal2ejzDeLnBdDWqqY3ZTZtrip3708thNxqm9DtJUKdcH+1ybONG/LNAyowJBmmcpeGa9cRJmn7vk4I/UJuZfyuAl/S8Ozl8iG3BZQvUz0ZTavlbOAVoWLnhtd8ZHyHrsq5vXcJZL/Bl6GZF6AjbfGAXaLTfVUXG3qlLCeACwWx+DkxzykXWLPCPT9jm88AJlVmE6GNZZKqnLyAzw0n1FJELYXfZvRdG9QpgZ789ewihsVY7uArd2WDO25V0TGNeozLZd2w8d6JTQQPRJicC8XaqNaFVlb0nXE5KUX/7kbA9nGDn3je78vkvapgydHNWMzz5w40V4hALPC0GZMx8qdVygg23vswfkvGT4cZBLsw3HoTFNA+yHpPHLqxt0QQfO8xpSMlMF306AIb78vGXu1S4x1dkgyfW/KPJHXisX4SxwYKS7U/ctWJD4bvBjBcPEQ9T0vsjt91JD10YI89CSJRopRX0KM1Jtu5bZzbzE4E3SzsHLimf7wrVDKgZgzFb/4Srp79RwfUvQbT1B2wlXi7j70s2Kb+szUwySyqpubi6Yc2vm5bXPBId+96NzPeJGSBbG5txOUAvdvUKS3l4lNawVTEq0bcgAeXXjnnyN8tYGk3AylTrZbmWLck0YOw+250kH+lRDWAfest+dWEfrR06KxDf+zGLMFP7tZErv4iPhCgi0aPyKNClQ0vYo4RXYctNdT6CYA58uydVDkT7w9J2s9bvLubAUktESMPt6xF2/PBnLWye64YJtI9PiLy/NjT5xodBNUQt13NvJInrNjMucwi81CzlgM0E8OR+1gY5k2JX27dLAl/Iq9YvWyjPsOyjWnaT8hNlg==";
    private static String sn = "V62Vvb7HiQBMPS8rdRFdLD3WMZYY0Ndfi+JkVe693PHuWc3zMAECjw==";
    private static String output_path = "../output_files/watermark/";
    private static String input_path = "../input_files/";
    private static String input_file = input_path + "AboutFoxit.pdf";
    private static String output_file = output_path + "watermark_add.pdf";
    private static String output_remove_file = output_path + "watermark_remove.pdf";

    // You can also use System.load("filename") instead. The filename argument must be an absolute path name.
    static {
       String os = System.getProperty("os.name").toLowerCase();
       String lib = "fsdk_java_";
       if (os.startsWith("win")) {
           lib += "win";
       } else if (os.startsWith("mac")) {
           lib += "mac";
       } else {
           lib += "linux";
       }
       if (System.getProperty("sun.arch.data.model").equals("64")) {
           if(System.getProperty("os.arch").equals("aarch64")){
               lib += "arm";
           }
           else{
               lib += "64";
           }
       } else {
           lib += "32";
       }
       System.loadLibrary(lib);
    }

    private static void createResultFolder(String output_path) {
        File myPath = new File(output_path);
        if (!myPath.exists()) {
            myPath.mkdir();
        }
    }

    static void addTextWatermark(PDFDoc doc, PDFPage page) throws PDFException {
        WatermarkSettings settings = new WatermarkSettings();
        settings.setFlags(e_FlagASPageContents | e_FlagOnTop);
        settings.setOffset_x(0);
        settings.setOffset_y(0);
        settings.setOpacity(90);
        settings.setPosition(Constants.e_PosTopRight);
        settings.setRotation(-45.f);
        settings.setScale_x(1.f);
        settings.setScale_y(1.f);

        WatermarkTextProperties text_properties = new WatermarkTextProperties();
        text_properties.setAlignment(e_AlignmentCenter);
        text_properties.setColor(0xF68C21);
        text_properties.setFont_size(e_FontStyleNormal);
        text_properties.setLine_space(1);
        text_properties.setFont_size(12.f);
        text_properties.setFont(new Font(e_StdIDTimesB));

        Watermark watermark = new Watermark(doc, "Foxit PDF SDK\nwww.foxitsoftware.com", text_properties, settings);
        watermark.insertToPage(page);

    }

    static void addBitmapWatermark(PDFDoc doc, PDFPage page, String bitmap_file) throws PDFException {
        WatermarkSettings settings = new WatermarkSettings();
        settings.setFlags(e_FlagASPageContents | e_FlagOnTop);
        settings.setOffset_x(0.f);
        settings.setOffset_y(0.f);
        settings.setOpacity(60);
        settings.setPosition(Constants.e_PosCenterLeft);
        settings.setRotation(90.f);

        Image image = new Image(bitmap_file);
        Bitmap bitmap = image.getFrameBitmap(0);
        settings.setScale_x(page.getHeight() * 1.0f / bitmap.getWidth());
        settings.setScale_y(settings.getScale_x());
        Watermark watermark = new Watermark(doc, bitmap, settings);
        watermark.insertToPage(page);
    }


    static void addImageWatermark(PDFDoc doc, PDFPage page, String image_file) throws PDFException {
        WatermarkSettings settings = new WatermarkSettings();
        settings.setFlags(e_FlagASPageContents | e_FlagOnTop);
        settings.setOffset_x(0.f);
        settings.setOffset_y(0.f);
        settings.setOpacity(20);
        settings.setPosition(Constants.e_PosCenter);
        settings.setRotation(0.0f);

        Image image = new Image(image_file);
        Bitmap bitmap = image.getFrameBitmap(0);
        settings.setScale_x(page.getWidth() * 0.618f / bitmap.getWidth());
        settings.setScale_y(settings.getScale_x());

        Watermark watermark = new Watermark(doc, image, 0, settings);
        watermark.insertToPage(page);
    }

    static void addSingleWatermark(PDFDoc doc, PDFPage page) throws PDFException {
        WatermarkSettings settings = new WatermarkSettings();
        settings.setFlags(e_FlagASPageContents | e_FlagOnTop);
        settings.setOffset_x(0.f);
        settings.setOffset_y(0.f);
        settings.setOpacity(90);
        settings.setPosition(Constants.e_PosBottomRight);
        settings.setRotation(0.0f);
        settings.setScale_x(0.1f);
        settings.setScale_y(0.1f);

        Watermark watermark = new Watermark(doc, page, settings);
        watermark.insertToPage(page);
    }


    public static void main(String[] args) throws PDFException {
        createResultFolder(output_path);
        // Initialize library
        int error_code = Library.initialize(sn, key);
        if (error_code != e_ErrSuccess) {
            System.out.println("Library Initialize Error: " + error_code);
            return;
        }



        try {
            PDFDoc doc = new PDFDoc(input_file);
            error_code = doc.load(null);

            if (error_code != e_ErrSuccess) {
                System.out.println("The Doc " + input_file + " Error: " + error_code);
                return;
            }
            int nCount = doc.getPageCount();
            for (int i = 0; i < nCount; i++) {
                PDFPage page = doc.getPage(i);
                page.startParse(e_ParsePageNormal, null, false);

                addTextWatermark(doc, page);
                String wm_bmp = input_path + "watermark.bmp";
                addBitmapWatermark(doc, page, wm_bmp);
                String wm_image = input_path + "sdk.png";
                addImageWatermark(doc, page, wm_image);
                addSingleWatermark(doc, page);
            }

            doc.saveAs(output_file, e_SaveFlagNoOriginal);
            System.out.println("Add watermarks to PDF file.");

            nCount = doc.getPageCount();
            for (int i = 0; i < nCount; i++)
            {
                PDFPage page = doc.getPage(i);
                page.startParse(e_ParsePageNormal, null, false);
                if (page.hasWatermark()) {
                    page.removeAllWatermarks();
                }
            }

            doc.saveAs(output_remove_file, e_SaveFlagNoOriginal);
            System.out.println("Remove watermarks from PDF file.");

        } catch (Exception e) {
            e.printStackTrace();

        }
        Library.release();
        return;
    }
}
