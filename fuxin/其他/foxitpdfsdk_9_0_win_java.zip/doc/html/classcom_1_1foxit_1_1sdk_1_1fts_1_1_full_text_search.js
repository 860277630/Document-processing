var classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search =
[
    [ "FullTextSearch", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html#a25e073e962d55041e8de19bec78ce4f8", null ],
    [ "FullTextSearch", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html#a7114779ba8bdfaf2209a168fc47d3f2e", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html#ad20398ca0176768a4406b76865fed079", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html#a99cc79dd3575cdb627dde77508fa35f3", null ],
    [ "searchOf", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html#a284d85cbcf6efbbb1599ca7a4868c941", null ],
    [ "setDataBasePath", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html#a36369de464add01a691e15c1cfb1cf05", null ],
    [ "startUpdateIndex", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html#af3256ad12dd7e8937206a0ca30a5e8c4", null ],
    [ "updateIndexWithFilePath", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html#ae14f8a918752ee5386d9ebf94a54a5b7", null ],
    [ "e_RankHitCountASC", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html#ae83e53108b90a7c83876f4b6857e3b43", null ],
    [ "e_RankHitCountDESC", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html#ab10a1c1001ec32406a9cbaafcc607520", null ],
    [ "e_RankNone", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html#aca3be46066873fee35cd9c484e07d726", null ]
];