var classcom_1_1foxit_1_1sdk_1_1_menu_item_ex =
[
    [ "MenuItemEx", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#a55e0aa1f986c02007bee7209ba8f71f5", null ],
    [ "MenuItemEx", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#abcf621fe8f573de67d05da6b4e0fa52b", null ],
    [ "MenuItemEx", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#a6af3b4120c95eac3bf039d7ad006d068", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#ae1fe319a0dbef08b5ed75e2e95f82995", null ],
    [ "getIs_checked", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#ad49efee2077e875827b3ee9b2a1151ca", null ],
    [ "getIs_enabled", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#abf1b31b8190400399485933625adb422", null ],
    [ "getItem_name", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#aedea93bb356692a0c1ca161bae3e72b9", null ],
    [ "getReturn_name", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#abbbde39c1bbbc5e1dc698984ea1d2ce9", null ],
    [ "getSub_menu_item_array", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#ae1e91a248aa7c240dc64059641a5e615", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#a8c61ab7dac35a8b3d19e53af76f8351c", null ],
    [ "setIs_checked", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#ac753c20e12935e7c2a2da8b0e2035d83", null ],
    [ "setIs_enabled", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#a0354e03f9194608cec829714b59127ae", null ],
    [ "setItem_name", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#a8f53739c2517d7c7bd70b504ca372e02", null ],
    [ "setReturn_name", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#ae200b683d6a11787ed698dfd25d8f5fe", null ],
    [ "setSub_menu_item_array", "classcom_1_1foxit_1_1sdk_1_1_menu_item_ex.html#a264f43f3bb697ee591178aa6746c94e2", null ]
];