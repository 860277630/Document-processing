var classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office =
[
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office.html#a5b77ded8fa87b4f656f867a844ed1e3a", null ],
    [ "initialize", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office.html#a4f34aa1a96eaebaadbc3be0ca75c115b", null ],
    [ "release", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office.html#a1f497aa5c56467610cd8f5322a2f783a", null ],
    [ "startConvertToExcel", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office.html#a64bad96d0394d8c5a4643ac9257e2858", null ],
    [ "startConvertToExcel", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office.html#af1768b7090765a1b8ff182d57540ea69", null ],
    [ "startConvertToPowerPoint", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office.html#a0d7f1b93c678955d36146fe3f2c0ec16", null ],
    [ "startConvertToPowerPoint", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office.html#ac5c54b0606418b816beb1b05f01ddadf", null ],
    [ "startConvertToWord", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office.html#a25d228954d6ef81daaf29cd510c04394", null ],
    [ "startConvertToWord", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office.html#a1f14c7094d4c9ad601de58baa224ae39", null ]
];