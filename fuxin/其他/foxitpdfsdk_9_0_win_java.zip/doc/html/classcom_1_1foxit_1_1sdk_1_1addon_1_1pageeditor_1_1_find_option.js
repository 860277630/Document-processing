var classcom_1_1foxit_1_1sdk_1_1addon_1_1pageeditor_1_1_find_option =
[
    [ "FindOption", "classcom_1_1foxit_1_1sdk_1_1addon_1_1pageeditor_1_1_find_option.html#a8089f8a7f4141f496d2d1b4397966ccb", null ],
    [ "FindOption", "classcom_1_1foxit_1_1sdk_1_1addon_1_1pageeditor_1_1_find_option.html#ad1bc4aaa44b84f6fe5af16462769be4b", null ],
    [ "FindOption", "classcom_1_1foxit_1_1sdk_1_1addon_1_1pageeditor_1_1_find_option.html#a892e5aca644a385cb7f8495023531201", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1pageeditor_1_1_find_option.html#a0d86d5c9204593716b3ce47309469d16", null ],
    [ "getIs_case_sensitive", "classcom_1_1foxit_1_1sdk_1_1addon_1_1pageeditor_1_1_find_option.html#a6d32fb1e3e8781faa3a4bd93b0873e3d", null ],
    [ "getIs_whole_word", "classcom_1_1foxit_1_1sdk_1_1addon_1_1pageeditor_1_1_find_option.html#a4718279c05c5164f2561895230ad7d15", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1addon_1_1pageeditor_1_1_find_option.html#a6288db186e48182bbb613ccffd4d745d", null ],
    [ "setIs_case_sensitive", "classcom_1_1foxit_1_1sdk_1_1addon_1_1pageeditor_1_1_find_option.html#a7f497bdfddcebeec7ca494c113ee02f4", null ],
    [ "setIs_whole_word", "classcom_1_1foxit_1_1sdk_1_1addon_1_1pageeditor_1_1_find_option.html#acccc519a7ea66721c71d5400b8efdd0a", null ]
];