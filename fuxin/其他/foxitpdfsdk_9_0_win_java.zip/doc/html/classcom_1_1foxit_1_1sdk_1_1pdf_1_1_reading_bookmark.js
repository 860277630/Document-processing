var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_reading_bookmark =
[
    [ "ReadingBookmark", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_reading_bookmark.html#a030ef6b209de2716b0c5980c8b3e931d", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_reading_bookmark.html#aa3741a1151bc35f785e2b0684b31770e", null ],
    [ "getDateTime", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_reading_bookmark.html#a29fce4cf6d3fca45ea96e666ef3d7127", null ],
    [ "getPageIndex", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_reading_bookmark.html#a4b56cff4fad8de2a9fcf63d8929d126f", null ],
    [ "getTitle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_reading_bookmark.html#ac96241ebba584ce5bc4314c453144968", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_reading_bookmark.html#ae054432be0c4180ec46a35d3a53114d2", null ],
    [ "setDateTime", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_reading_bookmark.html#ad452525768335bdf4b4e68342d9f2b90", null ],
    [ "setPageIndex", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_reading_bookmark.html#a34ea88315e9144e848ed5c0eb066257b", null ],
    [ "setTitle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_reading_bookmark.html#a2e047f3c251b86a1e7403557be39a567", null ]
];