var classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data =
[
    [ "TXT2PDFSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#a72bfe34842be0f7c0f2aba163886497a", null ],
    [ "TXT2PDFSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#ae564ef7260c2c20fa71d99b1db3386a4", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#a00796ba201db739e9ba6c9cdef83b3db", null ],
    [ "getFont", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#aebac533e382bf4ef31155ed5463b307a", null ],
    [ "getIs_break_page", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#a8ee8761d1c4e87536d9d22a46062eb6a", null ],
    [ "getLinespace", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#ab6265b49766e70efd616b0e7e50c9e37", null ],
    [ "getPage_height", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#ae6858a749781040de0055675d0d593d8", null ],
    [ "getPage_margin", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#aa91534e4ef55e09de8d1c8f7e041d197", null ],
    [ "getPage_width", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#a733d63a4a1afa0acda2f50a8b85ebe13", null ],
    [ "getText_color", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#a7adb9f3ecd9440d7b285509008bebe54", null ],
    [ "getText_size", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#ab2eae308dd986f121f17a4ab97016457", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#a8c9371eb138aba586391bf7eadf035cb", null ],
    [ "setFont", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#a3bdc301430625629d6398dde86ce67b9", null ],
    [ "setIs_break_page", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#a19d9b61979ed133b194dfe4c53c50ce5", null ],
    [ "setLinespace", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#aa9e3a8f20244c1b39b7dbe04c9a07d4c", null ],
    [ "setPage_height", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#aa9d1b0fdd5d84f55dc2cd50d14d149e2", null ],
    [ "setPage_margin", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#a59fc3a1569a8a97b71feb36b28656f89", null ],
    [ "setPage_width", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#ac413a2ee5692733fb6a45ca0aa5e8c7a", null ],
    [ "setText_color", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#aa14d2b808c7b6f2e82d4c226d60adf02", null ],
    [ "setText_size", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html#ab381aed4aeb95692ea4145af33729fd5", null ]
];