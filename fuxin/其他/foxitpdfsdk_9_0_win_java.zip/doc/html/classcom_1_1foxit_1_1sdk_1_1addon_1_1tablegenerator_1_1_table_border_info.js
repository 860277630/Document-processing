var classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info =
[
    [ "TableBorderInfo", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#a0d08c36caa914198e3c15e43bbe36d6a", null ],
    [ "TableBorderInfo", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#a98ac8770dd1b062541c5a253e4fbaa2a", null ],
    [ "TableBorderInfo", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#afdd663ca8923eaa413a8186f390c2073", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#a16bedc8f9075c111e783a1e950b1691e", null ],
    [ "getColor", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#ad9d0e322faf117681d75b98b06696db9", null ],
    [ "getDash_phase", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#acd175c73cd9830c7b6a26b17fb3b305b", null ],
    [ "getDashes", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#afc24d03b80ae2b250c43ec1450b775e7", null ],
    [ "getLine_width", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#a4bb0cbdf450301295f78303f87ae811d", null ],
    [ "getTable_border_style", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#aad53cb1880a1f945f597d2c46c3384f8", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#a7ad0e684115e18dab1314e304c27e56c", null ],
    [ "setColor", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#aa5836290dcc182785cae99cd675d33e8", null ],
    [ "setDash_phase", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#acadd34d8ca337149ca121bd2d566a55c", null ],
    [ "setDashes", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#a0a47fd45c23bd7dd86314f45e8c9d7c3", null ],
    [ "setLine_width", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#a2558709c8f62657cab250728c5f1c949", null ],
    [ "setTable_border_style", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#ab5668c1e370e5d23ca37bee740eceff7", null ],
    [ "e_TableBorderStyleDashed", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#a16803157a2ac1f308a6101ea866b049d", null ],
    [ "e_TableBorderStyleSolid", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_border_info.html#af295442241032093b8ac0e7cd713cd73", null ]
];