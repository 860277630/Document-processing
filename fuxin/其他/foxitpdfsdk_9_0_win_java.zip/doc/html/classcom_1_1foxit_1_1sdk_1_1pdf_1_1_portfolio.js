var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio =
[
    [ "Portfolio", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#aa5e39febe14f449bb8d238e7630c1f4d", null ],
    [ "createPortfolio", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#ad6c1138503d57a097e25fd56f66583ef", null ],
    [ "createPortfolio", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a071a5f2994a96b4308875a220d6e4671", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#adbc8d5d193775cb93031399190c041af", null ],
    [ "getInitialFileSpecKeyName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a8a5d3dc9a6da1a59fd4151b1aee3425b", null ],
    [ "getInitialViewMode", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a4058fc60d41500a9165cdae3403dbd0e", null ],
    [ "getPortfolioPDFDoc", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#acb6228dbeef6a1a82444033cd8949c57", null ],
    [ "getRootNode", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a4677ff8d2636697175ccfdf661872aec", null ],
    [ "getSchemaFields", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#af29f44fa0a05aa2e10517bc9d68de619", null ],
    [ "getSortingFieldKeyName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a976f4e999aa6ad0a66dfc5ee1b103ab9", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a3fc3a79c79567e3ce1b0974e4f770290", null ],
    [ "isSortedInAscending", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a757ad58b4e7ab46744719ee75080220c", null ],
    [ "setInitialFileSpecKeyName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a50173bd1f5f3e2c89d31413d7a31e4ac", null ],
    [ "setInitialViewMode", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a0258902d9e406acb6673947d22b4b557", null ],
    [ "setSchemaFields", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#ab6b87fa3c7af46e7985abd7e4633f719", null ],
    [ "setSortingFieldKeyName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#ab2d16962198f8eda8dcadc3f479ceaf0", null ],
    [ "setSortingOrder", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a2c8f03248d31c2bfee640a599349e6a7", null ],
    [ "e_InitialViewDetailMode", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a8d134a080b9e53ba4c98394456028a02", null ],
    [ "e_InitialViewHidden", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#aa7800086e3c5c0b41bd19fdac9ba5cb9", null ],
    [ "e_InitialViewTileMode", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a189e86085a5e167463d0079227457720", null ],
    [ "e_InitialViewUnknownMode", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#a970edaf3c6086de235b5f29709b90d31", null ]
];