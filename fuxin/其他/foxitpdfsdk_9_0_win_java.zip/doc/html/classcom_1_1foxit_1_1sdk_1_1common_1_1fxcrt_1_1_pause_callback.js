var classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_pause_callback =
[
    [ "needToPauseNow", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_pause_callback.html#a11c166d7a1860e61af6ceada1c68366f", null ]
];