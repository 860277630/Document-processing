var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties =
[
    [ "WatermarkTextProperties", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#a291890d16aa1b6057ce5dff5ae07ae65", null ],
    [ "WatermarkTextProperties", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#ab6aa48eab045bfee1b4b121397b262bf", null ],
    [ "WatermarkTextProperties", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#a0dd8c8a60a3a60696c4eb05f601afc8b", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#a9d598a39bc20513f6d856f6a482e9d30", null ],
    [ "getAlignment", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#af70246359039f97b8a333e4f263f696a", null ],
    [ "getColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#ac4d54a24bfb1e75b67a4e3811f302c64", null ],
    [ "getFont", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#a3038ee5afdcee79407bee4977e58b1f8", null ],
    [ "getFont_size", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#adcfeba33b98995573c6b85951e74d19f", null ],
    [ "getFont_style", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#aeda33c1f669e4c8e6fe7e1c942988912", null ],
    [ "getLine_space", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#ab946fd028e786b47300913b60515f015", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#a6aa4116c4761c1ebba285e2b22608aef", null ],
    [ "setAlignment", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#abcc2147e307fa34923efad28b1fde6a6", null ],
    [ "setColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#a711e6611622e53710ae1d60fbd52a067", null ],
    [ "setFont", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#acd39c540320caa5427934f5d76d995ce", null ],
    [ "setFont_size", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#a6d610cf1f64d9e0e05cb5266d8b56b5c", null ],
    [ "setFont_style", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#ab9c1710d31067b5b1c5305e372ce424d", null ],
    [ "setLine_space", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#aaafe6b488101b3a120fc3574c524e347", null ],
    [ "e_FontStyleNormal", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#ab88ccd3b0b1bed705cc3f206fdfc1ba7", null ],
    [ "e_FontStyleUnderline", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark_text_properties.html#a82ca6e3fcffb3d9c1bf78db86ed3dd8d", null ]
];