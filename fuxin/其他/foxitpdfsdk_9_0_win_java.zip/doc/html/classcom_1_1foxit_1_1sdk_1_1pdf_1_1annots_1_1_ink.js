var classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_ink =
[
    [ "Ink", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_ink.html#a7d33b251b38ad86a4f2dc34541ad3eb2", null ],
    [ "Ink", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_ink.html#a8147193db54a2cb2f21e193885d7b45e", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_ink.html#a9390f39f702281529f194523e2ab19a6", null ],
    [ "enableUseBezier", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_ink.html#a57c369a2c784b7818de2b88c45b12dd9", null ],
    [ "getInkList", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_ink.html#a541f3d1dba7feb0d882880621af494f9", null ],
    [ "setInkList", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_ink.html#a363405e4f4fe3b9d0fde831e45d28bae", null ]
];