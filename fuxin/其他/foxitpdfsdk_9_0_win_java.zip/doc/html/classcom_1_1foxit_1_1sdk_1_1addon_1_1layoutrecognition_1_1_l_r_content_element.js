var classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element =
[
    [ "LRContentElement", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element.html#a92527527f2cf3095c6f3c83b4d4ed66b", null ],
    [ "LRContentElement", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element.html#a651e860f87f368802839c4820033aea4", null ],
    [ "LRContentElement", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element.html#a5027079dd6dc87d7ed510d730a51ea79", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element.html#ad89b93e3c5d591d7c4a06f8d06f57a4a", null ],
    [ "getBBox", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element.html#a55a1aa751f00ed13c8b471c2490d2565", null ],
    [ "getGraphicsObjectElement", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element.html#a8beb1fe75615818245940f0f05946bf1", null ],
    [ "getGraphicsObjectRange", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element.html#ab167232a928e93419dfd8dbfdd4d38a5", null ],
    [ "getMatrix", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element.html#a25812241d1ab47c2c9435316809aa1a6", null ],
    [ "getParentElement", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element.html#acdecaa4bb826965ab351b85170dcaa11", null ]
];