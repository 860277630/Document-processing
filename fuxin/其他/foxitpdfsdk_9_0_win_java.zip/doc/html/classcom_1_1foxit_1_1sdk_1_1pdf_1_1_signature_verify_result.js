var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result =
[
    [ "SignatureVerifyResult", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#aeba5be5591c992e13f1847ea171e79b3", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#aa4e40230cade02b12ff5547f66e963cf", null ],
    [ "getCertificateVerifyResults", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#aad0b1b1fccaacf9b5bbbf8a4ffffb6f0", null ],
    [ "getLTVState", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#ae020f9ccf0bf8f9329534d22f61ab716", null ],
    [ "getOCSPSigantureVerifyResults", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#a7bd24163073f9a76bf52801e389d1539", null ],
    [ "getSignatureCheckTime", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#a8ea31e654872168b2aa50748ffb94fb0", null ],
    [ "getSignatureCheckTimeType", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#a304f0c5b5c7b477d485cb0677c0017fb", null ],
    [ "getSignatureHashValue", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#a76761675c659e4a580f346e482460934", null ],
    [ "getSignatureName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#a52075d20498f64a87813a86a4777b149", null ],
    [ "getSignatureState", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#acda5c068568259b8328f10680d870e82", null ],
    [ "getTSTSignatureVerifyResult", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#a7168ec141fbe2e274a08cad322304e2b", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#a7dbd88a10ffb4acbea1287b69694ee8c", null ],
    [ "e_LTVStateEnable", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#a5202684d057306b008f00aa7378469f5", null ],
    [ "e_LTVStateInactive", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#aedbc468198b3b32432cf1b4cd005bf52", null ],
    [ "e_LTVStateNotEnable", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_verify_result.html#abc5bad7c2d9816c786ea7167eb3538a0", null ]
];