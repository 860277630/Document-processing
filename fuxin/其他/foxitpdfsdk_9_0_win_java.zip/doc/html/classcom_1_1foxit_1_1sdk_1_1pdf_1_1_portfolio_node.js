var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_node =
[
    [ "PortfolioNode", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_node.html#a6fc8b60b298f58e6ba3a676172fdce59", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_node.html#a3ad8149c7273a0471dc91a8ae5850261", null ],
    [ "getNodeType", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_node.html#a1896d12e8d04854d9449ede3ee19261c", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_node.html#ae53c8dd80f29c52a3d46f10b4ccae36a", null ],
    [ "e_TypeFile", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_node.html#a73a14984a2a6c197f1a5fcfc21c78221", null ],
    [ "e_TypeFolder", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_node.html#aefb1d3b55dfec17e625fd3f781dfc446", null ],
    [ "e_TypeUnknown", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_node.html#a4851c231857836c8adee41aab76d3577", null ]
];