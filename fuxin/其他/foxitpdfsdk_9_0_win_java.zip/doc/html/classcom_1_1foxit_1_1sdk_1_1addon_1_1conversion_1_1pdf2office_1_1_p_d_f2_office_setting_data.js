var classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office_setting_data =
[
    [ "PDF2OfficeSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office_setting_data.html#aa4f3fc64054895bfc7a5def612696a03", null ],
    [ "PDF2OfficeSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office_setting_data.html#aa337fd8961a0977e454f67b4ffb76596", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office_setting_data.html#a59dd55b8367760ce7d1a944afc739c20", null ],
    [ "getEnable_ml_recognition", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office_setting_data.html#a43d6436a854388b7aa51784acc981ec2", null ],
    [ "getMetrics_data_folder_path", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office_setting_data.html#a78c7450f3b943b221e8dfca185aa5319", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office_setting_data.html#a17325a08a48537fe09e66399a7516f71", null ],
    [ "setEnable_ml_recognition", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office_setting_data.html#a46bde5dcee992f7d6e9684567b2a8a36", null ],
    [ "setMetrics_data_folder_path", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1pdf2office_1_1_p_d_f2_office_setting_data.html#acb8dd66d7413193baff33f71851763de", null ]
];