var classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_p_s_ink =
[
    [ "PSInk", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_p_s_ink.html#ab6557a91dd145fe7b692bb5915012aff", null ],
    [ "PSInk", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_p_s_ink.html#a15b05343137767ac4eb703716b8ced37", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_p_s_ink.html#a82e1d9693072d4f517173027502e4f0c", null ]
];