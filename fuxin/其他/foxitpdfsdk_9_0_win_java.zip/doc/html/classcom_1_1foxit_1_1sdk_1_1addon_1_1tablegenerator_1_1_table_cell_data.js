var classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data =
[
    [ "TableCellData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#a8aff6b55ad03da7d1a5759effbd25b62", null ],
    [ "TableCellData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#a6f8f7929161ee9460ed62f6d6bff7f10", null ],
    [ "TableCellData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#af2588b9214a28e604356b943946c491c", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#af93ffff753094cb4750fefadbce92928", null ],
    [ "getCell_image", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#ab8a7c4fa3a945769a7471bc7f58ed7f5", null ],
    [ "getCell_margin", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#a74e9d5d1c072f3c776172813b91e1f87", null ],
    [ "getCell_text", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#a1cb8e30767b12ca90b55c7d3d8f0bc20", null ],
    [ "getCell_text_style", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#a11bcf298b482a878d14670eae7b0f352", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#a5239fd8c6b29db2a92aaaece864af029", null ],
    [ "setCell_image", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#a72dce2387ca1d038d2bd98a55748311b", null ],
    [ "setCell_margin", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#a7fbbba28b577ad9f6291703641a49c8f", null ],
    [ "setCell_text", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#adfb941481be934dd1e0f5a34bc5f98a8", null ],
    [ "setCell_text_style", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_cell_data.html#ad92b2910aeb54125e7a4436a3f75fbc0", null ]
];