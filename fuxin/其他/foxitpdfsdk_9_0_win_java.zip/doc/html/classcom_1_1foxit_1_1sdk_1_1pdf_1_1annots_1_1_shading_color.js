var classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_shading_color =
[
    [ "ShadingColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_shading_color.html#a8f967c8c25ea219ee1b2a4c8e11e5cd3", null ],
    [ "ShadingColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_shading_color.html#a68f570de8f786372e68beb31bbd0a6ae", null ],
    [ "ShadingColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_shading_color.html#aa0b05f6171a584c49d182057714e2cc2", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_shading_color.html#a470879d8fb33fe8815cec5ff19c6f545", null ],
    [ "getFirst_color", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_shading_color.html#a0d003025e88831aeeebcca9b6b470c29", null ],
    [ "getSecond_color", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_shading_color.html#ad37574611a53d3740dbcbd817a430007", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_shading_color.html#a238e1c50968264cb3689871e3268ffa3", null ],
    [ "setFirst_color", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_shading_color.html#a41d4dcce045303d500da54a0fcc4682e", null ],
    [ "setSecond_color", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_shading_color.html#a837b3071fe6a4ce692df626e20da007c", null ]
];