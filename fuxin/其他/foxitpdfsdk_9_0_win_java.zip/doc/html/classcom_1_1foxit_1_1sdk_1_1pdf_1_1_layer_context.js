var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context =
[
    [ "LayerContext", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#afcbcea9bd66b5142c83a7f83ce59f7bd", null ],
    [ "LayerContext", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#aa6e6cbce12f3fc5c48637908880460b6", null ],
    [ "copyStates", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#a51f79c3de9ed1b64309ae2d22c32a9f1", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#a16e344fe590496f2fd2234d01decf701", null ],
    [ "getDocument", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#a86cf7b06e05385239337b6a19174f3f8", null ],
    [ "getUsageType", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#a2501ba889a2550bd5e0b3a1d607b109b", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#a4537572fda2238a0b63104a6728f2256", null ],
    [ "isVisible", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#ac834269c09f14558fbb6f67e78eaed0b", null ],
    [ "mergeStates", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#a44385e452b683b46facd6a0c3edc650d", null ],
    [ "reset", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#ad296ec43df675928850d4c0ec2c226f3", null ],
    [ "setVisible", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#aa2d3ea7e35f1dbffebf7eec7e3626245", null ],
    [ "e_UsageDesign", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#a03a84ece6154151c711a3dcbdddcf717", null ],
    [ "e_UsageExport", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#a5778d1ac4ba7e0f9a6b09316c9015099", null ],
    [ "e_UsagePrint", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#aa3e92d00fd71f1b93c981d9035e218ae", null ],
    [ "e_UsageView", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#a30d77d064dcf1b4b3e93740994ef91a8", null ],
    [ "e_UsageZoom", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#ae270a67a382aec287b16d3b4d9053713", null ]
];