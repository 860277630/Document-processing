var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config =
[
    [ "TableOfContentsConfig", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#a17ce1e0b6c1323d7424e2c7e76dca5da", null ],
    [ "TableOfContentsConfig", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#ab8e7be0415bec0e467464c76aacf4d5e", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#ae470b273caa479d275db28cba3cf8c05", null ],
    [ "getBookmark_level_array", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#addf92138d5a2a2466980b3b8fe761c1f", null ],
    [ "getInclude_toc_pages", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#a6062a2c71717f6120ee3a3f4f8fa9f5a", null ],
    [ "getIs_show_serial_number", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#a0c5c39e374221812680293d3f37d6b39", null ],
    [ "getTitle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#afb4d58cac1fe1359aa3f828a76e208cb", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#a6782701751b7a25a2f3e0ff9e9c21f2f", null ],
    [ "setBookmark_level_array", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#a39a54e5cc8675a9496a8e71ce389c410", null ],
    [ "setInclude_toc_pages", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#a9d9ed6100b4869e673bad56936709812", null ],
    [ "setIs_show_serial_number", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#a82538f4a68cdcb3e9db44a5b4dcc9b7d", null ],
    [ "setTitle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_table_of_contents_config.html#a6fa80a9a54340ffe406c4120de5ca703", null ]
];