var classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r =
[
    [ "OCR", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r.html#a8cc14388525e37361efc544c604a1e63", null ],
    [ "OCR", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r.html#a3671789935a6f8f5233f7dbe787325fe", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r.html#aeb8d4693392534e674bed746fd41d05c", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r.html#aa6f807097640e746727337e1ee9d6b60", null ],
    [ "oCRPDFDocument", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r.html#a75ec3d3440afe640c336717a26c16a46", null ],
    [ "oCRPDFDocuments", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r.html#afba379d77bea76e8f4b622aa85222ff0", null ],
    [ "oCRPDFPage", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r.html#a99dcfbdfd303eb88777fc6074ff684e6", null ]
];