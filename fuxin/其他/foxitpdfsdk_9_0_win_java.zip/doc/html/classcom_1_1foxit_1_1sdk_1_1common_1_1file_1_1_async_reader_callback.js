var classcom_1_1foxit_1_1sdk_1_1common_1_1file_1_1_async_reader_callback =
[
    [ "addDownloadHint", "classcom_1_1foxit_1_1sdk_1_1common_1_1file_1_1_async_reader_callback.html#a8ad562af8a0905c57ec5711e6f3de4d4", null ],
    [ "isDataAvail", "classcom_1_1foxit_1_1sdk_1_1common_1_1file_1_1_async_reader_callback.html#aec02a8b95be3ef342de8e92bfce899f9", null ]
];