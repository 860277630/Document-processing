var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_callback =
[
    [ "getTimeStampMessage", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_callback.html#a6c36ae10d5ab6447ff9eb681a86af941", null ],
    [ "release", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_callback.html#a3b7aaa1445f1aaccb3995a61640a5260", null ],
    [ "sendTimeStampRequest", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_callback.html#ad261998b90a4fb81779d9f9928fb18f1", null ]
];