var classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_generator =
[
    [ "addTableToPage", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_generator.html#aa4be1c8f9be14ba9342654dbd059516e", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_generator.html#a17b447aa338c42e99a5a376b5ccace31", null ],
    [ "insertTablePagesToDocument", "classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_generator.html#aeb601ed8f48e54869ee6809aa2a07612", null ]
];