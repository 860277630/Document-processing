/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Foxit PDF SDK", "index.html", [
    [ "Overview", "index.html", null ],
    [ "COPYRIGHT", "page1.html", null ],
    [ "REDISTRIBUTION", "page2.html", null ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Packages", "namespaces.html", [
      [ "Packages", "namespaces.html", "namespaces_dup" ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"classcom_1_1foxit_1_1sdk_1_1_floating_info.html#aeb9d4623ed08a505f0bf4f1c6168fe8f",
"classcom_1_1foxit_1_1sdk_1_1_search_option.html#a325aa3783c8b87337a03acef61ce88c7",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_h_t_m_l2_p_d_f_related_resource.html#a0f66d16e22c73bf6b4bf4f23abed53e2",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element.html#acdecaa4bb826965ab351b85170dcaa11",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_structure_element.html#af948db1d9b2ac39061fe6509497eecef",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1tablegenerator_1_1_table_data.html#aebdfc671d8c8f4a525ba8e235d587f58",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1xfa_1_1_x_f_a_doc.html#a5175c276d730f2c71db022fc7b5680d6",
"classcom_1_1foxit_1_1sdk_1_1common_1_1_constants.html#a485fb6ce35f172d3dfb867b05728613c",
"classcom_1_1foxit_1_1sdk_1_1common_1_1_image.html#a02c104b7a19c2c252f5644c1f2f68429",
"classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_matrix2_d.html#abe6f19dd5b53215b8c7d6459326b39fd",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_associated_files.html#ab68ff20dcff88852e979c39533345a91",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_doc_viewer_prefs.html#a054582505d2fed83aed294818cd72885",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_node.html#a83e29bf0e8b6b82d275ec85dd2186f2e",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_p_d_f_doc.html#acf393d7c57f3f23711abf71a539b5cfa",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio.html#ab6b87fa3c7af46e7985abd7e4633f719",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_schema_field_array.html#a0eb1643f39430921e1d7b4c202900a2c",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_tab_order_mgr.html#a36346b7113741791489ff1feaed47600",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_wrapper_data.html#a62751157a8a95c03358edbf48de3007f",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_annot.html#a030072c417fd1aa10ccb43678941ab8a",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_line.html#a23f2806edcde329e5845f67a2729488e",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_rich_text_style.html#ac6f4ddfa927ae135d76da6498a833a78",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_marked_content.html#a515360aedd86c7f530fe5d93ff8d9cbd",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler.html#aa5718f3c454c9083e3e9fd03bb86b84f",
"deprecated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';