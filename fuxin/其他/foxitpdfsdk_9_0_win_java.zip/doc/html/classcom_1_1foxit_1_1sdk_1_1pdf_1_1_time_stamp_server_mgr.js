var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr =
[
    [ "addServer", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#a5ab6d18d5ab235e585344237ed96903b", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#ad685f33bfd0bace30a8c5aa445d4d7bd", null ],
    [ "getDefaultServer", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#a3d016f3d0cecff041f6d0fbfb7c43cec", null ],
    [ "getServer", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#a767865dd3a43dadd54fd5bc20314a515", null ],
    [ "getServerCount", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#a8257a2f92f240b353bcf1dabf2ae0da2", null ],
    [ "getServerIndex", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#ab5258a2245cfba564ed956f3bb173205", null ],
    [ "initialize", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#ad37c69245cb36ea7825494b347532c74", null ],
    [ "release", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#a6342f91e46a2f2c7b7472867693795fe", null ],
    [ "removeServer", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#a4c75bf3cfcf45868bec19c8cd8db1dde", null ],
    [ "removeServer", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#a35fdab0c2e9ef498732d1b7bcadd0b10", null ],
    [ "setDefaultServer", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#ab7bf99e4175f6f4350f726af58b28a08", null ],
    [ "setDefaultServer", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server_mgr.html#a18880988c103abf21e39cb739525b8d7", null ]
];