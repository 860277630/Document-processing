var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_print_data =
[
    [ "LayerPrintData", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_print_data.html#aba6808ac95d9943ddb441646d795a607", null ],
    [ "LayerPrintData", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_print_data.html#a9de5c48195acf20639b022426ca6ac7b", null ],
    [ "LayerPrintData", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_print_data.html#aceccf447a8778a1cca9f50953cd56699", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_print_data.html#a45d8bf14bee5d824b7a87a4efc8e72ce", null ],
    [ "getPrint_state", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_print_data.html#aea700da80d3aa73995ffdc501daffdbb", null ],
    [ "getSubtype", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_print_data.html#a99a280ff6c66de7df6b32debf0628780", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_print_data.html#a31b787476408dbb2bd756ddee21f79e4", null ],
    [ "setPrint_state", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_print_data.html#a5bbd9ca010c83ea42745ac3492539757", null ],
    [ "setSubtype", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_print_data.html#a7168970cacdfdc5b63697481df773440", null ]
];