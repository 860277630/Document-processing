var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_d_r_m_security_callback =
[
    [ "getCipherType", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_d_r_m_security_callback.html#a8b2c511df8f93ac86f039a7c9806b44e", null ],
    [ "getFileID", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_d_r_m_security_callback.html#a87eae73cbf39bc8f377b2506a87e3b56", null ],
    [ "getInitialKey", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_d_r_m_security_callback.html#a1437259af18984a07f34cd046f4c94fa", null ],
    [ "getKeyLength", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_d_r_m_security_callback.html#a47b5ce4355c470c8befb7002d07a11e3", null ],
    [ "getSecurityType", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_d_r_m_security_callback.html#a0fcfbd8c61fcae19c7fd9bf6d1ac6cd3", null ],
    [ "getUserPermissions", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_d_r_m_security_callback.html#a1ca1479b8b2ab08720ea0e1bf31c8708", null ],
    [ "isOwner", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_d_r_m_security_callback.html#a60aef41f67c4f13f8b9cde0fcf012192", null ]
];