/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Foxit PDF SDK", "index.html", [
    [ "Overview", "index.html", null ],
    [ "COPYRIGHT", "page1.html", null ],
    [ "REDISTRIBUTION", "page2.html", null ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Packages", "namespaces.html", [
      [ "Packages", "namespaces.html", "namespaces_dup" ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"classcom_1_1foxit_1_1sdk_1_1_identity_properties.html#a6737ea4c0e1aab83594528fd8b08d550",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_border_info.html#a4043ea965dd10ba1c6c7b7a1561700f1",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_result_information.html#adca1b0d4d773ab7e869c70220c3271aa",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_element.html#aa976b5bdc1f14e2ded0b959659dee243",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_optimizer_settings.html#a2ffb6b5bf4f982681b240b646cb831e1",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1xfa_1_1_widget_menu.html#a47b210cb9ed2437abd465dadd50986e0",
"classcom_1_1foxit_1_1sdk_1_1common_1_1_constants.html#a198cea624d744c10f4ad7039b2524620",
"classcom_1_1foxit_1_1sdk_1_1common_1_1_graph_state.html#a2e141d270629d3517e8e6e9889357302",
"classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_matrix2_d.html#a3d1845e24cd5b8caa8a72f0dfdc92bdc",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_settings.html#afc25ee2f0ac8c49e9684cb823f4bbf23",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_d_r_m_encrypt_data.html#ac9404f692476f04e7205c5b8b4187c9d",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_layer_context.html#aa3e92d00fd71f1b93c981d9035e218ae",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_p_d_f_doc.html#aacdf18a68de07f27e802ed70bcbe4375",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#af5dc4d8b029e929638604d95405c7237",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_revocation_callback.html#ab4892da9c6a102076c43be64d452290e",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_std_security_handler.html#aa05c75b857cb1d0e5b41c80805e6320d",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_wrapper_data.html#a0f45c3e638af34e96f8a3ba49839514e",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_u_r_i_action.html#a9184af038cdc104e846516982ea00ce6",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_line.html#a1a772169100a3511568a896ce5dc25f3",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_rich_text_style.html#ac67da08ad47df1693b4f0d501aded325",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_marked_content.html#a46eeafcc26e154224812807767bec30d",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler.html#aa396dbbafbead32b5369e9d384669fed",
"classes.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';