var classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data =
[
    [ "FixupData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#a82a0ac0260358b0428d7de0a4725b5d1", null ],
    [ "FixupData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#adfd90eb32d1f1b7c805e1aedda6512af", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#a1613158f1471eb7aaafb0acd6e630ec8", null ],
    [ "getComment", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#aab65e191223b6a0d197b309567dddd6a", null ],
    [ "getName", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#aa45902dab9674750331074cd416c3e3a", null ],
    [ "getReasons", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#a6f10a8f7ae67f5e58d4ed41286206d3b", null ],
    [ "getState", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#a6f83a2baec10ce0a6393236da2655141", null ],
    [ "getUsed_count", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#a11d6584ae6d0ba297750a015153ecdab", null ],
    [ "setComment", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#a3563805db020517c5277c3d8f6406db3", null ],
    [ "setName", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#afb61734147dabb80515de2cc0bd80e5e", null ],
    [ "setReasons", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#a667e6c7a30596a7b483d3f86fada2a47", null ],
    [ "setState", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#a5d09fd6dd765b82cfdc7b3aaf97fb55c", null ],
    [ "setUsed_count", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#a62269f963e934aeb11d3e510ed8fb65e", null ],
    [ "e_FixupStateFailure", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#af929b1a76cd13e6da3587cc37c8149a9", null ],
    [ "e_FixupStateNotRequired", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#a5418ea3294db51aa0b8fba74fa985e68", null ],
    [ "e_FixupStateSuccess", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html#a4a61bd36b1cdc52597880d0e2f585eb4", null ]
];