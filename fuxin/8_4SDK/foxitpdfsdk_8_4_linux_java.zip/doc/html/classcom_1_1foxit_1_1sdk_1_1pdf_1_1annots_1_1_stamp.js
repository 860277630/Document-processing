var classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_stamp =
[
    [ "Stamp", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_stamp.html#aae30dc8986fb1205b767229ac97f3e6d", null ],
    [ "Stamp", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_stamp.html#a766b4edf630b68a3fea22c292e3c18dc", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_stamp.html#a55740e50a293d9d5721e637533be0fcc", null ],
    [ "getIconName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_stamp.html#ac33fbde98d87d15c73e8f43fd6a87066", null ],
    [ "getRotation", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_stamp.html#a9a778c57e9b5110144b43a7dddf93cc0", null ],
    [ "rotate", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_stamp.html#a06c02c85a0c8964192ec671694988fa6", null ],
    [ "setBitmap", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_stamp.html#a431e34220aa1cc7c95e8aa017634483f", null ],
    [ "setIconName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_stamp.html#aee56482d2152298f82477fe40f05009e", null ],
    [ "setImage", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_stamp.html#a2b596d75dd675eaafe9a949e6513f42e", null ],
    [ "setRotation", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_stamp.html#accbe7c3ff47c35bbcd7c4343069a2842", null ]
];