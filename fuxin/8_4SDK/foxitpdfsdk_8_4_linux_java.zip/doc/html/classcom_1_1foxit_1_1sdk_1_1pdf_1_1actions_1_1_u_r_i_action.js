var classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_u_r_i_action =
[
    [ "URIAction", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_u_r_i_action.html#af53e89a320a632dc8a82d9bb7ec1acb0", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_u_r_i_action.html#a7bc263d91019bb0454418b588efb66ea", null ],
    [ "getURI", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_u_r_i_action.html#abebb8a783bac49ed6e9d460671fd4c26", null ],
    [ "isTrackPosition", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_u_r_i_action.html#a431b47129e9b803b9c0d0a5d581e8ecf", null ],
    [ "setTrackPositionFlag", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_u_r_i_action.html#a9184af038cdc104e846516982ea00ce6", null ],
    [ "setURI", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_u_r_i_action.html#a85b8c939dddb9a1a5fc71e16197be4cf", null ]
];