var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary =
[
    [ "AnnotationSummary", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary.html#a455a62e14629fea52591d720582205df", null ],
    [ "AnnotationSummary", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary.html#aef70b37db51518bf7c7c045620c40392", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary.html#ae7b6ca0a6c850bc5bbe98eb592a11557", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary.html#ac87e8b5d75a81257ed7a207feb55bc88", null ],
    [ "setCallback", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary.html#aab29a173b4e79f9f9b2ed4b39adffdad", null ],
    [ "startSummarize", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary.html#a8ddd87db86cbd075bd92b6f79dd1dc09", null ],
    [ "startSummarize", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary.html#a21095ca640f518200f1ffc7e176fc96c", null ]
];