var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_snapped_point =
[
    [ "SnappedPoint", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_snapped_point.html#a0377c3882c3369d97748ed3b93cf9b45", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_snapped_point.html#a9c759c25d68812b6b4a947bb45296cb6", null ],
    [ "getPoint", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_snapped_point.html#ace18ecac11f90f3d4b755dfdb9c4f082", null ],
    [ "getType", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_snapped_point.html#aa2bf4b87375d736763fc49a3605cc87d", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_snapped_point.html#a5f9877d255a7ec376525bee28a9fb62b", null ],
    [ "e_TypeEndpoint", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_snapped_point.html#ab30c0bc67e87a55bbec58977641e3f4a", null ],
    [ "e_TypeIntersectionPoint", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_snapped_point.html#af9239a85d018c78d8cfbb92eeed20e13", null ],
    [ "e_TypeMidpoint", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_snapped_point.html#a07d204a2701796552acc95f1d9bd60de", null ],
    [ "e_TypeNearestPoint", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_snapped_point.html#aa808db91168995c14c8d3bd1996846eb", null ],
    [ "e_TypeNone", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_snapped_point.html#af7c0a4c9271b894ccc6ef6d20b6cf704", null ]
];