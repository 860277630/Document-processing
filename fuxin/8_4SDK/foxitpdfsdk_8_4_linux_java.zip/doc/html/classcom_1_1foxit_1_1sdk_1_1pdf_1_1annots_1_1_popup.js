var classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_popup =
[
    [ "Popup", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_popup.html#a91dedd8201ffb7843439afd355f854dd", null ],
    [ "Popup", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_popup.html#ad78e5cd0ca5fbc194031fd7cbb062e17", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_popup.html#a60e6cf84d9c1378b37197a3196cd1689", null ],
    [ "getOpenStatus", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_popup.html#af44c6ab43a556cfa4d4cb4951dc4ddb2", null ],
    [ "getParent", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_popup.html#a4ddcc50bd983e6a1b6cf7f5601782038", null ],
    [ "setOpenStatus", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_popup.html#ac3df428b38a31b57f136293c2c9e1216", null ]
];