var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback =
[
    [ "createContext", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#a64cff4bac588b23226b37864d00da6c5", null ],
    [ "decryptData", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#a8770a909d49c957ed20f16116fbf1fba", null ],
    [ "encryptData", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#a1148c8729c69519fb518f314ff940c0f", null ],
    [ "finishDecryptor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#a739ac331f39ba507d587fcb27a02bd66", null ],
    [ "getCipher", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#a90ce739aee4cb2a1f71b779c98dab899", null ],
    [ "getDecryptedSize", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#ae6434976748603f6d3239c72bc3d62ff", null ],
    [ "getEncryptedSize", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#a4e8b1d7d1414e9249240b7a95b3979d4", null ],
    [ "getEncryptKey", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#afc7d76a4ac90496c5e7b096765c71ff2", null ],
    [ "getSecurityType", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#a96ff47319b497c6b0b4e95099415c271", null ],
    [ "getUserPermissions", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#a501bcde70ff5c315e349681ccfb1360b", null ],
    [ "isOwner", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#aef2c3063d160307d7fe88867834dea17", null ],
    [ "releaseContext", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#a936ba9d2fc753ca65f57ab8d9bc7b306", null ],
    [ "startDecryptor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#a931821a3f923e2adf3c34efff7ad8205", null ],
    [ "useStandardCryptoMethod", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_callback.html#a36434196b6f7385e9837557ff5558c57", null ]
];