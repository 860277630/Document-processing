var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_search_cancel_callback =
[
    [ "needToCancelNow", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_search_cancel_callback.html#ac79ae4b3d6a3b7dafc6a1b35f041cf38", null ]
];