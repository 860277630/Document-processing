var classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text =
[
    [ "FreeText", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a6158c778ce4eb58dbda2366206ccc9da", null ],
    [ "FreeText", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#abaaf0bacb455585fc9b7c5240ad6b6e5", null ],
    [ "allowTextOverflow", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#afc73d459083c85c1bbb466ed70b720e9", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a32331e6886b0f94f8a5a5089e8bf224e", null ],
    [ "getAlignment", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#ac242e6f508b949aa81f2706023f65e6c", null ],
    [ "getCalloutLineEndingStyle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a610ec489f7b6b8e81d5c070c9b1c2c01", null ],
    [ "getCalloutLinePoints", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a9f6d69a15a4d284e95c03cdbb380f259", null ],
    [ "getDefaultAppearance", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a5b59b686b95f77b8496918e37ee0b49c", null ],
    [ "getFillColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#add34d2a83e4a628ba6f6fe574dbf8069", null ],
    [ "getInnerRect", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a447f5e849789ac84159595dabc688876", null ],
    [ "getRotation", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a42987176a49c0fcce0f5b14bc7988076", null ],
    [ "getTextMatrix", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#aecd7e6c26d205b0c08fc7feeb31cfaf5", null ],
    [ "rotate", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a6b54f6946f40eebb110c999e14a54422", null ],
    [ "setAlignment", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a955b63aefae31ef31fa1dc018ade37ed", null ],
    [ "setCalloutLineEndingStyle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#af404141e5e57925ca308aeec297db9b4", null ],
    [ "setCalloutLinePoints", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#ad7bacb316a98bed893acca9edfbd09ee", null ],
    [ "setDefaultAppearance", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a35d664cd3e37713ca0dd6714dca66315", null ],
    [ "setFillColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a71ec76dba1f09a7194bf692b1b7776a1", null ],
    [ "setInnerRect", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a79b4b8b57fb6b6907b89f53d29966d72", null ],
    [ "setRotation", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a04946bc201ec4e97fcbc2ae9987a4ba9", null ],
    [ "setTextMatrix", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_free_text.html#a55a329dd84f51991c595c69283e4c446", null ]
];