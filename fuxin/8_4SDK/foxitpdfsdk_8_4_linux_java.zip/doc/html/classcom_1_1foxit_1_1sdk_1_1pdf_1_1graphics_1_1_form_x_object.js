var classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_form_x_object =
[
    [ "create", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_form_x_object.html#a21fbfdb2a43b587a58c40cb4649f46ea", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_form_x_object.html#a21b663b63f496cb60d71fb0a1fe6f18e", null ],
    [ "getGraphicsObjects", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_form_x_object.html#a648be6069c0035dbb17dd0db33e3a2c0", null ],
    [ "getStream", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_form_x_object.html#a6ba6b77c1b31e0e3bb039f7505c4080e", null ],
    [ "importPageContent", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_form_x_object.html#ac8453dc6a26d2c6c23ce9f8d0a6cd432", null ]
];