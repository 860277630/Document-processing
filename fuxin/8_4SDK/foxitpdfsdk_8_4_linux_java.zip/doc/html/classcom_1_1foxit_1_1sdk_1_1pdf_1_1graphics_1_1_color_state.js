var classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_color_state =
[
    [ "ColorState", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_color_state.html#a8402f7d042eb9b7bf1c29eab994ba9a0", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_color_state.html#a2f791443011bb657b4a2fab4f5501c30", null ],
    [ "getFillColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_color_state.html#a595b17686cc4b5bbdca245c11dd66125", null ],
    [ "getStrokeColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_color_state.html#aec705924f87a23306b9f039feef96122", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_color_state.html#a26663c46ac5311c9b14ec5722f80dad4", null ],
    [ "setFillColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_color_state.html#aecde0b84f14b6be8261e3c9ff4a70e00", null ],
    [ "setStrokeColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_color_state.html#a00c99d823ae600c57123523341182cde", null ]
];