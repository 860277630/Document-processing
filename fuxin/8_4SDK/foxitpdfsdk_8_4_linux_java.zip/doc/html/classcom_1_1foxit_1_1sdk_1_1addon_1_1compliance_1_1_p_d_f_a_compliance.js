var classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance =
[
    [ "PDFACompliance", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#a830ce7e96327227a6812fcaeb51a48ee", null ],
    [ "PDFACompliance", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#af2bc9ade43b6a300f19c7f58eb1a030d", null ],
    [ "convertPDFFile", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#a4b26ea062843354396fbd1aa29a13a83", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#aeb4eddd5ab5535e0143ec435bc9c5335", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#a10e28fb0f6d1562eadf78e86738957d8", null ],
    [ "verify", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#afe322df5bb92739ab8af8099ef2f13a1", null ],
    [ "e_VersionPDFA1a", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#aed66ec39dc0a3c4e3882beb2cfdc3d8d", null ],
    [ "e_VersionPDFA1b", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#a88c786237e34d87580ff343bfbe9bafd", null ],
    [ "e_VersionPDFA2a", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#a4bbc29011d396fd234d855bbc7931776", null ],
    [ "e_VersionPDFA2b", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#a7b4b2ca79e99328cc03229cd596065bb", null ],
    [ "e_VersionPDFA2u", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#ac28341e52c2b8ce92e20dd26d232c797", null ],
    [ "e_VersionPDFA3a", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#aa37e6d918751cbe8e23ffb3958fb0324", null ],
    [ "e_VersionPDFA3b", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#a2e9fa913b91dc6466d98471720f389fa", null ],
    [ "e_VersionPDFA3u", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html#af9fd33a466124470ec29c6aae6872013", null ]
];