var classcom_1_1foxit_1_1sdk_1_1_menu_item_config =
[
    [ "MenuItemConfig", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a4b2d28c2fa44e4c2bea4594ec005c08c", null ],
    [ "MenuItemConfig", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#ab602edd0e5dc436bbf12977490f2b626", null ],
    [ "MenuItemConfig", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a2503d6b248c374cbbad17f725b5a860e", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a921439c281b7ef681d846030ab14ea84", null ],
    [ "getEnable", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a720af05816805b323312704236f6cf21", null ],
    [ "getExec", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#abccade0b32bf4edc3d826af7bd75c755", null ],
    [ "getMarked", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a0fc7d9ff06fc1562c91b55024831459c", null ],
    [ "getName", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#ae3ffd0c59f727aeb065a6c9ea96753ee", null ],
    [ "getParent", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#adde2a5443de6f8f5cefaf564b78cd9b9", null ],
    [ "getPos", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a0d4d168ec242d13dd3b22d3b6554df95", null ],
    [ "getPos_str", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a019da942bd4da554b3cdf817af132383", null ],
    [ "getUser", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#aaf33d2263a22686a574a547038a17450", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a29eef872b72d1372986f91bf65781212", null ],
    [ "setEnable", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a6dc6232cf54166b429ba7ffbfc25adb1", null ],
    [ "setExec", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#aa909110bc3f8ab34037248d52e20efe4", null ],
    [ "setMarked", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a240f359f4dd9013dc60b0e50279ad120", null ],
    [ "setName", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a708421d83237b3e556ebaa8ee4fc1b75", null ],
    [ "setParent", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#adcfecabca1fbc9657d4f8f1d6396166a", null ],
    [ "setPos", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#aef5b2ff52818c18cb5a22a2ac72c77ad", null ],
    [ "setPos_str", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a90d86a5572620803612ff7dccac692f7", null ],
    [ "setUser", "classcom_1_1foxit_1_1sdk_1_1_menu_item_config.html#a03d794b5d6532ed5e340801dff731ecc", null ]
];