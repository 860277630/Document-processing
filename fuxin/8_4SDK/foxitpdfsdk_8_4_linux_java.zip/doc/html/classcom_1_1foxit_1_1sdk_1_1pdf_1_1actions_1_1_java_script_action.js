var classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_java_script_action =
[
    [ "JavaScriptAction", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_java_script_action.html#a61b86bcf7941331818c6efe6581ee2d5", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_java_script_action.html#ab73a499933f7a2080e584adb073e5b1a", null ],
    [ "getScript", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_java_script_action.html#a588f7d9650c1bdbe8fc04a8c91e2d042", null ],
    [ "setScript", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_java_script_action.html#a1a2520093e08c25f8ad1b956e42cb928", null ]
];