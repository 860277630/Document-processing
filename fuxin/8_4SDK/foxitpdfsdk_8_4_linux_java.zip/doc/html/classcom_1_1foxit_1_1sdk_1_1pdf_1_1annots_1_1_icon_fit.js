var classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit =
[
    [ "IconFit", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#aee757f8b19ae442e8b01398595f0845b", null ],
    [ "IconFit", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a3b64f677567aac92f2297d6eb3579d11", null ],
    [ "IconFit", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a58c8b245cbbdbf9cb3f93965b2ff9430", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#acae1ab76a73554619e8a8f041ba3753c", null ],
    [ "getFit_bounds", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#aa8327a0a2a3dae62790d52754d0ed44e", null ],
    [ "getHorizontal_fraction", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a225e9e08b1691fb1670ea6437817ffb4", null ],
    [ "getIs_proportional_scaling", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a7a926c435b0d3cf73a3dabc0016e4f05", null ],
    [ "getScale_way_type", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a14323391c1a9f056d966f0e127507de6", null ],
    [ "getVertical_fraction", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a84527bc545f8c18097ba024c8b41f5b6", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#ac6fe25aedca046e0508e4439e030203c", null ],
    [ "setFit_bounds", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a25d697bbeb4add6f60337348028396fd", null ],
    [ "setHorizontal_fraction", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a22521c2e461b2309d9654ef4c8d7797c", null ],
    [ "setIs_proportional_scaling", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a6d599edfb6be96ff58e18275e8e33b2e", null ],
    [ "setScale_way_type", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#aa124cea7a3df62ac1a885aecd4771ec2", null ],
    [ "setVertical_fraction", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a86e4c522b155cf073355bd67717f9561", null ],
    [ "e_ScaleWayAlways", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a259007794e3902abf274d67d8be2667a", null ],
    [ "e_ScaleWayBigger", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#aba396bce8ab2a610ff0111e7b91cef28", null ],
    [ "e_ScaleWayNever", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a56908232bbf35cf7bb54919225870601", null ],
    [ "e_ScaleWayNone", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a0e790197351db0531a4502ba320b2009", null ],
    [ "e_ScaleWaySmaller", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_icon_fit.html#a0ddf15c07ea35c1ef8de635aff474030", null ]
];