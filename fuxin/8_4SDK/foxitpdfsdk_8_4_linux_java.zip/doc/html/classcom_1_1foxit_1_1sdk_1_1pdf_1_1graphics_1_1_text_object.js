var classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_text_object =
[
    [ "create", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_text_object.html#ad5f7d56813beeb8f3d6e14f5bd3128b7", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_text_object.html#a782a0913052b1fba6df4174da1ec750a", null ],
    [ "getCharCount", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_text_object.html#a1618a3157db1752bd9a4349778337fc7", null ],
    [ "getCharHeightByIndex", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_text_object.html#a487b49e4a1fedeacdf4ac73ecdfdf2dc", null ],
    [ "getCharPos", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_text_object.html#a799880882d939b90969306956f308189", null ],
    [ "getCharWidthByIndex", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_text_object.html#aae7aecfdd77f6ec90f39cde1a59bbeb6", null ],
    [ "getText", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_text_object.html#aa01c5d5c193109b4fdb3ee87ca17b638", null ],
    [ "getTextState", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_text_object.html#af8ac7ee02539f5851bea19401a313dbf", null ],
    [ "setText", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_text_object.html#aa1cfc3e2acc1ac99b96c247a4d94ab04", null ],
    [ "setTextState", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1graphics_1_1_text_object.html#a2a234a25013fa07a85889afe4e405693", null ]
];