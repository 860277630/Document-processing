var classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_unembedded_font_settings =
[
    [ "UnembeddedFontSettings", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_unembedded_font_settings.html#a6bac2bdc6fb1831ffef6be37a303189a", null ],
    [ "UnembeddedFontSettings", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_unembedded_font_settings.html#a9c71afe4e0110b81cdaaf7e502817c61", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_unembedded_font_settings.html#ac0722ccc64ac9682dcd317820303a7ab", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_unembedded_font_settings.html#a24c9ca53e83641ff14cf3bb63bc264ed", null ],
    [ "setUnembeddedFontNameArray", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_unembedded_font_settings.html#a158a3223c6efa6af7f4a0a7bd4f2486b", null ]
];