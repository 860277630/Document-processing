var classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_progress_callback =
[
    [ "release", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_progress_callback.html#a5f0e792ae92a1200ec82845d7f4598a3", null ],
    [ "updateCurrentStateData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_progress_callback.html#a446afbea1f8cf3668017f66703384f22", null ]
];