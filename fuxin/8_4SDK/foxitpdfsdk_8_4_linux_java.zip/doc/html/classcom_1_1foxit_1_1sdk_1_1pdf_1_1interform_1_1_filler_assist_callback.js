var classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback =
[
    [ "appendPopupMenuItem", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#af778c58fecca6f67edf1a43905c7b27d", null ],
    [ "createPopupMenu", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#a44fd3493c3360e1634c6428305229975", null ],
    [ "destroyPopupMenu", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#a10829e2eaf2a140797df52b17253fb28", null ],
    [ "enablePopupMenuItem", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#ab0b29015f6374470e747a5799caff80c", null ],
    [ "focusGotOnControl", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#a1cd4ae5c007c3523e47a3b467137be68", null ],
    [ "focusLostFromControl", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#af85b0aa3d241c03537cc23ee2b1d588f", null ],
    [ "getClipboardText", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#a0e9027a576b0f1149a3b47719802fec4", null ],
    [ "getVersion", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#a788e9db7ef15b4a05675818cd5bf0e54", null ],
    [ "killTimer", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#aa4fc59bd3305c6408e9787c97bb1106d", null ],
    [ "refresh", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#a3a8caf05db39855480b13a68781881e4", null ],
    [ "release", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#a91e355d082d0daa745ed24bca635e3e1", null ],
    [ "reportInvalidValue", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#a1a8bd9c57e87793fc1b656d980773e31", null ],
    [ "setClipboardText", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#ac404f6bd5351f6999705c1f851dba83c", null ],
    [ "setTimerCallback", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#afd743f6ac98a3990b8f4e8c633cf514c", null ],
    [ "showPopupMenu", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#a93fb8521535ea79b180f203d62aba68c", null ],
    [ "e_PopupMenuItemCopy", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#abe121c40f5617d5d8acbdfcdd72ac47f", null ],
    [ "e_PopupMenuItemCut", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#abd752a08ff4a465707adf52f10f4bd45", null ],
    [ "e_PopupMenuItemDelete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#a1594ee4a634dc9bc180386d33320eec6", null ],
    [ "e_PopupMenuItemNone", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#ae801d9eafd77ba6d6901c30404fd9770", null ],
    [ "e_PopupMenuItemPaste", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#af8440e865d926476d1d17f1a6429f412", null ],
    [ "e_PopupMenuItemSelectAll", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_filler_assist_callback.html#a34ac397b169c4da253538959f4f4f994", null ]
];