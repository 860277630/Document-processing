var classcom_1_1foxit_1_1sdk_1_1_player_args =
[
    [ "PlayerArgs", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#a7e21c9f53e97129351ea3ec8f5a629c1", null ],
    [ "PlayerArgs", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#a8fb08a06a3b49378d782fff035e6949f", null ],
    [ "PlayerArgs", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#af96e4fce4110368818cd024f0c6c728f", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#a841be7b51a2a637f6c079944996dbe12", null ],
    [ "getAudio_format", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#aacdba3cda94a7cb3047957f413e651da", null ],
    [ "getDoc", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#a44ba2f5ed0bb505f3f61f885f8766264", null ],
    [ "getPlayer_settings", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#a2aa5389c445e45bfd2a08aeb6d691d72", null ],
    [ "getRendition", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#ac23648da6405981a5f782432ac23e6fd", null ],
    [ "getScreen_annot", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#a39a979d38a69254d413db70fc20b536c", null ],
    [ "getURL", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#ad4def197c2e3bfd08b658329bd35d537", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#a60ff9cf7bb75103952d4bc9a0c428f8d", null ],
    [ "setAudio_format", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#adb9284d338ed5d6c8353565ecf6f9456", null ],
    [ "setDoc", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#ae7e55d01a1e723638a67b5c6270f24f3", null ],
    [ "setPlayer_settings", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#ac13f45f61830b9eb34348f24f47bd552", null ],
    [ "setRendition", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#abaca8d4aeb5ab67cba450c81e83b042b", null ],
    [ "setScreen_annot", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#af02808824fc54c5f300bec672e1a2a22", null ],
    [ "setURL", "classcom_1_1foxit_1_1sdk_1_1_player_args.html#af2d663c95757b89f1adcff7d53672d79", null ]
];