var classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_file_attachment =
[
    [ "FileAttachment", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_file_attachment.html#aa926dc3d167dcf138f3189938b458037", null ],
    [ "FileAttachment", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_file_attachment.html#aa6a9267c12d64bde3324d86db597ce11", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_file_attachment.html#a6618cb236719d0e42ebf36af35ea1f76", null ],
    [ "getFileSpec", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_file_attachment.html#a94c9a2c91ceb9bd05c10a9f26db8c22d", null ],
    [ "getIconName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_file_attachment.html#a4cddcd0898053418b581c73aff3e2e77", null ],
    [ "setFileSpec", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_file_attachment.html#aab18d3cc494262b10af3d0474f9de9e6", null ],
    [ "setIconName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_file_attachment.html#a78f13bf33086cb67e86d7be3a28e2c8f", null ]
];