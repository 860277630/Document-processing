var classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_context =
[
    [ "LRContext", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_context.html#a6970620a95d542a0d8db3b2330694e69", null ],
    [ "LRContext", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_context.html#a617254d44f248281046602d0798e8f88", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_context.html#a5d357283e1e92f8825f9aa1afbb11eb4", null ],
    [ "getRootElement", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_context.html#ab2423e8c6784f5a549d0418f609223f2", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_context.html#afb7834abaaf2fb3340af81fdeb032f93", null ],
    [ "startParse", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_context.html#a848eb47f3ff361b0e13948af2623a041", null ]
];