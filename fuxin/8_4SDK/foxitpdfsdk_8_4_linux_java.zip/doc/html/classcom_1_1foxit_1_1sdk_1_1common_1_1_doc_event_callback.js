var classcom_1_1foxit_1_1sdk_1_1common_1_1_doc_event_callback =
[
    [ "onDocOpened", "classcom_1_1foxit_1_1sdk_1_1common_1_1_doc_event_callback.html#a29052fdfaba816bd53031af511a1986d", null ],
    [ "onDocSaved", "classcom_1_1foxit_1_1sdk_1_1common_1_1_doc_event_callback.html#a085bedb3f2091d39d8fe2fd2f4ff03ba", null ],
    [ "onDocWillDestroy", "classcom_1_1foxit_1_1sdk_1_1common_1_1_doc_event_callback.html#a7fc5e4382621e1ba28f9ad85db90b37d", null ],
    [ "onDocWillOpen", "classcom_1_1foxit_1_1sdk_1_1common_1_1_doc_event_callback.html#aac023b92050957b1b8c1ad9c7ebea366", null ],
    [ "onDocWillSave", "classcom_1_1foxit_1_1sdk_1_1common_1_1_doc_event_callback.html#ac051086c1b9e922f69810397ca898ded", null ],
    [ "release", "classcom_1_1foxit_1_1sdk_1_1common_1_1_doc_event_callback.html#ab9c1c1bfcc2e1ba09e46cdd8119c0473", null ]
];