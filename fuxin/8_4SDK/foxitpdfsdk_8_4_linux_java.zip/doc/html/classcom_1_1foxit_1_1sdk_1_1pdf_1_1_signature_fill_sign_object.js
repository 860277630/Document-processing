var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_fill_sign_object =
[
    [ "SignatureFillSignObject", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_fill_sign_object.html#a3332dd05ef0036e19fb14658686405fd", null ],
    [ "SignatureFillSignObject", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_fill_sign_object.html#a9b4ea45a30f6283fa5deaff92b17653a", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_fill_sign_object.html#ab733d1954b12afa75cca5d38ed08f36c", null ],
    [ "isInitialsType", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_fill_sign_object.html#a6c55d8f12c4e11e10a2c04fe287943e6", null ],
    [ "setBitmap", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature_fill_sign_object.html#ac8b8d58f37674cacc2989d1580203014", null ]
];