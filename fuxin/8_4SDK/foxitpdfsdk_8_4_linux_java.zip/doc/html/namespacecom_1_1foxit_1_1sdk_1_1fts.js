var namespacecom_1_1foxit_1_1sdk_1_1fts =
[
    [ "DocumentsSource", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_documents_source.html", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_documents_source" ],
    [ "FullTextSearch", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search.html", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_full_text_search" ],
    [ "SearchCallback", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_search_callback.html", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_search_callback" ]
];