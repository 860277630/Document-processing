var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_std_security_handler =
[
    [ "StdSecurityHandler", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_std_security_handler.html#ab127b6a34ab69931ee6632839f65891e", null ],
    [ "StdSecurityHandler", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_std_security_handler.html#a1f9a419fbbc0b44b6983639f0c7bedfc", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_std_security_handler.html#a85f5e309a19932cf2494a664e98efcf0", null ],
    [ "initialize", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_std_security_handler.html#aa05c75b857cb1d0e5b41c80805e6320d", null ],
    [ "initializeW", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_std_security_handler.html#aaae4ea40f0b3858666bd5862fd44a458", null ],
    [ "setAES256ModifyFlags", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_std_security_handler.html#a717189cd3d6882731f1fa0a1787d64ab", null ],
    [ "e_ModifyOwnerPassword", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_std_security_handler.html#a7ad47c58ed2914b0e94b6845c1abee56", null ],
    [ "e_ModifyPermission", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_std_security_handler.html#ab234e90de2611161a8689985df3a4cbe", null ],
    [ "e_ModifyUserPassword", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_std_security_handler.html#a90b9c13500c1312bd78ddaf67c2eb8e5", null ]
];