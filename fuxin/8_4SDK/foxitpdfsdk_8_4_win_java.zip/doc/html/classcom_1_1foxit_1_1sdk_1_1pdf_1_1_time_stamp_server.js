var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server =
[
    [ "TimeStampServer", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#a83852b695e852ac9c2b167b6d7d1a0ef", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#a3d9d2e9b1bf75adbb4f7bf35e32985e6", null ],
    [ "getTimeStampMessage", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#ac5b24c8b1a3510be68f2b42e80c2bf34", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#af81989069709df16562b628d4fe81770", null ],
    [ "sendTimeStampRequest", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#a97bbe8fd30dbc70a53008612368f91b3", null ],
    [ "e_SendResultFailToConnect", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#a3f7a84e0808b62335a41712939a2e657", null ],
    [ "e_SendResultFailToCreateSocket", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#ae76ee183ebc2a28dab96e3e35d808928", null ],
    [ "e_SendResultFailToGetData", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#afd4d629d9e61dbe453a6ffb44c76150b", null ],
    [ "e_SendResultFailToReceiveData", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#a2f88c4599186d90d8da2e536f4431267", null ],
    [ "e_SendResultFailToRequest", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#a85888ced67bf768482da8f5814c8129e", null ],
    [ "e_SendResultFailToSendData", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#aa6fcdfa33bd347c2e5fefcf31950c844", null ],
    [ "e_SendResultOutOfMemory", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#a8c72535d9c861f8ee2cc610a4aed1558", null ],
    [ "e_SendResultSuccess", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_time_stamp_server.html#a695935eaef9804e792aab6ad7ceb2b60", null ]
];