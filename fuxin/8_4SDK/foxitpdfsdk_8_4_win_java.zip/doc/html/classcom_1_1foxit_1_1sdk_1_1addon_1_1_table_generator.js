var classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_generator =
[
    [ "addTableToPage", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_generator.html#a35002638cedf049deff323b7d27530a3", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_generator.html#ae748b9e5a7fd947c2648be00ccab7474", null ]
];