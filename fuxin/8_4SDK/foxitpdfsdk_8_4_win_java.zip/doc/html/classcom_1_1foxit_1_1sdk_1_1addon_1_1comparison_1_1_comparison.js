var classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison =
[
    [ "Comparison", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison.html#af70d2fc8567511095bc661e308019dff", null ],
    [ "Comparison", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison.html#a2e271e98a684324d1467b6ae8dfe16db", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison.html#a98d5b783bf8995817c2254421562a766", null ],
    [ "doCompare", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison.html#af50b313d2292b5519a4c003079e52d3e", null ],
    [ "generateComparedDoc", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison.html#ae87d7be650d7b49a75363d1c740a59a9", null ],
    [ "generateComparedDoc", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison.html#a3f15857da067c7aefc953cd876ec1f4e", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison.html#a0d63bf5b70aa370df508a98137d05a3c", null ],
    [ "e_CompareTypeAll", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison.html#a247a32efa942cca9a6832db8f15d0714", null ],
    [ "e_CompareTypeAnnotation", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison.html#a33a08d37bb62590f0af14d08022edcbc", null ],
    [ "e_CompareTypeText", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison.html#adfd5c59aff34eef6371842bdc1e5fa2c", null ]
];