var classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f =
[
    [ "PointF", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#a7c3d0df7c38eb53a981b60b7624410a3", null ],
    [ "PointF", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#a8b610bcb75cee252e58a36ca73a93ab8", null ],
    [ "PointF", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#a2c1bfb6b5be920ff76b97c31db34bee5", null ],
    [ "add", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#a86759022b2235f25a64d70aa31b4b7ab", null ],
    [ "getX", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#a5c8976b20a96e594e55a9d852c87bcd7", null ],
    [ "getY", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#a4639c0fe8629d95552cbc09324ee53d1", null ],
    [ "reset", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#aa15e10e985ad609d59d9baa25fcbd8ac", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#ae37fa2ef3e03fa0ab82df12857e22258", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#add3ec05400dfeab00a1e04cd21edd5a2", null ],
    [ "setX", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#a0efa203c323fcc2db3455c12d7867e09", null ],
    [ "setY", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#a063c1deb779079f73cf2b7320282758f", null ],
    [ "subtract", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_point_f.html#a201f8f760be40c1ead6c63f5e507b6ee", null ]
];