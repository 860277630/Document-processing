var classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space =
[
    [ "ColorSpace", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#a64a4505977847e74581e6b041fa433c8", null ],
    [ "ColorSpace", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#a1d759ad5f7ff821225df68dcbbbae815", null ],
    [ "convertColor", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#aa549682d85ea820d06158ed80928d606", null ],
    [ "convertColor", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#a0d2524d0a03f0ce47a9a9dd91c69804d", null ],
    [ "convertColor", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#a248ed38fdcdc7867e27b86a3cfd4d835", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#a02bf74faa754ef087fd1b6e9bb99d84c", null ],
    [ "getColorSpaceType", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#a48b5eef97391b51ad8ca7e281e820feb", null ],
    [ "getComponentCount", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#adb12496119671f9bb05adca054fca9e3", null ],
    [ "getComponentNames", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#a38b1e5589688f6edc19ce3002f12a774", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#af410d13829f64c1660a915ab3f3c95f1", null ],
    [ "isSpotColorSpace", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#a0023d799fb34cf9947e376ada8d89196", null ],
    [ "e_RenderIntentAbsColorimetric", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#ac76d54f93b178f2bf1e6d8d563acd871", null ],
    [ "e_RenderIntentPerceptual", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#a1ce3e923a70c0db4559a5d6b5592d26c", null ],
    [ "e_RenderIntentRelColorimetric", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#aa2c77a72f6bb6c29748224896bec4a06", null ],
    [ "e_RenderIntentSaturation", "classcom_1_1foxit_1_1sdk_1_1common_1_1_color_space.html#af5b8b73ac1d38843f32680f6f4d46b2c", null ]
];