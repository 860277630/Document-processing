var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects =
[
    [ "GraphicsObjects", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#ab2210595359d40b470ca431458ab9183", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a9dcbdbd56ddb04032f3cf59b438eec88", null ],
    [ "generateContent", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a89f99441a48323e31ea223d5bf99c23e", null ],
    [ "generateContent", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a67dfd20df6290d0704adb97f151c23a2", null ],
    [ "getFirstGraphicsObjectPosition", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a782791ecfb709af89271b6cafc9afd8b", null ],
    [ "getGraphicsObject", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a900591f2f2ea501669b8e9696f7a5281", null ],
    [ "getGraphicsObject", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a8aa7c878cb0a7328bc69caab58ea81c9", null ],
    [ "getGraphicsObjectCount", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#ab9b4abc495330ec594fd7a3b4b1d3704", null ],
    [ "getGraphicsObjectIndex", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#add4cda533973f435a0789131019a5287", null ],
    [ "getGraphicsObjectPosition", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a2e3fd168f5874d1fcf288c3443b80802", null ],
    [ "getLastGraphicsObjectPosition", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a3e04e7c235c21323b1be9e9955b58f59", null ],
    [ "getNextGraphicsObjectPosition", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a52771eb8e14ad9049da933fa6aebbe0b", null ],
    [ "getPrevGraphicsObjectPosition", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#af9e7fe1c7f93272b31df1391148cbedc", null ],
    [ "insertGraphicsObject", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a17c646f4b6aa2b7c5544555f6340e732", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a8277536a50ef2491a520512599008f83", null ],
    [ "moveGraphicsObjectByPosition", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#ae25011dcea943dd2c8de36085ab7eb28", null ],
    [ "removeGraphicsObject", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#aae7adcc9bff3f62877f279fe262714b0", null ],
    [ "removeGraphicsObjectByPosition", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#ae43c125ee6da649dab8e65afcc5f6d6c", null ],
    [ "e_TextMergeBTET", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a4e07446b8a7688a85e3210f1a15a60d0", null ],
    [ "e_TextMergeNone", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a22c3ed24d1aceb25df09d136c41e44d5", null ],
    [ "e_TextMergeTJY", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#a5785b76f588daf97d7560fb31cea05e7", null ]
];