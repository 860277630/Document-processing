var classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_file_reader_callback =
[
    [ "getSize", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_file_reader_callback.html#a2c561ef52e9ed6cb6bdf8bb716d20dfa", null ],
    [ "readBlock", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_file_reader_callback.html#aadd6f57397b805e8e49ab7b2db828421", null ],
    [ "release", "classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_file_reader_callback.html#a18de9768d382dafd2ae2175baf52cd4b", null ]
];