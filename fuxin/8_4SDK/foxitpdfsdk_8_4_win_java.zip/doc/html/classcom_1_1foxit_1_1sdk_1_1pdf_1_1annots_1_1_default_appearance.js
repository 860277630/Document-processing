var classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance =
[
    [ "DefaultAppearance", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#a9434026baa17284435035322a250e54b", null ],
    [ "DefaultAppearance", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#a9d0346a23c7dff006494573751d49daa", null ],
    [ "DefaultAppearance", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#a36288a2fe4652f55137888969ce69cbe", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#adadb42654cddfebf9f78eb2e0c6a47fc", null ],
    [ "getFlags", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#a65cca2cac8ffeacf81883e4c7e6011b2", null ],
    [ "getFont", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#a0ee9530dba8660be2a6c3d3bb82a07dc", null ],
    [ "getText_color", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#a177d2a863e90445fe1d126e7a98f7c4c", null ],
    [ "getText_size", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#affd9544be0dc1b1f2f42164396cbe337", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#ae3d5205418fe7051f1a689098df9fb0a", null ],
    [ "setFlags", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#abd99685c24cc760edac31e3239525029", null ],
    [ "setFont", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#ae67d948d161b47a333712c8c1a9cb76f", null ],
    [ "setText_color", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#ac73cd30eacaeb9dba589c86e62a650bf", null ],
    [ "setText_size", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#a607f8cca37cb2c9c6d5905725c7595c0", null ],
    [ "e_FlagFont", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#a500754845ae52059cfdf3e242f1b470a", null ],
    [ "e_FlagFontSize", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#a1b7b714a5a6761f639e1b71a07e80547", null ],
    [ "e_FlagTextColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_default_appearance.html#a7cd4d6956e7ea7b30f0a9e7657c77119", null ]
];