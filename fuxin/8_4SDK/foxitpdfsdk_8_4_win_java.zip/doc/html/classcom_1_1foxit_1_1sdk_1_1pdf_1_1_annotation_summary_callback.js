var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback =
[
    [ "getCurrentLocaleID", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#a262e10413ac5a2ce577570eef8a90065", null ],
    [ "getLocalFontName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#ad2deb7178cfdd16dc16ac10942654935", null ],
    [ "loadString", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#ab9570937931595ec7c22b41a89b1c24d", null ],
    [ "release", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#a76c79fb7b80a8666085801b845aabf0d", null ],
    [ "e_AnnotationSummaryStringIDAuthor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#ad1f80491e24c8865953dc57d1381eaf8", null ],
    [ "e_AnnotationSummaryStringIDDate", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#a62b66dd2069d3e1678009878e93ac40d", null ],
    [ "e_AnnotationSummaryStringIDDocumentTitle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#a4718ea99e4283d4e6b34cab683e1a0a9", null ],
    [ "e_AnnotationSummaryStringIDNoAnnotations", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#a21a2fa5e92c179dcceb65b8785333d50", null ],
    [ "e_AnnotationSummaryStringIDNumber", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#a1eb05ab2adcf1c0d89cc38ce7d1d1473", null ],
    [ "e_AnnotationSummaryStringIDPage", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#acce58ca1cf966f0c791fbfec10429005", null ],
    [ "e_AnnotationSummaryStringIDPageTitle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#a7ea0eecedeb386a556db63d00dd7e01f", null ],
    [ "e_AnnotationSummaryStringIDSubject", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#a06822e9cc2b50e8efdfa81c21e7b10a2", null ],
    [ "e_AnnotationSummaryStringIDType", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_annotation_summary_callback.html#aaab364f3accf157f51341639d7aba88e", null ]
];