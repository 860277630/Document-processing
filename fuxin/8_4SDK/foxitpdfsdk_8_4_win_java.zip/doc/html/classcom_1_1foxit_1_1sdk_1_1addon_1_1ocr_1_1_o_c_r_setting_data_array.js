var classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array =
[
    [ "OCRSettingDataArray", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array.html#ae0daf06e6bc026224d39422a10820751", null ],
    [ "OCRSettingDataArray", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array.html#a85a95ca923a4ecb552a85307f2816def", null ],
    [ "add", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array.html#aa330526e0e33d75ee634675fce79c9f2", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array.html#a8507c11a6dd0c80c9e1a75297e7c910a", null ],
    [ "getAt", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array.html#ae0b2896c8a6234611877c43d8148e18d", null ],
    [ "getSize", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array.html#ad36861127db1641fc527654010d27c0e", null ],
    [ "insertAt", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array.html#a818dffab5f6aa44ce21c37dbfbb9835e", null ],
    [ "removeAll", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array.html#a38375c9d38a9c11494b450970cd5f460", null ],
    [ "removeAt", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array.html#a73d53fa434d4450e7477dedd5e5ce533", null ]
];