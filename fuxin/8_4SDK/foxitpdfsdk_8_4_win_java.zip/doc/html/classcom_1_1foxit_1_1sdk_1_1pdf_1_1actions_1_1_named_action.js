var classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_named_action =
[
    [ "NamedAction", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_named_action.html#abeb4465b6ee8e8eca2bc593e973a9b67", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_named_action.html#a669e7813482a8cbddabd373747ae9d8b", null ],
    [ "getName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_named_action.html#a7c1d073a4bb48a44169e07bf85136cda", null ],
    [ "setName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_named_action.html#a0e763124cbb81c9fd39cbaa9630c9e4b", null ]
];