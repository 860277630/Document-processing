var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign =
[
    [ "FillSign", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#ab96abb6e81f71509ded060e44933e97c", null ],
    [ "FillSign", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#a0a239b9dfc7696bbb073348fa213887a", null ],
    [ "addObject", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#a513251d77aa2df1d58e98618fd451ac4", null ],
    [ "addTextObject", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#a34d024c30db62260e3da83965fdab249", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#aa734edeb023326f1615aa74d967a8690", null ],
    [ "getObjectAtDevicePoint", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#ab56ba0294f77f76b6f2b2a0122a2e2fc", null ],
    [ "getObjectAtPoint", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#a966457806495107392ac6c4a27344057", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#ac79ddcb1ba6b0634394c999cb975723d", null ],
    [ "removeObject", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#a91f6e625d53ea017a1c54acdc47faef9", null ],
    [ "e_FillSignObjectTypeCheckMark", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#aaed57ce47b36771417361fcde9342043", null ],
    [ "e_FillSignObjectTypeCrossMark", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#a087ded0ac8841fbd900baa2be7bddeab", null ],
    [ "e_FillSignObjectTypeDot", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#a1f8f2dd0a1e4218b45347f8f13c04bee", null ],
    [ "e_FillSignObjectTypeInitialsSignature", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#a6f640645f8eb66ab3dd6180595a87476", null ],
    [ "e_FillSignObjectTypeLine", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#abdfafcb16c01ca307f36e6baad59de36", null ],
    [ "e_FillSignObjectTypeRoundRectangle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#af8c08f9b7eba7dad488b7d3cf722ecc7", null ],
    [ "e_FillSignObjectTypeSignature", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#af86c5582db8daa950c1d2c4926b4ccc0", null ],
    [ "e_FillSignObjectTypeText", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_fill_sign.html#a8021ff4c1685e2e440c5bc81993cc515", null ]
];