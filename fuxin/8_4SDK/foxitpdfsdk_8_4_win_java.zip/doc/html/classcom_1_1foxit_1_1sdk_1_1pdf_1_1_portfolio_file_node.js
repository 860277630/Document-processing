var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_file_node =
[
    [ "PortfolioFileNode", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_file_node.html#a8485d44e815dfcfe09f5a40cbee911a2", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_file_node.html#aaf537b6970b0dab82f9f608d5b674a7d", null ],
    [ "getFileSpec", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_file_node.html#a47c38055f4efbbe6a5784eacc0dc5af7", null ],
    [ "getKeyName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_portfolio_file_node.html#a9594d23a4f71282da58b3c99441a0ccd", null ]
];