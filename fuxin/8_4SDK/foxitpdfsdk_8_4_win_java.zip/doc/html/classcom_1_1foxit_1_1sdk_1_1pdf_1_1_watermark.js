var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark =
[
    [ "Watermark", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark.html#a8b5b11b155b9b6291cbe79543984dd10", null ],
    [ "Watermark", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark.html#afe9f004f107a532f717e749653df378d", null ],
    [ "Watermark", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark.html#a99adad1f594531cd10fcfb960c03f267", null ],
    [ "Watermark", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark.html#ab3e6c339dafdd6c7b3acd68e125ba2ba", null ],
    [ "Watermark", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark.html#aec55df98352990fd60303ff19efc97ea", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark.html#ac72445f975f2eb5f0e8833324710d5e2", null ],
    [ "getHeight", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark.html#abc6577ed64f438048a2de5c6b28ff890", null ],
    [ "getWidth", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark.html#ab340e37b5125cde3c556cf15ca43ea90", null ],
    [ "insertToPage", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark.html#a1c8436e3a5655d3215a8cdf14702a30d", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_watermark.html#a9161b05fab87e20d92e03eee13713b83", null ]
];