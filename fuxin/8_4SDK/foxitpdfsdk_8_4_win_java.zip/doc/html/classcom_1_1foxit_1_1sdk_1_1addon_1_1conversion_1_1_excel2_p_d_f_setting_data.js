var classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data =
[
    [ "Excel2PDFSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a3f303ddc00f4ab62b1d061f0d9a177f7", null ],
    [ "Excel2PDFSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a7f6f31c70de644e0000b9a7fa7813563", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#abc6ebfd1e13f564163e31be2ed1c5bf9", null ],
    [ "getConvert_to_pdfa", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a6bbec1dade2cf24689cff2f231fe3588", null ],
    [ "getIgnore_print_area", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a7f50f5076db5c99086b17429afa4b977", null ],
    [ "getInclude_doc_props", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#aba7ed0773352c125995e30f092cfd377", null ],
    [ "getQuality", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#ae48e0b6785b90e59c8323f81742d6c7e", null ],
    [ "getScale_type", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#aef9f7fa7f6bcb7415a8151d7f1ccd48d", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a0089d55cc131cfc3d73787c06cbc5ac9", null ],
    [ "setConvert_to_pdfa", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#ab3e602946b5c2be8fd4bef781825fe2d", null ],
    [ "setIgnore_print_area", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a41e898bfbb4b96dceef1b92015ad3209", null ],
    [ "setInclude_doc_props", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#aac8581e0d497c9d4d5d41d9ddcf887c6", null ],
    [ "setQuality", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#af867aefbe023bcf9e417a7248ca14ab7", null ],
    [ "setScale_type", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a402ffd76505f14c3abc5ff31c845f98a", null ],
    [ "e_ConvertQualityMinimum", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a21ad2854a79afc95131f464c6a4f92c1", null ],
    [ "e_ConvertQualityStandard", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a40e3734d59d6d00e0544123f7613ff70", null ],
    [ "e_ScaleTypeFitAllColumns", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a12beadc051f3c05aa0e85f38cc2ebfcc", null ],
    [ "e_ScaleTypeFitAllRows", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a0416784f8d39072bf88ab5793ac58812", null ],
    [ "e_ScaleTypeFitSheet", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a9ff9ec5aed90b3000530f784954d451a", null ],
    [ "e_ScaleTypeNone", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html#a65c96f5bb22054d3903f9043dc055c61", null ]
];