/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Foxit PDF SDK", "index.html", [
    [ "Overview", "index.html", null ],
    [ "COPYRIGHT", "page1.html", null ],
    [ "REDISTRIBUTION", "page2.html", null ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Packages", "namespaces.html", [
      [ "Packages", "namespaces.html", "namespaces_dup" ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"classcom_1_1foxit_1_1sdk_1_1_identity_properties.html#a3eff64d9e8bf6129a3db3f2c8a7a3c73",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_border_info.html#a333674f71240f913a50a21a411aa9da7",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_result_information.html#aa79759b6ff66bb013ae0408c0ad24db1",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_word2_p_d_f_setting_data.html#add2258fceda7ecd342f2fc0b4bedcb59",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_structure_element.html#ae10520fcc1628688795f0d15859037ee",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1xfa_1_1_app_provider_callback.html#ab4ccec33bb2b66ed4b720afbd98f889c",
"classcom_1_1foxit_1_1sdk_1_1addon_1_1xfa_1_1_x_f_a_widget.html#aeb0a10ecace3bf4351d50dd4b0419c27",
"classcom_1_1foxit_1_1sdk_1_1common_1_1_date_time.html#aa53f57d3a0b85443c96ac9a3dd2ffd42",
"classcom_1_1foxit_1_1sdk_1_1common_1_1_render_config.html#a9efd9227e2909026c48623cc78220833",
"classcom_1_1foxit_1_1sdk_1_1common_1_1fxcrt_1_1_rect_i.html#a33cfe0d391a52326a881c565ce336d72",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_cert_verify_result.html#afb1e258f1954133b76936939572a64c6",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_graphics_objects.html#af9e7fe1c7f93272b31df1391148cbedc",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_output_preview.html#af5cbabe723523aef775fccbdade2b3ab",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_p_d_f_page.html#afc9d979d58b356cc52874a2f40ccb0cf",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_rendition.html#a4724124822393be97f6f966b40390440",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_signature.html#addd37cdae2fa68a137ba750ea845545c",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1_text_search.html#ad9609a7bb0a5a62893de4ae5bcf90392",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1actions_1_1_embedded_goto_target.html#a6acdad452e687687f928ccfca133ed02",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_caret.html#a2fbaabbf196fef9073bbe6bc70c9ccdc",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_note_array.html#abc2a725496c304d2671dad94425a33cc",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_widget.html#af4b406a27dfb7ae09c967ece06d53eb5",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1interform_1_1_field.html#a9ea48be0ee24bd307391e0e48ab7577e",
"classcom_1_1foxit_1_1sdk_1_1pdf_1_1objects_1_1_p_d_f_dictionary.html#a090b29f93ea054715a9d08b3f753581b"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';