var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata =
[
    [ "Metadata", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#ae0ea63c6adf4efb0b30b9af19a838b55", null ],
    [ "Metadata", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#a611fcf37c148c14574564d6492db2654", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#a24024f1390583b590c9a11f66b991f03", null ],
    [ "getCreationDateTime", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#a0ea362c8fc351699a87edb14e60c5d42", null ],
    [ "getCustomerKeys", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#a500c960532cbea834de48d60d475b42b", null ],
    [ "getModifiedDateTime", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#ac80cb437272c2e8ceb0a96bb47e5d4f0", null ],
    [ "getValues", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#ac47429e1bac6f728c9388b142ece1b3e", null ],
    [ "hasKey", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#a37595b9e8413f68f158976dc3cd20c65", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#ab2d50a166f4463b6c2d5c75724bfa44b", null ],
    [ "removeCustomerKey", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#a16921290fd8befcc5ba8ce0b2b005f16", null ],
    [ "setCreationDateTime", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#ae04476266def67273c004f07f112e219", null ],
    [ "setModifiedDateTime", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#aaf02fd25de62f35f786525a1522788de", null ],
    [ "setValues", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_metadata.html#a23d89490af7a6c24ec30ed3614cbc451", null ]
];