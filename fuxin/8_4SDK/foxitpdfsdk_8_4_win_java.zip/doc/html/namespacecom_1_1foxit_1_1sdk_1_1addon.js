var namespacecom_1_1foxit_1_1sdk_1_1addon =
[
    [ "accessibility", null, [
      [ "TaggedPDF", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f" ],
      [ "TaggedPDFCallback", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback" ]
    ] ],
    [ "comparison", null, [
      [ "CompareResultInfo", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_compare_result_info.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_compare_result_info" ],
      [ "CompareResultInfoArray", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_compare_result_info_array.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_compare_result_info_array" ],
      [ "CompareResults", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_compare_results.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_compare_results" ],
      [ "Comparison", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1comparison_1_1_comparison" ]
    ] ],
    [ "compliance", null, [
      [ "ComplianceEngine", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_compliance_engine.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_compliance_engine" ],
      [ "FixupData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_fixup_data" ],
      [ "HitData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_hit_data.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_hit_data" ],
      [ "PDFACompliance", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_a_compliance" ],
      [ "PDFCompliance", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_compliance.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_p_d_f_compliance" ],
      [ "ProgressCallback", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_progress_callback.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_progress_callback" ],
      [ "ResultInformation", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_result_information.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1compliance_1_1_result_information" ]
    ] ],
    [ "conversion", null, [
      [ "Convert", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_convert.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_convert" ],
      [ "Excel2PDFSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_excel2_p_d_f_setting_data" ],
      [ "HTML2PDFRelatedResource", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_h_t_m_l2_p_d_f_related_resource.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_h_t_m_l2_p_d_f_related_resource" ],
      [ "HTML2PDFRelatedResourceArray", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_h_t_m_l2_p_d_f_related_resource_array.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_h_t_m_l2_p_d_f_related_resource_array" ],
      [ "HTML2PDFSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_h_t_m_l2_p_d_f_setting_data.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_h_t_m_l2_p_d_f_setting_data" ],
      [ "PowerPoint2PDFSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_power_point2_p_d_f_setting_data.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_power_point2_p_d_f_setting_data" ],
      [ "TXT2PDFSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_t_x_t2_p_d_f_setting_data" ],
      [ "Word2PDFSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_word2_p_d_f_setting_data.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1conversion_1_1_word2_p_d_f_setting_data" ]
    ] ],
    [ "layoutrecognition", null, [
      [ "LRContentElement", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_content_element" ],
      [ "LRContext", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_context.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_context" ],
      [ "LRElement", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_element.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_element" ],
      [ "LRGraphicsObjectElement", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_graphics_object_element.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_graphics_object_element" ],
      [ "LRStructureElement", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_structure_element.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1layoutrecognition_1_1_l_r_structure_element" ]
    ] ],
    [ "ocr", null, [
      [ "OCR", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r" ],
      [ "OCREngine", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_engine.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_engine" ],
      [ "OCRSettingData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data" ],
      [ "OCRSettingDataArray", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1ocr_1_1_o_c_r_setting_data_array" ]
    ] ],
    [ "optimization", null, [
      [ "ImageSettings", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_image_settings.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_image_settings" ],
      [ "MonoImageSettings", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_mono_image_settings.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_mono_image_settings" ],
      [ "Optimizer", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_optimizer.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_optimizer" ],
      [ "OptimizerSettings", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_optimizer_settings.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_optimizer_settings" ],
      [ "UnembeddedFontSettings", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_unembedded_font_settings.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1optimization_1_1_unembedded_font_settings" ]
    ] ],
    [ "xfa", "namespacecom_1_1foxit_1_1sdk_1_1addon_1_1xfa.html", "namespacecom_1_1foxit_1_1sdk_1_1addon_1_1xfa" ],
    [ "FormCombination", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_form_combination.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_form_combination" ],
    [ "FormFileInfo", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_form_file_info.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_form_file_info" ],
    [ "FormFileInfoArray", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_form_file_info_array.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_form_file_info_array" ],
    [ "Redaction", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_redaction.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_redaction" ],
    [ "TableBorderInfo", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_border_info.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_border_info" ],
    [ "TableCellData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_cell_data.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_cell_data" ],
    [ "TableCellDataArray", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_cell_data_array.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_cell_data_array" ],
    [ "TableCellDataColArray", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_cell_data_col_array.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_cell_data_col_array" ],
    [ "TableCellIndexArray", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_cell_index_array.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_cell_index_array" ],
    [ "TableData", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_data.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_data" ],
    [ "TableGenerator", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_generator.html", "classcom_1_1foxit_1_1sdk_1_1addon_1_1_table_generator" ]
];