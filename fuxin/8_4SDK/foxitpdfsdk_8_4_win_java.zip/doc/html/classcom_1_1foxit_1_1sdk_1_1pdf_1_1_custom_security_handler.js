var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_handler =
[
    [ "CustomSecurityHandler", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_handler.html#abbf7fd12aeffbf08fde7a3189d59d4bd", null ],
    [ "CustomSecurityHandler", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_handler.html#a3d2301175ba9392be9f0d99a5501b936", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_handler.html#a615d192ae1b7c124d41186c336780de2", null ],
    [ "initialize", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_custom_security_handler.html#a9b02ade8061e4d3a36ed0f1b5ca69558", null ]
];