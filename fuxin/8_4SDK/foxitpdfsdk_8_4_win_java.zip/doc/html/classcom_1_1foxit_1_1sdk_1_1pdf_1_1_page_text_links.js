var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_page_text_links =
[
    [ "PageTextLinks", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_page_text_links.html#a3d2900184cd64e0e360bcb26dde96529", null ],
    [ "PageTextLinks", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_page_text_links.html#a91638a5d2e8e5d5cd7f7329c43e86dc4", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_page_text_links.html#a22f88e3e26d8dd2f51e46ae265b8ad4c", null ],
    [ "getTextLink", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_page_text_links.html#a7defad995aff28d74427f717cdbbec4a", null ],
    [ "getTextLinkCount", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_page_text_links.html#a05f32777d8f10d14b2c9e1f01afdfb23", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_page_text_links.html#a4c10fa7d74fa9aafdaea02390a281ea6", null ]
];