var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data =
[
    [ "PayLoadData", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#a82e8e888bb39e51c771e56b3d247322f", null ],
    [ "PayLoadData", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#a1b2d50de5bcd4373332c0335639a8e53", null ],
    [ "PayLoadData", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#a899fcbd32d2fb1af998a55b9d4a0fa2e", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#a448785235f1b2268549952095be8d515", null ],
    [ "getCrypto_filter", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#a0885bf1b9b4c1e5ce45f0e04b60f72cb", null ],
    [ "getDescription", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#aeea9f0fdfdb7a07b40d5b611cf9974bb", null ],
    [ "getFile_name", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#a48d9f38db9cf0a0c16b93359c1e8fa4d", null ],
    [ "getFile_size", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#af5dc4d8b029e929638604d95405c7237", null ],
    [ "getVersion", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#a8911935718d284deaf86306c8ad4def0", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#afe8a1d752733cc08677a7a2dcbc3404f", null ],
    [ "setCrypto_filter", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#a5061bfe7050bd1526e67516da98aac40", null ],
    [ "setDescription", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#a5180fb1b319ab911750292b5e5656e0e", null ],
    [ "setFile_name", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#adb58d628561de0caf799df73bdf790da", null ],
    [ "setFile_size", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#a6caae2fb60e606363babce1d7e818677", null ],
    [ "setVersion", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_pay_load_data.html#a583c84d714a4a0c9a4c0edbbbe0e71f9", null ]
];