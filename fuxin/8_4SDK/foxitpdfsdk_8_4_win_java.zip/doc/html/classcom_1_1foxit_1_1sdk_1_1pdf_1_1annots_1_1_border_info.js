var classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info =
[
    [ "BorderInfo", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#a53eb4291ea6f4e8337e7dcb3c7fe8818", null ],
    [ "BorderInfo", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#ab6cd26a99b948e808fac596946d2b569", null ],
    [ "BorderInfo", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#a32937ab8c96fbf37fc0f1c3a4ec2d137", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#ac6b03bf1c8de3ae5bfa854ce4dd095bd", null ],
    [ "getCloud_intensity", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#af6748e94e61ec7c68d75906113fa7bbe", null ],
    [ "getDash_phase", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#a6d0b3fa22d4f423cdfdd650d7f754aed", null ],
    [ "getDashes", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#af0c2ff8251a47f9b21e9eca937108f12", null ],
    [ "getStyle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#ad055b95276a20c650252d12b008457a1", null ],
    [ "getWidth", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#ab800d46a7d16f1c06e7d3e81d9d9ea53", null ],
    [ "set", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#a9b38ac9d34c915a1324f7bc123253cd8", null ],
    [ "setCloud_intensity", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#ac593cb5f764c5c21a13265572984c75c", null ],
    [ "setDash_phase", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#a53d7689518575248d92d579c3485808b", null ],
    [ "setDashes", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#a6e3226e5c62b163f6617cbfb1d8ddee5", null ],
    [ "setStyle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#a949163485600334f4357a8f7da5c557c", null ],
    [ "setWidth", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#a4dce71dbf6fdf497decccbf0786326d0", null ],
    [ "e_Beveled", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#ad6ff6da2039c4d7e72f1370b5bf6bc4f", null ],
    [ "e_Cloudy", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#a0ff100b2558ef06103017fce406627d9", null ],
    [ "e_Dashed", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#ad108e06ced12a6fe56d8eabed6b00914", null ],
    [ "e_Inset", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#a912806faaf424c5a21340d08c5f95139", null ],
    [ "e_Solid", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#aab82bf916915a3676d1047b5f28f8175", null ],
    [ "e_UnderLine", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_border_info.html#aaa456898ade539249f210798bc17c295", null ]
];