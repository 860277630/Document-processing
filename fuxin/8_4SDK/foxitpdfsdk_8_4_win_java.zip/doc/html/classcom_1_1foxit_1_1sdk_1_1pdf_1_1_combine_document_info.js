var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_combine_document_info =
[
    [ "CombineDocumentInfo", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_combine_document_info.html#a80f4055b320030e8a662f107773a2514", null ],
    [ "CombineDocumentInfo", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_combine_document_info.html#ac8b833b599b5ef74be6bf8afa28cb37f", null ],
    [ "CombineDocumentInfo", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_combine_document_info.html#a913afc9553a5150b02cc2ac298c09a94", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_combine_document_info.html#a7107c611a8cd7968a6b2a014fd8d696a", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_combine_document_info.html#a28ef75a99fa33770970adb88c75a7b53", null ],
    [ "setBookmarkTitle", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_combine_document_info.html#a05be57d82c67e2a1453a69967e37e9bf", null ],
    [ "setPDFFileName", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_combine_document_info.html#a3c0748cbef79b2f5ee34580e08b11bd1", null ]
];