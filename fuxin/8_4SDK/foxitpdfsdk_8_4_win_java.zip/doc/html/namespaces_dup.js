var namespaces_dup =
[
    [ "com", null, [
      [ "foxit", null, [
        [ "sdk", "namespacecom_1_1foxit_1_1sdk.html", "namespacecom_1_1foxit_1_1sdk" ]
      ] ]
    ] ]
];