var classcom_1_1foxit_1_1sdk_1_1fts_1_1_documents_source =
[
    [ "DocumentsSource", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_documents_source.html#a6a045e0e761c6cd661ee7663accbd4f4", null ],
    [ "DocumentsSource", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_documents_source.html#aba8ec42ef7379980ffd19c16c8ac1f7f", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_documents_source.html#abb4a7c45ce07abc40efc2e87e232338d", null ],
    [ "isEmpty", "classcom_1_1foxit_1_1sdk_1_1fts_1_1_documents_source.html#ae3bd118a45588b650d8d5cf9aef5bbf8", null ]
];