var classcom_1_1foxit_1_1sdk_1_1pdf_1_1_p_s_i_callback =
[
    [ "refresh", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_p_s_i_callback.html#ad6ab0941a8bf422c80c6ac47d615557b", null ],
    [ "release", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1_p_s_i_callback.html#af1d6638c18fe8296c1870c4270324124", null ]
];