var classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback =
[
    [ "release", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#a630a3e994e4c8ecde9722bd10c01848e", null ],
    [ "report", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#a15f197391c2456817b3e889d862f9c4c", null ],
    [ "e_ReportCategoryArtifact", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#aaf6820fd66b42aa3e81971395fa4fc2b", null ],
    [ "e_ReportCategoryFigure", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#aedde3889b6c545b1ed9884bb123f8e49", null ],
    [ "e_ReportCategoryListItem", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#a64dda3c86a8ac9139e54b49ddb5bddf0", null ],
    [ "e_ReportCategoryParagraph", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#ad1c0f874bc8dba3d7917c0d38c440261", null ],
    [ "e_ReportCategoryRegion", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#ad9fba962cf00b7e1035c24b62905a702", null ],
    [ "e_ReportCategoryTable", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#ab6278d7ed5454e9124e481dcbfa4df65", null ],
    [ "e_ReportCategoryTableHeader", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#aefee1aa580ff5b3aa95803552578f308", null ],
    [ "e_ReportCategoryTableRow", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#ad062466c5ab79ab35fc46c98205a82da", null ],
    [ "e_ReportCategoryTocItem", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#a6cb4578e98c0c1efd381b9d50b4dc23f", null ],
    [ "e_ReportConfidenceHigh", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#afa75fc6689b4b5220d57c5c6149dd4b8", null ],
    [ "e_ReportConfidenceLow", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#a5208f81a623f864a68b827909377ceb6", null ],
    [ "e_ReportConfidenceMedium", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#abfd5d381437434fa485bb64c8e0f2d38", null ],
    [ "e_ReportConfidenceMediumHigh", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#a4eec38061aec1459f8c3eef2be3ba14f", null ],
    [ "e_ReportConfidenceMediumLow", "classcom_1_1foxit_1_1sdk_1_1addon_1_1accessibility_1_1_tagged_p_d_f_callback.html#aa6e12e7b27a1e9cb633bc881e89b8df6", null ]
];