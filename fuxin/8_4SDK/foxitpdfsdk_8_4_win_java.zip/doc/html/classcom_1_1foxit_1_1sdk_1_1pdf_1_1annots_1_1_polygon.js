var classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon =
[
    [ "Polygon", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#abc2d8cf9cd359b82711a9d907d57bc3a", null ],
    [ "Polygon", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#a02a684e440e650d31036117017e6c3c1", null ],
    [ "delete", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#aed837872a3486e36ffcb18cb4fc8a122", null ],
    [ "getFillColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#af4b53969e8c37bd66644bfd1a7da5773", null ],
    [ "getMeasureConversionFactor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#a6ababf21e64b10c1ec8c1c874e81a7a8", null ],
    [ "getMeasureRatio", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#a8a8d19208cacecca43e863332f4d570d", null ],
    [ "getMeasureRatioW", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#a1b02a7185ea7b0e2fd6ff0e224106cbe", null ],
    [ "getMeasureUnit", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#a5d0c49c77997ac491c12f8d0acdd9045", null ],
    [ "getMeasureUnitW", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#a759bd643712492224d5092a32b99b2a7", null ],
    [ "getVertexes", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#af49ca38f10a708a5ac47a15551398865", null ],
    [ "setFillColor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#a4eb9f5aee2c1d9fc89ac4786440b99e9", null ],
    [ "setMeasureConversionFactor", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#a8367723848919cd38982c383b68439c5", null ],
    [ "setMeasureRatio", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#a5542008390ed9f259adf368cb8b0561a", null ],
    [ "setMeasureUnit", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#a1cb0cb8987099d3c8377da45cffee9a0", null ],
    [ "setVertexes", "classcom_1_1foxit_1_1sdk_1_1pdf_1_1annots_1_1_polygon.html#af70b1c7eb915d09f43cd5e9beafe7656", null ]
];